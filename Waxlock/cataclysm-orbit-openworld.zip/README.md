# Cataclysm Orbit — Open World Edition

A ground-up rebuild addressing every point of the last round of feedback.
Open `index.html` in a browser — no install, no server, no build step.

## What changed, and why

**"The art style is terrible, go get proper pixel art or free assets."**
Done both. The world tiles, walls, water, and enemy creatures are real,
professionally-made **CC0 (public domain) pixel art from Kenney's asset
library** (via `shorepine/kenney` on GitHub — a legitimate CC0 mirror,
license copy included at `assets/tiles/KENNEY_LICENSE.txt`). Kenney doesn't
publish a cat character, so the cats themselves are hand-authored, native
32x32 pixel art built pixel-by-pixel (not the vector shapes from last time)
in `tools/gen_cat_sprites.py` — you can see the actual pixel grid logic
there. Everything renders with image smoothing forced off, so it stays
crisp pixel art at any scale instead of blurring.

**"Make it an open world map with biomes."**
The fixed arena is gone. `js/world/tilemap.js` procedurally generates one
big seeded tile map (110x110 tiles) split into a safe central spawn
("Litter Fields") surrounded by three biome sectors — Junkyard, Toxic
Marsh, Crystal Wastes — each reusing the same tile art with a colour-tint
overlay and its own decoration set. The camera follows you freely across
the whole thing.

**"Update the character models."**
All-new hand-pixeled cats (4 palettes x 3 facing directions x 2-frame walk
cycle) and all-new enemies (adapted from Kenney's creature tiles — see
below).

**"Tutorial every time you start."**
A short 4-card overlay (`js/scenes/tutorial.js`) shows every time you enter
the world — movement, combat, dash, objective. Click/Space/Esc to blow
through it in a couple of seconds if you already know it.

**"Make it progressive — unlock more the more you play."**
This is the new core loop: clear trash in your current biome, a named
guardian boss spawns, beating it unlocks the next biome *and* the next
playable cat (Brick ties to Junkyard, Soot to Toxic Marsh, Miso to Crystal
Wastes). Locked biomes render fogged/dark and softly push you back out if
you wander in early.

**"EXP and collision/health don't work."**
Both real bugs, both fixed:
- **Collision**: in the previous build, damage only ever came from bullet
  collisions — melee enemies (Grub, Mite) had *no code path at all* that
  dealt contact damage on touch. `js/world/entities.js` now has an explicit
  contact-damage check every frame for melee-type enemies (search that file
  for "CONTACT DAMAGE" — it's commented with the bug explanation).
- **EXP**: fish used to flow player -> run satchel -> (deposit on death) ->
  vault -> EXP, and that middle step turned out fragile. Fish now go
  **straight into the vault** the moment you pick them up — one less place
  for the pipeline to silently drop them. Verified end-to-end in
  `tools/smoke-test.js`.

## How I verified this (no browser in my build environment)

I loaded the actual `index.html` script pipeline headlessly with `jsdom` +
`node-canvas`, then: clicked through every House panel via real DOM events,
force-triggered a full boss-defeat -> biome-unlock -> cat-unlock chain,
directly tested that a melee enemy now damages the player and that a fish
pickup now moves the vault total and converts to EXP, tested death ->
respawn and the pause menu, confirmed the tutorial reappears on a second
World entry, and ran ~60 simulated seconds of open-world play start to
finish. All of that is `tools/smoke-test.js` — rerun it after any future
edit:
```
cd tools && npm install jsdom canvas && node smoke-test.js
```

## Project layout

```
index.html              entry point, boots to the Start scene
css/style.css            all UI styling
js/engine/               sprite loader, game state, input, audio, main loop
js/data/                 fish/cat/weapon/enemy/upgrade/biome data tables
js/world/                tilemap generator + Player/Enemy/Bullet/Pickup
js/scenes/               start, house, world (the open map), tutorial
assets/tiles/            Kenney CC0 tile sheets (town/dungeon/battle) + license
assets/sprites/          hand-pixeled cats, recoloured enemies, fish, house
tools/                   sprite generators (re-run after editing) + smoke test
```

Saves to `localStorage`, persists across sessions on the same browser.

## Controls

Move **WASD** - Aim **mouse** - Attack **hold click / Space** - Dash
**Shift** - Active skill **E** - Pause **Esc** - walk into the House to
enter it

## Where the enemy sprites came from

Kenney's "Tiny Dungeon" pack includes a slime, a crab, a spider, and a
ghost creature. `tools/gen_enemy_sprites.py` extracts each one and
**recolours** it (remapping its existing colours by lightness onto a new
palette, keeping all of the original shading) to fit the trash-planet
theme — Grub is the slime, Spitter is the crab, Mite is the spider, and the
mini-boss is the ghost scaled up with a few junk-coloured blocks stamped on.

## Honest scope notes

- 3 biome bosses share one enlarged/recoloured sprite rather than 3 unique
  designs — a reasonable place to spend more time next if you want it.
- The House interior is a simple single room (walk-in, panel-based) rather
  than a bigger explorable interior.
- Difficulty scales by biome order + a flat kill-count-to-boss threshold
  (12), not a hand-tuned curve — an easy first thing to retune by feel
  once you've played it.

## Next steps

Tell me what to push on next: unique boss designs per biome, a 5th biome,
gear/crafting, or tightening the difficulty curve once you've had a chance
to actually play through it.
