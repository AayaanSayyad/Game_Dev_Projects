/* BiomeData — the open-world map is one big tile grid split into biome
 * quadrants. Each biome reuses the same CC0 Kenney tiles (see
 * assets/tiles/*_sheet.png) with a colour-tint overlay + its own decoration
 * set and enemy pool, so 4 visually distinct zones don't require 4x the
 * art. Biomes unlock in sequence by defeating that biome's guardian.
 */
(function (root) {
	'use strict';

	const TILE = 16; // native px per tile in the sheets

	// sheet tile indices (see tools/*.py comments / labeled montages)
	const T = {
		grass: [0, 1, 2], grassEdge: [12, 13, 14],
		dirt: [39, 40, 41, 42],
		treeGreen: [3, 4, 6, 7, 8], treeAutumn: [9, 10, 11], mushroom: [29, 30],
		wallGrey: [48, 49, 50, 51], wallBrick: [52, 53, 54, 55],
		crystalWall: [96, 97, 98, 108, 109, 110],
		fence: [80, 81, 82],
	};
	const D = { // dungeon sheet
		floorBrown: [0, 1, 2, 3], wallGreyD: [36, 37, 38, 39], sand: [48, 49, 50, 51, 52, 53],
	};
	const B = { // battle sheet
		water: [88, 89, 90, 91], shoreN: [36, 37, 38],
	};

	const BIOMES = {
		litter_fields: {
			name: 'Litter Fields', order: 0, tint: null,
			ground: { sheet: 'town', cols: 12, indices: T.grass, scale: 1 },
			decor: [
				{ sheet: 'town', cols: 12, indices: T.treeGreen, density: 0.018, solid: true },
				{ sheet: 'town', cols: 12, indices: T.mushroom, density: 0.01, solid: false },
			],
			patchTiles: { sheet: 'town', cols: 12, indices: T.dirt, density: 0.05 },
			water: { sheet: 'battle', cols: 14, indices: B.water, density: 0.006 },
			enemies: ['grub', 'mite'],
			bossName: 'Bin Crawler',
			unlockedByDefault: true,
		},
		junkyard: {
			name: 'Junkyard', order: 1, tint: 'rgba(120,110,90,0.28)',
			ground: { sheet: 'dungeon', cols: 12, indices: D.floorBrown, scale: 1 },
			decor: [
				{ sheet: 'dungeon', cols: 12, indices: D.wallGreyD, density: 0.02, solid: true },
				{ sheet: 'town', cols: 12, indices: T.wallBrick, density: 0.012, solid: true },
			],
			patchTiles: { sheet: 'town', cols: 12, indices: T.dirt, density: 0.06 },
			water: null,
			enemies: ['grub', 'spitter', 'mite'],
			bossName: 'Rustclaw',
			requires: 'litter_fields',
		},
		toxic_marsh: {
			name: 'Toxic Marsh', order: 2, tint: 'rgba(120,60,170,0.30)',
			ground: { sheet: 'town', cols: 12, indices: T.grass, scale: 1 },
			decor: [
				{ sheet: 'town', cols: 12, indices: T.mushroom, density: 0.03, solid: false },
				{ sheet: 'town', cols: 12, indices: T.treeAutumn, density: 0.012, solid: true },
			],
			patchTiles: { sheet: 'dungeon', cols: 12, indices: D.sand, density: 0.04 },
			water: { sheet: 'battle', cols: 14, indices: B.water, density: 0.035, tint: 'rgba(150,70,190,0.5)' },
			enemies: ['spitter', 'mite', 'grub'],
			bossName: 'The Sump',
			requires: 'junkyard',
		},
		crystal_wastes: {
			name: 'Crystal Wastes', order: 3, tint: 'rgba(150,200,230,0.22)',
			ground: { sheet: 'town', cols: 12, indices: T.crystalWall.slice(3), scale: 1 },
			decor: [
				{ sheet: 'town', cols: 12, indices: T.crystalWall.slice(0, 3), density: 0.02, solid: true },
			],
			patchTiles: { sheet: 'dungeon', cols: 12, indices: D.wallGreyD, density: 0.03 },
			water: null,
			enemies: ['spitter', 'mite', 'grub'],
			bossName: 'Glasshowl',
			requires: 'toxic_marsh',
		},
	};

	const BIOME_ORDER = ['litter_fields', 'junkyard', 'toxic_marsh', 'crystal_wastes'];

	root.BiomeData = { TILE, T, D, B, BIOMES, BIOME_ORDER };
})(typeof window !== 'undefined' ? window : globalThis);
