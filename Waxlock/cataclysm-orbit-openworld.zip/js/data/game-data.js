/* GameData — same roster/kit numbers as before, adapted so cats unlock with
 * biome progress (not an abstract wave number) and enemies point at real
 * sprite assets instead of vector palettes.
 */
(function (root) {
	'use strict';

	const CATS = {
		stray: {
			id: 'stray', name: 'Stray', role: 'Balanced', unlockBiome: null,
			maxHp: 6, moveSpeed: 95, accel: 750, friction: 900, weight: 1.0,
			dashSpeed: 260, dashTime: 0.16, dashIframes: 0.18, dashCooldown: 1.4,
			weapon: 'scratch_claws', skill: 'fleet_paws', starterGear: 'Scratch Claws',
			amiibo: { desc: '+5% move speed', key: 'move_speed_pct', value: 0.05 },
		},
		brick: {
			id: 'brick', name: 'Brick', role: 'Ranged', unlockBiome: 'junkyard',
			maxHp: 6, moveSpeed: 88, accel: 650, friction: 850, weight: 1.1,
			dashSpeed: 250, dashTime: 0.16, dashIframes: 0.18, dashCooldown: 1.5,
			weapon: 'hairball_slingshot', skill: 'hairball_barrage', starterGear: 'Hairball Slingshot',
			amiibo: { desc: '+1 pierce on primary', key: 'pierce_add', value: 1 },
		},
		soot: {
			id: 'soot', name: 'Soot', role: 'Bruiser', unlockBiome: 'toxic_marsh',
			maxHp: 8, moveSpeed: 74, accel: 520, friction: 780, weight: 1.6,
			dashSpeed: 220, dashTime: 0.14, dashIframes: 0.16, dashCooldown: 1.7,
			weapon: 'rusty_forge_hammer', skill: 'anvil_slam', starterGear: 'Rusty Forge Hammer',
			amiibo: { desc: '-10% gear loss (Phase 2)', key: 'gear_loss_pct', value: -0.10 },
		},
		miso: {
			id: 'miso', name: 'Miso', role: 'Support', unlockBiome: 'crystal_wastes',
			maxHp: 6, moveSpeed: 92, accel: 700, friction: 870, weight: 0.9,
			dashSpeed: 250, dashTime: 0.16, dashIframes: 0.18, dashCooldown: 1.4,
			weapon: 'purr_wave', skill: 'purr_charm', starterGear: 'Purr Charm',
			amiibo: { desc: '+0.5 heart start', key: 'bonus_half_hearts', value: 1 },
		},
	};

	const WEAPONS = {
		scratch_claws: { name: 'Scratch Claws', mode: 'rapid', cooldown: 0.14, damage: 1, speed: 260, spreadDeg: 6, pierce: 0, range: 220 },
		hairball_slingshot: { name: 'Hairball Slingshot', mode: 'lob', cooldown: 0.55, damage: 2, speed: 230, spreadDeg: 3, pierce: 0, range: 240, splash: 34 },
		rusty_forge_hammer: { name: 'Rusty Forge Hammer', mode: 'melee', cooldown: 0.85, damage: 3, meleeRange: 46, knockback: 260 },
		purr_wave: { name: 'Purr Wave', mode: 'rapid', cooldown: 0.32, damage: 1, speed: 200, spreadDeg: 4, pierce: 1, range: 210 },
	};

	const SKILLS = {
		fleet_paws: { name: 'Fleet Paws', type: 'speed_burst', cooldown: 9, duration: 2, multiplier: 1.6 },
		hairball_barrage: { name: 'Hairball Barrage', type: 'burst_fire', cooldown: 11, count: 5, spreadDeg: 55, damage: 2 },
		anvil_slam: { name: 'Anvil Slam', type: 'aoe_slam', cooldown: 10, damage: 5, radius: 70, windup: 0.45, knockback: 340 },
		purr_charm: { name: 'Purr Charm', type: 'heal_pulse', cooldown: 13, healHalfHearts: 2, radius: 90 },
	};

	// sprite: file under assets/sprites/. hp/speed/damage scale with biome order + local kill count.
	const ENEMIES = {
		grub: { name: 'Grub', sprite: 'enemy_grub', size: 22, baseHp: 3, speed: 60, contactDamage: 1, score: 10 },
		spitter: {
			name: 'Spitter', sprite: 'enemy_spitter', size: 22, baseHp: 4, speed: 28, contactDamage: 1, score: 15,
			telegraphTime: 0.8, bulletSpeed: 110, bulletDamage: 1, attackCooldown: 2.2, attackRange: 190,
		},
		mite: { name: 'Mite Swarm', sprite: 'enemy_mite', size: 16, baseHp: 1, speed: 130, contactDamage: 1, score: 5, packSize: 3 },
	};
	const BOSS = {
		sprite: 'enemy_boss', size: 56, baseHp: 40, speed: 42, contactDamage: 2, score: 200,
		slamCooldown: 3.0, slamTelegraph: 0.9, slamRadius: 60, slamDamage: 2, ringCount: 10, ringSpeed: 95,
	};

	// -------------------------------------------------------- HOUSE UPGRADES
	const UPGRADES = {
		tent: {
			name: 'Tent', track: 'Shelter', requires: null,
			cost: [{ species: 'sardine_rotten', rarity: 'Common', amount: 5 }],
			effect: 'unlock_checkpoints', desc: 'A cardboard tent — the bare minimum. Marks your respawn point.',
		},
		shack: {
			name: 'Shack', track: 'Shelter', requires: 'tent',
			cost: [{ species: 'mackerel_foul', rarity: 'Uncommon', amount: 3 }, { species: 'sardine_rotten', rarity: 'Common', amount: 2 }],
			effect: 'faster_respawn', desc: '+1 max heart on respawn (temporary buffer).',
		},
		cat_house: {
			name: 'Cat House', track: 'Shelter', requires: 'shack',
			cost: [{ species: 'tuna_mold', rarity: 'Rare', amount: 2 }, { species: 'mackerel_foul', rarity: 'Common', amount: 5 }],
			effect: 'checkpoint_50', desc: '+1 max heart, permanently, for every cat.',
		},
		smoker: {
			name: 'Smoker', track: 'Workshop', requires: 'tent',
			cost: [{ species: 'sardine_rotten', rarity: 'Uncommon', amount: 6 }],
			effect: 'unlock_smoker', desc: 'Convert 5 Common fish into 1 Uncommon of the same species, from the Vault.',
		},
		fish_safe: {
			name: 'Fish Safe', track: 'Workshop', requires: 'tent',
			cost: [{ species: 'tuna_mold', rarity: 'Rare', amount: 4 }],
			effect: 'fish_loss_reduction', desc: '+25% fish magnet radius, always on.',
		},
		window_perch: {
			name: 'Window Perch', track: 'Colony', requires: 'tent',
			cost: [{ species: 'sardine_rotten', rarity: 'Common', amount: 8 }],
			effect: 'amiibo_slot_2', desc: 'Unlocks your second Amiibo slot.',
		},
	};
	const TRACK_ORDER = ['Shelter', 'Workshop', 'Colony'];

	const BUFF_POOL = {
		warm_milk: { name: 'Warm Milk', desc: '+1 heart, right now.' },
		fish_magnet: { name: 'Fish Magnet', desc: '+30% fish pickup range.' },
		lucky_gut: { name: 'Lucky Gut', desc: 'Better odds at rare fish.' },
		second_wind: { name: 'Second Wind', desc: 'Revive once at 1 heart.' },
		piercing_claws: { name: 'Piercing Claws', desc: '+1 pierce on your primary.' },
	};

	// Kills needed in a biome before its guardian boss appears.
	const KILLS_TO_BOSS = 12;

	root.GameData = { CATS, WEAPONS, SKILLS, ENEMIES, BOSS, UPGRADES, TRACK_ORDER, BUFF_POOL, KILLS_TO_BOSS };
})(typeof window !== 'undefined' ? window : globalThis);
