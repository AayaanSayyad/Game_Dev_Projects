/* FishData — species x rarity fish system (design doc section 8). */
(function (root) {
	'use strict';

	const RARITIES = ['Common', 'Uncommon', 'Rare', 'Epic', 'Legendary'];
	const RARITY_COLOR = {
		Common: '#8fbf6a', Uncommon: '#5fc9c9', Rare: '#a97fe0', Epic: '#e8c565', Legendary: '#f28fc0',
	};
	const DROP_WEIGHTS_NORMAL = { Common: 0.70, Uncommon: 0.22, Rare: 0.06, Epic: 0.018, Legendary: 0.002 };
	const DROP_WEIGHTS_ELITE = { Common: 0.40, Uncommon: 0.35, Rare: 0.18, Epic: 0.05, Legendary: 0.02 };

	const SPECIES = {
		sardine_rotten: { name: 'Sardine', planets: ['litter_prime'], baseExp: 2, use: 'Basic EXP, early upgrades', active: true },
		mackerel_foul: { name: 'Mackerel', planets: ['litter_prime'], baseExp: 3, use: 'Forge tier 1', active: true },
		tuna_mold: { name: 'Tuna', planets: ['litter_prime', 'ring_of_yarn'], baseExp: 5, use: 'Ammo crafting', active: true },
		salmon_sour: { name: 'Salmon', planets: ['ring_of_yarn'], baseExp: 6, use: 'Healer Amiibo unlock', active: false },
		herring_haunt: { name: 'Herring', planets: ['ring_of_yarn'], baseExp: 6, use: 'Signal tower', active: false },
		squid_inked: { name: 'Squid', planets: ['ring_of_yarn', 'fishbone_nebula'], baseExp: 7, use: 'Mage gear', active: false },
		crab_old: { name: 'Crab', planets: ['fishbone_nebula'], baseExp: 8, use: 'Tank armor', active: false },
		eel_coil: { name: 'Eel', planets: ['fishbone_nebula'], baseExp: 8, use: 'Dash mods', active: false },
		lobster_red: { name: 'Lobster', planets: ['fishbone_nebula', 'hairball_core'], baseExp: 10, use: 'Epic house room', active: false },
		whale_bit: { name: 'Whale Bit', planets: ['hairball_core'], baseExp: 14, use: 'Legendary crafts', active: false },
		space_koi: { name: 'Space Koi', planets: ['any'], baseExp: 12, use: 'Epic substitute', active: false },
		void_anchovy: { name: 'Void Anchovy', planets: ['boss_only'], baseExp: 20, use: 'Planet unlock tokens', active: false },
	};

	function activeSpeciesForPlanet(planetId) {
		return Object.keys(SPECIES).filter((id) => {
			const s = SPECIES[id];
			return s.active && (s.planets.includes(planetId) || s.planets.includes('any'));
		});
	}

	function rarityMult(rarity) {
		return { Common: 1, Uncommon: 2, Rare: 5, Epic: 12, Legendary: 30 }[rarity] || 1;
	}

	function rollRarityOnce(isElite) {
		const table = isElite ? DROP_WEIGHTS_ELITE : DROP_WEIGHTS_NORMAL;
		const roll = Math.random();
		let acc = 0;
		for (const r of RARITIES) {
			acc += table[r];
			if (roll <= acc) return r;
		}
		return 'Common';
	}
	function rarityRank(r) { return RARITIES.indexOf(r); }

	// `lucky` re-rolls once and keeps the rarer result (Lucky Gut buff).
	function rollRarity(isElite, lucky) {
		const r1 = rollRarityOnce(isElite);
		if (!lucky) return r1;
		const r2 = rollRarityOnce(isElite);
		return rarityRank(r2) > rarityRank(r1) ? r2 : r1;
	}

	function rollSpecies(planetId) {
		const pool = activeSpeciesForPlanet(planetId);
		if (!pool.length) return 'sardine_rotten';
		return pool[Math.floor(Math.random() * pool.length)];
	}

	root.FishData = { RARITIES, RARITY_COLOR, SPECIES, activeSpeciesForPlanet, rarityMult, rollRarity, rollSpecies, rarityRank };
})(typeof window !== 'undefined' ? window : globalThis);
