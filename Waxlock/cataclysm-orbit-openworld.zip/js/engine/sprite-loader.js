/* Sprites — loads spritesheets/images and draws them crisp (no smoothing),
 * matching genuine pixel-art scaling instead of the browser's default blur.
 */
(function (root) {
	'use strict';

	const cache = {};
	let loadCount = 0, loadedCount = 0;

	function load(key, src) {
		loadCount++;
		const img = new Image();
		img.onload = () => { loadedCount++; };
		img.onerror = () => { loadedCount++; console.warn('Sprite failed to load:', src); };
		img.src = src;
		cache[key] = img;
		return img;
	}

	function get(key) { return cache[key]; }
	function allLoaded() { return loadedCount >= loadCount; }
	function progress() { return loadCount === 0 ? 1 : loadedCount / loadCount; }

	// Draw one tile from a sheet (tileSize px source cells) at (dx,dy) world
	// coords, drawn at `size` px (defaults to tileSize, i.e. 1:1).
	function drawTile(ctx, sheetKey, index, cols, tileSize, dx, dy, size) {
		const img = cache[sheetKey];
		if (!img || !img.complete || img.naturalWidth === 0) return;
		size = size || tileSize;
		const sx = (index % cols) * tileSize;
		const sy = Math.floor(index / cols) * tileSize;
		ctx.drawImage(img, sx, sy, tileSize, tileSize, Math.round(dx), Math.round(dy), size, size);
	}

	// Draw a whole standalone sprite image (e.g. an enemy or cat frame).
	function drawSprite(ctx, key, dx, dy, w, h, flip) {
		const img = cache[key];
		if (!img || !img.complete || img.naturalWidth === 0) return;
		if (flip) {
			ctx.save();
			ctx.translate(Math.round(dx) + w, Math.round(dy));
			ctx.scale(-1, 1);
			ctx.drawImage(img, 0, 0, w, h);
			ctx.restore();
		} else {
			ctx.drawImage(img, Math.round(dx), Math.round(dy), w, h);
		}
	}

	root.Sprites = { load, get, allLoaded, progress, drawTile, drawSprite };
})(typeof window !== 'undefined' ? window : globalThis);
