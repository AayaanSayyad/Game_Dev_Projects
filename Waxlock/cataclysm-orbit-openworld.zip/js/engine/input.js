/* Input — keyboard + mouse state, canvas-space mouse coords for aiming. */
(function (root) {
	'use strict';

	const keys = {};
	const justPressed = {};
	const mouse = { x: 0, y: 0, down: false, justDown: false };
	let canvasEl = null;

	function code(e) { return e.code || e.key; }

	function onKeyDown(e) {
		const c = code(e);
		if (!keys[c]) justPressed[c] = true;
		keys[c] = true;
		if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(c)) e.preventDefault();
	}
	function onKeyUp(e) { keys[code(e)] = false; }

	function updateMouseFromEvent(e) {
		if (!canvasEl) return;
		const rect = canvasEl.getBoundingClientRect();
		const scaleX = canvasEl.width / rect.width;
		const scaleY = canvasEl.height / rect.height;
		mouse.x = (e.clientX - rect.left) * scaleX;
		mouse.y = (e.clientY - rect.top) * scaleY;
	}

	function bind(canvas) {
		canvasEl = canvas;
		window.addEventListener('keydown', onKeyDown);
		window.addEventListener('keyup', onKeyUp);
		window.addEventListener('mousemove', updateMouseFromEvent);
		canvas.addEventListener('mousedown', (e) => { updateMouseFromEvent(e); mouse.down = true; mouse.justDown = true; });
		window.addEventListener('mouseup', () => { mouse.down = false; });
		canvas.addEventListener('contextmenu', (e) => e.preventDefault());
	}

	function isDown(c) { return !!keys[c]; }
	function wasPressed(c) { return !!justPressed[c]; }
	function anyPressed(codes) { return codes.some((c) => keys[c]); }
	function anyJustPressed(codes) { return codes.some((c) => justPressed[c]); }

	function moveVector() {
		let x = 0, y = 0;
		if (anyPressed(['KeyA', 'ArrowLeft'])) x -= 1;
		if (anyPressed(['KeyD', 'ArrowRight'])) x += 1;
		if (anyPressed(['KeyW', 'ArrowUp'])) y -= 1;
		if (anyPressed(['KeyS', 'ArrowDown'])) y += 1;
		const len = Math.hypot(x, y) || 1;
		return { x: x / len * (x || y ? 1 : 0), y: y / len * (x || y ? 1 : 0), raw: { x, y } };
	}

	function endFrame() {
		for (const k in justPressed) justPressed[k] = false;
		mouse.justDown = false;
	}

	root.Input = { bind, isDown, wasPressed, anyPressed, anyJustPressed, moveVector, endFrame, mouse, keys };
})(typeof window !== 'undefined' ? window : globalThis);
