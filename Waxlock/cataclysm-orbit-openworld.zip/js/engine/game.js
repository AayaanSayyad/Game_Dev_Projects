/* Game — scene manager + main loop. Loads all sprite/tile assets up front
 * and disables image smoothing everywhere so pixel art stays crisp at any
 * scale (the single most important line for "this looks like real pixel
 * art" vs "blurry upscaled PNGs").
 */
(function (root) {
	'use strict';

	const Game = {
		canvas: null, ctx: null, W: 960, H: 600,
		scenes: {}, current: null, currentName: null,
		lastTime: 0, t: 0, uiLayer: null, ready: false,

		registerScene(name, scene) { this.scenes[name] = scene; },

		init() {
			this.canvas = document.getElementById('game-canvas');
			this.canvas.width = this.W;
			this.canvas.height = this.H;
			this.ctx = this.canvas.getContext('2d');
			this.ctx.imageSmoothingEnabled = false;
			this.uiLayer = document.getElementById('ui-layer');
			this.resize();
			window.addEventListener('resize', () => this.resize());
			Input.bind(this.canvas);
			AudioMgr.init();
			GameState.load();
			this._preload();
			requestAnimationFrame((ts) => this.loop(ts));
		},

		_preload() {
			Sprites.load('tiles_town', 'assets/tiles/town_sheet.png');
			Sprites.load('tiles_dungeon', 'assets/tiles/dungeon_sheet.png');
			Sprites.load('tiles_battle', 'assets/tiles/battle_sheet.png');
			['stray', 'brick', 'soot', 'miso'].forEach((cat) => {
				['down_0', 'down_1', 'up_0', 'up_1', 'side_0', 'side_1'].forEach((frame) => {
					Sprites.load(`cat_${cat}_${frame}`, `assets/sprites/cat_${cat}_${frame}.png`);
				});
			});
			['grub', 'spitter', 'mite', 'boss'].forEach((id) => {
				Sprites.load(`enemy_${id}`, `assets/sprites/enemy_${id}.png`);
			});
			['common', 'uncommon', 'rare', 'epic', 'legendary'].forEach((r) => {
				Sprites.load(`fish_${r}`, `assets/sprites/fish_${r}.png`);
			});
			Sprites.load('house_icon', 'assets/sprites/house_icon.png');
		},

		resize() {
			const viewport = document.getElementById('viewport');
			const targetAspect = this.W / this.H;
			const winW = window.innerWidth, winH = window.innerHeight;
			let w = winW, h = winW / targetAspect;
			if (h > winH) { h = winH; w = winH * targetAspect; }
			viewport.style.width = Math.floor(w) + 'px';
			viewport.style.height = Math.floor(h) + 'px';
		},

		goto(name, ...args) {
			if (this.current && this.current.exit) this.current.exit();
			this.uiLayer.innerHTML = '';
			this.currentName = name;
			this.current = this.scenes[name];
			if (this.current && this.current.enter) this.current.enter(...args);
		},

		loop(now) {
			const dt = Math.min(0.05, (now - this.lastTime) / 1000 || 0);
			this.lastTime = now;

			if (!this.ready) {
				this.ctx.imageSmoothingEnabled = false;
				this._drawLoading();
				if (Sprites.allLoaded()) { this.ready = true; this.goto('start'); }
				requestAnimationFrame((ts) => this.loop(ts));
				return;
			}

			this.t += dt;
			if (this.current && this.current.update) this.current.update(dt, this.t);
			this.ctx.clearRect(0, 0, this.W, this.H);
			this.ctx.imageSmoothingEnabled = false;
			if (this.current && this.current.render) this.current.render(this.ctx, this.t);
			Input.endFrame();
			requestAnimationFrame((ts) => this.loop(ts));
		},

		_drawLoading() {
			const ctx = this.ctx;
			ctx.fillStyle = '#141024'; ctx.fillRect(0, 0, this.W, this.H);
			ctx.fillStyle = '#ffe6ae'; ctx.font = '20px monospace'; ctx.textAlign = 'center';
			ctx.fillText('Loading...', this.W / 2, this.H / 2);
			const p = Sprites.progress();
			ctx.strokeStyle = '#ffe6ae'; ctx.strokeRect(this.W / 2 - 100, this.H / 2 + 16, 200, 10);
			ctx.fillRect(this.W / 2 - 100, this.H / 2 + 16, 200 * p, 10);
		},

		el(tag, className, parent) {
			const e = document.createElement(tag);
			if (className) e.className = className;
			(parent || this.uiLayer).appendChild(e);
			return e;
		},
	};

	root.Game = Game;
})(typeof window !== 'undefined' ? window : globalThis);
