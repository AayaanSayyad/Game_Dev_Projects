/* GameState — persistent + session state, saved to localStorage.
 *
 * Bug-fix note: in the previous build, fish went player -> run satchel ->
 * (deposit on death/retreat) -> vault, and EXP conversion only ever read
 * the vault. In open-world play there's no clean "run boundary" to deposit
 * on, so that intermediate step was fragile. Fish now go straight into the
 * vault the moment they're collected — one less place for the pipeline to
 * silently drop them.
 */
(function (root) {
	'use strict';
	const FD = root.FishData, GD = root.GameData;
	const SAVE_KEY = 'cataclysm_orbit_world_save_v1';

	function freshState() {
		const vault = {};
		Object.keys(FD.SPECIES).forEach((id) => { vault[id] = {}; });
		const biomeProgress = {};
		root.BiomeData.BIOME_ORDER.forEach((id) => { biomeProgress[id] = { kills: 0, bossSpawned: false, bossDefeated: false }; });
		return {
			vaultFish: vault,
			accountExp: 0,
			houseUpgrades: [],
			rosterUnlocked: ['stray'],
			selectedCat: 'stray',
			amiiboIds: [null, null],
			biomeProgress,
			unlockedBiomes: ['litter_fields'],
			settings: { screenShake: true, musicOn: true, sfxOn: true },
			lastUnlocked: [],
			totalKills: 0,
			mapSeed: Math.floor(Math.random() * 1e9),
		};
	}

	const S = {
		data: freshState(),
		heartsCurrent: 6, heartsMax: 6,
		activeBuffs: [], secondWindUsed: false,
		listeners: {},

		on(evt, fn) { (this.listeners[evt] = this.listeners[evt] || []).push(fn); },
		emit(evt, ...args) { (this.listeners[evt] || []).forEach((fn) => fn(...args)); },

		load() {
			try {
				const raw = localStorage.getItem(SAVE_KEY);
				if (raw) {
					const parsed = JSON.parse(raw);
					const fresh = freshState();
					this.data = Object.assign(fresh, parsed);
					this.data.settings = Object.assign(fresh.settings, parsed.settings || {});
					this.data.biomeProgress = Object.assign(fresh.biomeProgress, parsed.biomeProgress || {});
					if (!this.data.mapSeed) this.data.mapSeed = fresh.mapSeed;
				}
			} catch (e) { console.warn('GameState.load failed', e); }
		},
		save() {
			try { localStorage.setItem(SAVE_KEY, JSON.stringify(this.data)); } catch (e) { console.warn('GameState.save failed', e); }
		},

		// ------------------------------------------------------- VAULT / FISH
		addFish(species, rarity, amount) {
			amount = amount || 1;
			this.data.vaultFish[species] = this.data.vaultFish[species] || {};
			this.data.vaultFish[species][rarity] = (this.data.vaultFish[species][rarity] || 0) + amount;
			this.save();
			this.emit('fishChanged');
		},
		vaultCount(species, rarity) { return (this.data.vaultFish[species] || {})[rarity] || 0; },
		vaultTotal() {
			let t = 0;
			Object.values(this.data.vaultFish).forEach((sp) => Object.values(sp).forEach((n) => (t += n)));
			return t;
		},
		convertVaultToExp() {
			let gained = 0;
			Object.keys(this.data.vaultFish).forEach((species) => {
				Object.keys(this.data.vaultFish[species]).forEach((r) => {
					const n = this.data.vaultFish[species][r];
					if (n <= 0) return;
					gained += Math.round(n * FD.SPECIES[species].baseExp * FD.rarityMult(r));
					this.data.vaultFish[species][r] = 0;
				});
			});
			this.data.accountExp += gained;
			this.save();
			return gained;
		},
		smokeConvert(species) {
			if (this.vaultCount(species, 'Common') < 5) return false;
			this.data.vaultFish[species].Common -= 5;
			this.data.vaultFish[species].Uncommon = (this.data.vaultFish[species].Uncommon || 0) + 1;
			this.save();
			return true;
		},

		// -------------------------------------------------------- UPGRADES
		hasUpgrade(id) { return this.data.houseUpgrades.includes(id); },
		canAfford(id) {
			const u = GD.UPGRADES[id];
			if (!u || this.hasUpgrade(id)) return false;
			if (u.requires && !this.hasUpgrade(u.requires)) return false;
			return u.cost.every((line) => this.vaultCount(line.species, line.rarity) >= line.amount);
		},
		purchaseUpgrade(id) {
			if (!this.canAfford(id)) return false;
			const u = GD.UPGRADES[id];
			u.cost.forEach((line) => { this.data.vaultFish[line.species][line.rarity] -= line.amount; });
			this.data.houseUpgrades.push(id);
			this.emit('upgradePurchased', id);
			this.save();
			return true;
		},
		amiiboSlotCap() { return this.hasUpgrade('window_perch') ? 2 : 1; },
		maxHeartsBonus() {
			let bonus = 0;
			if (this.hasUpgrade('shack')) bonus += 2;
			if (this.hasUpgrade('cat_house')) bonus += 2;
			return bonus;
		},
		pickupRangeBonus() { return this.hasUpgrade('fish_safe') ? 0.25 : 0; },

		// ---------------------------------------------------------- ROSTER
		checkRosterUnlocks() {
			const newly = [];
			Object.keys(GD.CATS).forEach((id) => {
				const need = GD.CATS[id].unlockBiome;
				const unlocked = need === null || this.data.unlockedBiomes.includes(need);
				if (unlocked && !this.data.rosterUnlocked.includes(id)) {
					this.data.rosterUnlocked.push(id);
					newly.push(id);
				}
			});
			if (newly.length) { this.data.lastUnlocked.push(...newly); this.save(); }
			return newly;
		},

		// -------------------------------------------------------- BIOMES
		isUnlocked(biomeId) { return this.data.unlockedBiomes.includes(biomeId); },
		registerKill(biomeId) {
			if (!this.data.biomeProgress[biomeId]) return;
			this.data.totalKills++;
			const p = this.data.biomeProgress[biomeId];
			if (!p.bossSpawned) p.kills++;
			this.save();
		},
		bossReadyToSpawn(biomeId) {
			const p = this.data.biomeProgress[biomeId];
			return p && !p.bossSpawned && !p.bossDefeated && p.kills >= GD.KILLS_TO_BOSS;
		},
		markBossSpawned(biomeId) { this.data.biomeProgress[biomeId].bossSpawned = true; this.save(); },
		defeatBoss(biomeId) {
			this.data.biomeProgress[biomeId].bossDefeated = true;
			const idx = root.BiomeData.BIOME_ORDER.indexOf(biomeId);
			const next = root.BiomeData.BIOME_ORDER[idx + 1];
			let unlockedNext = null;
			if (next && !this.data.unlockedBiomes.includes(next)) {
				this.data.unlockedBiomes.push(next);
				unlockedNext = next;
			}
			this.checkRosterUnlocks();
			this.save();
			return unlockedNext;
		},

		// --------------------------------------------------------- HEARTS
		startSession(catId, amiiboIds) {
			this.data.selectedCat = catId;
			this.data.amiiboIds = amiiboIds.slice();
			const cat = GD.CATS[catId];
			let maxHp = cat.maxHp + this.maxHeartsBonus();
			amiiboIds.forEach((id) => {
				if (id && GD.CATS[id].amiibo.key === 'bonus_half_hearts') maxHp += GD.CATS[id].amiibo.value;
			});
			this.heartsMax = maxHp;
			this.heartsCurrent = maxHp;
			this.activeBuffs = [];
			this.secondWindUsed = false;
			this.save();
		},
		amiiboPassiveValue(key) {
			let total = 0;
			this.data.amiiboIds.forEach((id) => {
				if (id && GD.CATS[id].amiibo.key === key) total += GD.CATS[id].amiibo.value;
			});
			return total;
		},
		takeDamage(halfHearts) {
			this.heartsCurrent = Math.max(0, this.heartsCurrent - halfHearts);
			this.emit('heartsChanged', this.heartsCurrent, this.heartsMax);
		},
		heal(halfHearts) {
			this.heartsCurrent = Math.min(this.heartsMax, this.heartsCurrent + halfHearts);
			this.emit('heartsChanged', this.heartsCurrent, this.heartsMax);
		},
		fullHeal() { this.heartsCurrent = this.heartsMax; this.emit('heartsChanged', this.heartsCurrent, this.heartsMax); },

		hasBuff(id) { return this.activeBuffs.includes(id); },
		applyBuff(id) {
			if (this.activeBuffs.includes(id)) return;
			this.activeBuffs.push(id);
			if (id === 'warm_milk') { this.heartsMax += 2; this.heal(2); }
		},
		buffPickupRangeBonus() { return this.hasBuff('fish_magnet') ? 0.30 : 0; },
		buffPierceBonus() { return this.hasBuff('piercing_claws') ? 1 : 0; },
		buffLuckyGut() { return this.hasBuff('lucky_gut'); },
	};

	root.GameState = S;
})(typeof window !== 'undefined' ? window : globalThis);
