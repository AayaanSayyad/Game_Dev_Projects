/* AudioMgr — small SFX pool + music player wrapper around HTMLAudioElement. */
(function (root) {
	'use strict';

	const SFX_FILES = {
		hit: 'sfx_hit.wav', splat: 'sfx_splat.wav', pickup_common: 'sfx_pickup_common.wav',
		pickup_uncommon: 'sfx_pickup_uncommon.wav', pickup_rare: 'sfx_pickup_rare.wav', dash: 'sfx_dash.wav',
		wave_clear: 'sfx_wave_clear.wav', milestone: 'sfx_milestone.wav', player_hurt: 'sfx_player_hurt.wav',
		purchase: 'sfx_purchase.wav', death: 'sfx_death.wav', skill: 'sfx_skill.wav',
		ui_move: 'sfx_ui_move.wav', ui_confirm: 'sfx_ui_confirm.wav', telegraph: 'sfx_telegraph.wav',
	};
	const MUSIC_FILES = { house: 'music_house_loop.wav', combat: 'music_combat_loop.wav' };
	const BASE = 'assets/audio/';
	const POOL_SIZE = 6;

	const pools = {};
	let musicEl = null, currentMusicKey = null;
	let enabled = { sfx: true, music: true };

	function init() {
		Object.keys(SFX_FILES).forEach((key) => {
			pools[key] = [];
			for (let i = 0; i < POOL_SIZE; i++) {
				const a = new Audio(BASE + SFX_FILES[key]);
				a.preload = 'auto';
				pools[key].push(a);
			}
		});
		musicEl = new Audio();
		musicEl.loop = true;
		musicEl.volume = 0.35;
	}

	let poolIdx = {};
	function playSfx(key, pitch, volume) {
		if (!enabled.sfx || !pools[key]) return;
		poolIdx[key] = ((poolIdx[key] || 0) + 1) % POOL_SIZE;
		const a = pools[key][poolIdx[key]];
		try {
			a.currentTime = 0;
			a.playbackRate = pitch || 1.0;
			a.volume = volume === undefined ? 0.6 : volume;
			a.play().catch(() => {});
		} catch (e) { /* ignore autoplay-block errors */ }
	}

	function playMusic(key) {
		if (currentMusicKey === key) return;
		currentMusicKey = key;
		musicEl.src = BASE + MUSIC_FILES[key];
		if (enabled.music) musicEl.play().catch(() => {});
	}
	function stopMusic() { musicEl.pause(); currentMusicKey = null; }
	function setEnabled(sfx, music) {
		enabled.sfx = sfx; enabled.music = music;
		if (!music) musicEl.pause();
		else if (currentMusicKey) musicEl.play().catch(() => {});
	}

	root.AudioMgr = { init, playSfx, playMusic, stopMusic, setEnabled };
})(typeof window !== 'undefined' ? window : globalThis);
