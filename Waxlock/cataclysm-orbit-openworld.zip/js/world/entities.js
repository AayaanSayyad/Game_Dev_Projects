/* WorldEntities — Player/Enemy/Bullet/FishPickup for the open world.
 *
 * Bug-fix note: the previous build only ever damaged the player through
 * Bullet collisions. Melee enemies (Grub, Mite) never had any code path
 * that dealt contact damage at all — touching the player did nothing.
 * Enemy.update() below now explicitly checks proximity-to-player for
 * melee-type enemies every frame and calls player.takeHit() directly; see
 * the "CONTACT DAMAGE" block.
 */
(function (root) {
	'use strict';
	const GD = root.GameData, FD = root.FishData, TM = root.TileMapMod;

	function dist(a, b) { return Math.hypot(a.x - b.x, a.y - b.y); }
	function normalize(v) { const l = Math.hypot(v.x, v.y) || 1; return { x: v.x / l, y: v.y / l }; }
	function moveToward(cur, target, maxDelta) {
		if (Math.abs(target - cur) <= maxDelta) return target;
		return cur + Math.sign(target - cur) * maxDelta;
	}
	function rotate(v, ang) { const c = Math.cos(ang), s = Math.sin(ang); return { x: v.x * c - v.y * s, y: v.x * s + v.y * c }; }

	// ============================================================== PLAYER
	class Player {
		constructor(catId, world) {
			this.world = world;
			this.catId = catId;
			this.cat = GD.CATS[catId];
			this.weapon = GD.WEAPONS[this.cat.weapon];
			this.skill = GD.SKILLS[this.cat.skill];
			const spawn = world.map.spawnWorldPos();
			this.pos = { x: spawn.x, y: spawn.y + 40 };
			this.vel = { x: 0, y: 0 };
			this.radius = 9;
			this.moveSpeed = this.cat.moveSpeed * (1 + GameState.amiiboPassiveValue('move_speed_pct'));
			this.facing = 'down'; this.flip = false;
			this.animT = 0;
			this.dashing = false; this.dashT = 0; this.dashCd = 0;
			this.fireCd = 0; this.skillCd = 0; this.skillMult = 1; this.skillMultT = 0;
			this.invulnT = 1.0; // brief spawn grace
			this.alive = true;
			this.meleeSwingT = 0;
			this.frozen = false;
		}
		dashCooldownFrac() { return Math.max(0, this.dashCd / this.cat.dashCooldown); }
		skillCooldownFrac() { return Math.max(0, this.skillCd / this.skill.cooldown); }
		isInvuln() { return this.invulnT > 0; }

		update(dt) {
			if (!this.alive) return;
			this.dashCd = Math.max(0, this.dashCd - dt);
			this.skillCd = Math.max(0, this.skillCd - dt);
			this.fireCd = Math.max(0, this.fireCd - dt);
			this.invulnT = Math.max(0, this.invulnT - dt);
			if (this.skillMultT > 0) { this.skillMultT -= dt; if (this.skillMultT <= 0) this.skillMult = 1; }
			if (this.meleeSwingT > 0) this.meleeSwingT -= dt;

			if (this.frozen) { this.vel = { x: 0, y: 0 }; return; }

			const mv = Input.moveVector();
			const worldMouse = this.world.screenToWorld(Input.mouse.x, Input.mouse.y);
			const aim = normalize({ x: worldMouse.x - this.pos.x, y: worldMouse.y - this.pos.y });
			this.aim = aim;

			if (Math.abs(aim.x) > Math.abs(aim.y)) { this.facing = 'side'; this.flip = aim.x < 0; }
			else { this.facing = aim.y < 0 ? 'up' : 'down'; }

			if (Input.anyJustPressed(['ShiftLeft', 'ShiftRight']) && this.dashCd <= 0 && !this.dashing) this.startDash(mv, aim);

			const moving = mv.x !== 0 || mv.y !== 0;
			if (this.dashing) {
				this.dashT -= dt;
				if (this.dashT <= 0) this.dashing = false;
			} else {
				const target = { x: mv.x * this.moveSpeed * this.skillMult, y: mv.y * this.moveSpeed * this.skillMult };
				const accel = moving ? this.cat.accel : this.cat.friction;
				this.vel.x = moveToward(this.vel.x, target.x, accel * dt);
				this.vel.y = moveToward(this.vel.y, target.y, accel * dt);
			}
			if (moving || this.dashing) this.animT += dt * (this.dashing ? 16 : 8);

			const nx = this.pos.x + this.vel.x * dt, ny = this.pos.y + this.vel.y * dt;
			const resolved = this.world.map.resolveCollision(nx, ny, this.radius);
			this.pos.x = resolved.x; this.pos.y = resolved.y;
			this.world.enforceBiomeLock(this, this.cat.weight);

			if (Input.mouse.down || Input.isDown('Space')) this.handleFire(dt, aim);
			if (Input.anyJustPressed(['KeyE']) && this.skillCd <= 0) this.useSkill(aim);
		}

		startDash(mv, aim) {
			const dir = (mv.x || mv.y) ? normalize(mv) : aim;
			this.dashing = true; this.dashT = this.cat.dashTime; this.dashCd = this.cat.dashCooldown;
			this.invulnT = Math.max(this.invulnT, this.cat.dashIframes);
			this.vel = { x: dir.x * this.cat.dashSpeed, y: dir.y * this.cat.dashSpeed };
			AudioMgr.playSfx('dash', 1, 0.5);
		}

		handleFire(dt, aim) {
			if (this.fireCd > 0) return;
			this.fireCd = this.weapon.cooldown;
			switch (this.weapon.mode) {
				case 'rapid': this.fireProjectile(aim); break;
				case 'lob': this.fireLob(aim); break;
				case 'melee': this.fireMelee(); break;
			}
		}
		fireProjectile(aim) {
			const spread = (Math.random() * 2 - 1) * (this.weapon.spreadDeg * Math.PI / 180);
			const d = rotate(aim, spread);
			this.world.spawnBullet(this.pos.x + aim.x * 12, this.pos.y + aim.y * 12, d, this.weapon.speed,
				this.weapon.damage, true, 'player', this.weapon.pierce + GameState.amiiboPassiveValue('pierce_add') + GameState.buffPierceBonus(), this.weapon.range);
		}
		fireLob(aim) {
			const spread = (Math.random() * 2 - 1) * (this.weapon.spreadDeg * Math.PI / 180);
			const d = rotate(aim, spread);
			const b = this.world.spawnBullet(this.pos.x + aim.x * 12, this.pos.y + aim.y * 12, d, this.weapon.speed, this.weapon.damage, true, 'lob', 0, this.weapon.range);
			b.lob = true; b.splash = this.weapon.splash;
		}
		fireMelee() {
			this.meleeSwingT = 0.14;
			AudioMgr.playSfx('hit', 0.85, 0.35);
			const origin = { x: this.pos.x + this.aim.x * this.weapon.meleeRange * 0.5, y: this.pos.y + this.aim.y * this.weapon.meleeRange * 0.5 };
			this.world.enemies.forEach((e) => {
				if (!e.alive) return;
				if (dist(origin, e.pos) <= this.weapon.meleeRange * 0.65) {
					const kdir = normalize({ x: e.pos.x - this.pos.x, y: e.pos.y - this.pos.y });
					e.takeHit(this.weapon.damage, kdir);
					e.knock(kdir, this.weapon.knockback);
				}
			});
		}
		useSkill(aim) {
			this.skillCd = this.skill.cooldown;
			AudioMgr.playSfx('skill', 1, 0.55);
			switch (this.skill.type) {
				case 'speed_burst': this.skillMult = this.skill.multiplier; this.skillMultT = this.skill.duration; break;
				case 'burst_fire': {
					const spread = this.skill.spreadDeg * Math.PI / 180;
					for (let i = 0; i < this.skill.count; i++) {
						const frac = (this.skill.count === 1) ? 0 : (i / (this.skill.count - 1)) - 0.5;
						const d = rotate(aim, frac * spread);
						const b = this.world.spawnBullet(this.pos.x + aim.x * 12, this.pos.y + aim.y * 12, d, this.weapon.speed, this.skill.damage, true, 'lob', 0, this.weapon.range || 260);
						b.lob = true; b.splash = this.weapon.splash || 34;
					}
					break;
				}
				case 'aoe_slam': {
					const cx = this.pos.x, cy = this.pos.y;
					this.world.spawnTelegraph(cx, cy, this.skill.radius, this.skill.windup, '#ffb35a');
					setTimeout(() => {
						if (!this.alive) return;
						this.world.enemies.forEach((e) => {
							if (!e.alive) return;
							if (dist({ x: cx, y: cy }, e.pos) <= this.skill.radius) {
								const kdir = normalize({ x: e.pos.x - cx, y: e.pos.y - cy });
								e.takeHit(this.skill.damage, kdir);
								e.knock(kdir, this.skill.knockback);
							}
						});
						AudioMgr.playSfx('hit', 0.6, 0.6);
					}, this.skill.windup * 1000);
					break;
				}
				case 'heal_pulse':
					GameState.heal(this.skill.healHalfHearts);
					this.world.spawnPulse(this.pos.x, this.pos.y, this.skill.radius, '#ff9fae');
					break;
			}
		}

		takeHit(halfHearts, dir) {
			if (!this.alive || this.isInvuln()) return;
			this.invulnT = 0.6;
			GameState.takeDamage(halfHearts);
			this.vel.x += dir.x * 220 / this.cat.weight;
			this.vel.y += dir.y * 220 / this.cat.weight;
			AudioMgr.playSfx('player_hurt', 1, 0.5);
			this.world.shake(3, 0.14);
			if (GameState.heartsCurrent <= 0) {
				if (GameState.hasBuff('second_wind') && !GameState.secondWindUsed) {
					GameState.secondWindUsed = true;
					GameState.heartsCurrent = 2;
					GameState.emit('heartsChanged', 2, GameState.heartsMax);
					AudioMgr.playSfx('milestone');
					return;
				}
				this.die();
			}
		}
		die() {
			if (!this.alive) return;
			this.alive = false;
			AudioMgr.playSfx('death');
			this.world.onPlayerDied();
		}
		spriteKey() {
			const frame = Math.floor(this.animT) % 2;
			return `cat_${this.catId}_${this.facing}_${frame}`;
		}
		render(ctx, screenX, screenY) {
			const size = 44;
			if (this.meleeSwingT > 0 && this.weapon.mode === 'melee') {
				ctx.save();
				ctx.strokeStyle = 'rgba(255,255,255,0.5)'; ctx.lineWidth = 3;
				ctx.beginPath(); ctx.arc(screenX, screenY, this.weapon.meleeRange * 0.65, 0, Math.PI * 2); ctx.stroke();
				ctx.restore();
			}
			ctx.save();
			if (this.invulnT > 0) ctx.globalAlpha = 0.55 + 0.35 * Math.abs(Math.sin(performance.now() / 60));
			Sprites.drawSprite(ctx, this.spriteKey(), screenX - size / 2, screenY - size / 2 - 6, size, size, this.flip);
			ctx.restore();
		}
	}

	// ============================================================= ENEMIES
	const MELEE_TYPES = new Set(['grub', 'mite']);
	const CONTACT_COOLDOWN = 0.7;

	class Enemy {
		constructor(type, x, y, hpMult, world, isBoss) {
			this.type = type;
			this.isBoss = !!isBoss;
			this.data = isBoss ? GD.BOSS : GD.ENEMIES[type];
			this.world = world;
			this.pos = { x, y };
			this.maxHp = Math.ceil(this.data.baseHp * hpMult);
			this.hp = this.maxHp;
			this.speed = this.data.speed;
			this.alive = true;
			this.flash = 0;
			this.knockVel = { x: 0, y: 0 };
			this.attackCd = type === 'spitter' ? Math.random() * this.data.attackCooldown : (isBoss ? 1.4 : 0);
			this._contactCd = 0;
			this.telegraphing = false; this.telegraphT = 0;
			this.nextIsSlam = true;
			this.t = Math.random() * 10;
			this.radius = this.data.size / 2;
			this.flip = false;
		}
		knock(dir, force) { this.knockVel.x += dir.x * force; this.knockVel.y += dir.y * force; }
		takeHit(dmg, dir) {
			if (!this.alive) return;
			this.hp -= dmg;
			this.flash = 1;
			this.knock(dir, 55);
			if (this.hp <= 0) this.die();
		}
		die() {
			if (!this.alive) return;
			this.alive = false;
			AudioMgr.playSfx('splat', 0.9 + Math.random() * 0.2, 0.5);
			this.world.onEnemyDied(this);
		}
		update(dt, player) {
			if (!this.alive) return;
			this.t += dt;
			this.flash = Math.max(0, this.flash - dt * 6);
			this._contactCd = Math.max(0, this._contactCd - dt);
			this.knockVel.x = moveToward(this.knockVel.x, 0, 400 * dt);
			this.knockVel.y = moveToward(this.knockVel.y, 0, 400 * dt);
			let desired = { x: 0, y: 0 };
			const toPlayer = normalize({ x: player.pos.x - this.pos.x, y: player.pos.y - this.pos.y });
			const d = dist(this.pos, player.pos);
			if (toPlayer.x !== 0) this.flip = toPlayer.x < 0;

			if (this.isBoss) {
				if (this.telegraphing) {
					this.telegraphT -= dt;
					if (this.telegraphT <= 0) this.executeBossAttack(player);
				} else {
					if (d > 50) desired = { x: toPlayer.x * this.speed, y: toPlayer.y * this.speed };
					this.attackCd -= dt;
					if (this.attackCd <= 0) { this.telegraphing = true; this.telegraphT = this.data.slamTelegraph; AudioMgr.playSfx('telegraph', 0.7, 0.3); }
				}
			} else if (this.type === 'spitter') {
				if (this.telegraphing) {
					this.telegraphT -= dt;
					if (this.telegraphT <= 0) this.fireSpitter(player);
				} else {
					if (d > this.data.attackRange) desired = { x: toPlayer.x * this.speed, y: toPlayer.y * this.speed };
					else if (d < this.data.attackRange * 0.5) desired = { x: -toPlayer.x * this.speed * 0.6, y: -toPlayer.y * this.speed * 0.6 };
					this.attackCd -= dt;
					if (this.attackCd <= 0 && d <= this.data.attackRange * 1.3) { this.telegraphing = true; this.telegraphT = this.data.telegraphTime; AudioMgr.playSfx('telegraph', 1, 0.25); }
				}
			} else {
				// grub, mite: straight chase
				desired = { x: toPlayer.x * this.speed, y: toPlayer.y * this.speed };
			}

			const nx = this.pos.x + (desired.x + this.knockVel.x) * dt;
			const ny = this.pos.y + (desired.y + this.knockVel.y) * dt;
			const resolved = this.world.map.resolveCollision(nx, ny, this.radius);
			this.pos.x = resolved.x; this.pos.y = resolved.y;

			// ---- CONTACT DAMAGE (fixed: previously missing entirely for
			// melee enemies — see file header) ----
			if (MELEE_TYPES.has(this.type) && this._contactCd <= 0) {
				if (dist(this.pos, player.pos) <= this.radius + player.radius) {
					player.takeHit(this.data.contactDamage, normalize({ x: player.pos.x - this.pos.x, y: player.pos.y - this.pos.y }));
					this._contactCd = CONTACT_COOLDOWN;
				}
			}
		}
		fireSpitter(player) {
			this.telegraphing = false;
			this.attackCd = this.data.attackCooldown;
			const dir = normalize({ x: player.pos.x - this.pos.x, y: player.pos.y - this.pos.y });
			this.world.spawnBullet(this.pos.x, this.pos.y, dir, this.data.bulletSpeed, this.data.bulletDamage, false, 'enemy', 0, 420);
		}
		executeBossAttack(player) {
			this.telegraphing = false;
			this.attackCd = this.data.slamCooldown;
			if (this.nextIsSlam) {
				if (dist(this.pos, player.pos) <= this.data.slamRadius) {
					const dir = normalize({ x: player.pos.x - this.pos.x, y: player.pos.y - this.pos.y });
					player.takeHit(this.data.slamDamage, dir);
				}
				AudioMgr.playSfx('hit', 0.6, 0.5);
			} else {
				for (let i = 0; i < this.data.ringCount; i++) {
					const ang = (Math.PI * 2 * i) / this.data.ringCount;
					this.world.spawnBullet(this.pos.x, this.pos.y, { x: Math.cos(ang), y: Math.sin(ang) }, this.data.ringSpeed, 1, false, 'enemy', 0, 400);
				}
			}
			this.nextIsSlam = !this.nextIsSlam;
		}
		render(ctx, screenX, screenY) {
			const size = this.data.size;
			if (this.telegraphing) {
				const frac = 1 - Math.max(0, this.telegraphT) / (this.isBoss ? this.data.slamTelegraph : this.data.telegraphTime);
				if (!this.isBoss || this.nextIsSlam) {
					ctx.save();
					ctx.strokeStyle = `rgba(255,96,96,${0.35 + 0.45 * frac})`; ctx.lineWidth = 2.5;
					const r = this.isBoss ? this.data.slamRadius : 20;
					ctx.beginPath(); ctx.arc(screenX, screenY, r * frac, 0, Math.PI * 2); ctx.stroke();
					ctx.restore();
				}
			}
			ctx.save();
			if (this.flash > 0) { ctx.filter = 'brightness(2.2)'; }
			Sprites.drawSprite(ctx, this.data.sprite, screenX - size / 2, screenY - size / 2, size, size, this.flip);
			ctx.restore();
			if (this.isBoss) {
				const w = 60;
				ctx.save();
				ctx.translate(screenX - w / 2, screenY - size / 2 - 12);
				ctx.fillStyle = 'rgba(0,0,0,0.5)'; ctx.fillRect(0, 0, w, 6);
				ctx.fillStyle = '#dc5a70'; ctx.fillRect(0, 0, w * Math.max(0, this.hp / this.maxHp), 6);
				ctx.strokeStyle = '#1a1220'; ctx.lineWidth = 1; ctx.strokeRect(0, 0, w, 6);
				ctx.restore();
			}
		}
	}

	// ============================================================== BULLET
	class Bullet {
		constructor(x, y, dir, speed, damage, fromPlayer, kind, pierce, range) {
			this.pos = { x, y }; this.dir = dir; this.speed = speed; this.damage = damage;
			this.fromPlayer = fromPlayer; this.kind = kind; this.pierce = pierce || 0;
			this.range = range || 260; this.traveled = 0; this.dead = false; this.lob = false; this.splash = 0;
			this.angle = Math.atan2(dir.y, dir.x);
		}
		update(dt, world) {
			const move = { x: this.dir.x * this.speed * dt, y: this.dir.y * this.speed * dt };
			this.pos.x += move.x; this.pos.y += move.y;
			this.traveled += Math.hypot(move.x, move.y);
			if (this.traveled >= this.range) { if (this.lob) this.detonate(world); this.dead = true; return; }
			if (!this.lob) {
				const targets = this.fromPlayer ? world.enemies : [world.player];
				for (const target of targets) {
					if (!target || !target.alive) continue;
					const r = target.radius;
					if (dist(this.pos, target.pos) <= r) {
						target.takeHit(this.damage, this.dir);
						if (target !== world.player) AudioMgr.playSfx('hit', 0.9 + Math.random() * 0.2, 0.3);
						if (this.pierce > 0) this.pierce--; else this.dead = true;
						break;
					}
				}
			}
		}
		detonate(world) {
			const targets = this.fromPlayer ? world.enemies : [world.player];
			targets.forEach((target) => {
				if (!target || !target.alive) return;
				if (dist(this.pos, target.pos) <= this.splash) target.takeHit(this.damage, { x: 0, y: 0 });
			});
			AudioMgr.playSfx('hit', 0.75, 0.3);
			world.spawnSpark(this.pos.x, this.pos.y, this.fromPlayer ? '#ffb35a' : '#c98cf0');
		}
		render(ctx, sx, sy) {
			const colors = { player: '#ffe38c', enemy: '#c98cf0', lob: '#ffb35a' };
			const c = colors[this.kind] || '#fff';
			const scale = this.lob ? 1 + Math.sin(Math.min(1, this.traveled / this.range) * Math.PI) * 0.6 : 1;
			ctx.save();
			ctx.translate(sx, sy); ctx.rotate(this.angle);
			ctx.fillStyle = c; ctx.strokeStyle = 'rgba(0,0,0,0.5)'; ctx.lineWidth = 1.4;
			ctx.beginPath(); ctx.ellipse(0, 0, 5 * scale, 3.6 * scale, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
			ctx.restore();
		}
	}

	class FishPickup {
		constructor(x, y, species, rarity) {
			this.pos = { x, y }; this.species = species; this.rarity = rarity; this.collected = false; this.bornT = 0;
		}
		update(dt, player) {
			this.bornT += dt;
			const magnetR = 70 * (1 + GameState.amiiboPassiveValue('pickup_radius_pct') + GameState.buffPickupRangeBonus() + GameState.pickupRangeBonus());
			const d = dist(this.pos, player.pos);
			if (d <= magnetR) {
				const speed = 80 + (1 - Math.min(1, d / magnetR)) * 260;
				const dir = normalize({ x: player.pos.x - this.pos.x, y: player.pos.y - this.pos.y });
				this.pos.x += dir.x * speed * dt; this.pos.y += dir.y * speed * dt;
			}
			if (dist(this.pos, player.pos) <= 14) this.collect();
		}
		collect() {
			if (this.collected) return;
			this.collected = true;
			GameState.addFish(this.species, this.rarity, 1);
			const rank = FD.rarityRank(this.rarity);
			const sfx = rank >= 2 ? 'pickup_rare' : (rank === 1 ? 'pickup_uncommon' : 'pickup_common');
			AudioMgr.playSfx(sfx, 1 + Math.random() * 0.1, 0.4);
		}
		render(ctx, sx, sy) {
			const bob = Math.sin(this.bornT * 6) * 2 - (this.bornT < 0.25 ? (0.25 - this.bornT) * 30 : 0);
			Sprites.drawSprite(ctx, `fish_${this.rarity.toLowerCase()}`, sx - 9, sy - 6 + bob, 18, 13, false);
		}
	}

	// FX helpers
	class SparkBurst {
		constructor(x, y, color) { this.x = x; this.y = y; this.color = color; this.t = 0; this.dead = false; this.parts = Array.from({ length: 7 }, (_, i) => ({ a: (Math.PI * 2 * i) / 7, r: 0 })); }
		update(dt) { this.t += dt; this.parts.forEach((p) => (p.r += dt * 80)); if (this.t > 0.3) this.dead = true; }
		render(ctx, sx, sy) { const a = 1 - this.t / 0.3; ctx.save(); ctx.fillStyle = this.color; ctx.globalAlpha = a; this.parts.forEach((p) => { ctx.beginPath(); ctx.arc(sx + Math.cos(p.a) * p.r, sy + Math.sin(p.a) * p.r, 2.4, 0, Math.PI * 2); ctx.fill(); }); ctx.restore(); }
	}
	class TelegraphFx {
		constructor(x, y, radius, duration, color) { this.x = x; this.y = y; this.radius = radius; this.duration = duration; this.t = 0; this.color = color; this.dead = false; }
		update(dt) { this.t += dt; if (this.t >= this.duration) this.dead = true; }
		render(ctx, sx, sy) { const frac = this.t / this.duration; ctx.save(); ctx.strokeStyle = this.color; ctx.globalAlpha = 0.3 + 0.5 * frac; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(sx, sy, this.radius * frac, 0, Math.PI * 2); ctx.stroke(); ctx.restore(); }
	}
	class PulseFx {
		constructor(x, y, radius, color) { this.x = x; this.y = y; this.radius = radius; this.t = 0; this.color = color; this.dead = false; }
		update(dt) { this.t += dt * 3; if (this.t >= 1) this.dead = true; }
		render(ctx, sx, sy) { ctx.save(); ctx.globalAlpha = 1 - this.t; ctx.strokeStyle = this.color; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(sx, sy, this.radius * this.t, 0, Math.PI * 2); ctx.stroke(); ctx.restore(); }
	}
	class Splat {
		constructor(x, y) { this.x = x; this.y = y; this.t = 0; this.dead = false; this.seed = Math.random() * 999; }
		update(dt) { this.t += dt; if (this.t > 2.5) this.dead = true; }
		render(ctx, sx, sy) {
			ctx.save(); ctx.globalAlpha = Math.max(0, 1 - this.t / 2.5) * 0.6;
			ctx.fillStyle = '#4a7a3a';
			for (let i = 0; i < 4; i++) {
				const a = this.seed + i * 1.7, r = 6 + (i % 3) * 3;
				ctx.beginPath(); ctx.ellipse(sx + Math.cos(a) * 6, sy + Math.sin(a) * 4, r, r * 0.6, a, 0, Math.PI * 2); ctx.fill();
			}
			ctx.restore();
		}
	}

	root.WorldEntities = { Player, Enemy, Bullet, FishPickup, SparkBurst, TelegraphFx, PulseFx, Splat, dist, normalize };
})(typeof window !== 'undefined' ? window : globalThis);
