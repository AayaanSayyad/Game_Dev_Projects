/* TileMap — one big deterministic (seeded) tile grid, split into biome
 * "pie slices" around a safe central spawn. Locked biomes push the player
 * back at their border and render a warning-fog overlay until unlocked.
 */
(function (root) {
	'use strict';
	const BD = root.BiomeData;
	const TILE = BD.TILE;

	const MAP_W = 110, MAP_H = 110;
	const CENTER = { x: MAP_W / 2, y: MAP_H / 2 };
	const SAFE_RADIUS = 16;

	function mulberry32(seed) {
		return function () {
			seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
			let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
			t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
			return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
		};
	}

	function biomeAt(tx, ty) {
		const dx = tx - CENTER.x, dy = ty - CENTER.y;
		const dist = Math.hypot(dx, dy);
		if (dist < SAFE_RADIUS) return 'litter_fields';
		let ang = Math.atan2(dy, dx) * 180 / Math.PI; // -180..180
		if (ang < 0) ang += 360;
		if (ang < 120) return 'junkyard';
		if (ang < 240) return 'toxic_marsh';
		return 'crystal_wastes';
	}

	class TileMap {
		constructor(seed) {
			this.seed = seed || 12345;
			this.rand = mulberry32(this.seed);
			this.w = MAP_W; this.h = MAP_H;
			this.ground = []; // {sheet,cols,index}
			this.decor = [];  // {sheet,cols,index,solid,x,y}
			this.solidGrid = new Set(); // "x,y" tiles blocked by decor
			this._generate();
		}

		_pick(arr) { return arr[Math.floor(this.rand() * arr.length)]; }

		_generate() {
			for (let ty = 0; ty < this.h; ty++) {
				this.ground.push([]);
				for (let tx = 0; tx < this.w; tx++) {
					const biomeId = biomeAt(tx, ty);
					const biome = BD.BIOMES[biomeId];
					let cell = { sheet: biome.ground.sheet, cols: biome.ground.cols, index: this._pick(biome.ground.indices), biome: biomeId, water: false };
					if (biome.patchTiles && this.rand() < biome.patchTiles.density) {
						cell = { sheet: biome.patchTiles.sheet, cols: biome.patchTiles.cols, index: this._pick(biome.patchTiles.indices), biome: biomeId, water: false };
					}
					if (biome.water && this.rand() < biome.water.density) {
						cell = { sheet: biome.water.sheet, cols: biome.water.cols, index: this._pick(biome.water.indices), biome: biomeId, water: true, tint: biome.water.tint };
					}
					this.ground[ty].push(cell);
				}
			}
			// decoration (trees/rocks/etc), skipped near exact center so spawn is clear
			for (let ty = 0; ty < this.h; ty++) {
				for (let tx = 0; tx < this.w; tx++) {
					if (Math.hypot(tx - CENTER.x, ty - CENTER.y) < 6) continue;
					if (this.ground[ty][tx].water) continue;
					const biomeId = this.ground[ty][tx].biome;
					const biome = BD.BIOMES[biomeId];
					for (const layer of biome.decor) {
						if (this.rand() < layer.density) {
							this.decor.push({ sheet: layer.sheet, cols: layer.cols, index: this._pick(layer.indices), tx, ty, solid: layer.solid });
							if (layer.solid) this.solidGrid.add(tx + ',' + ty);
							break;
						}
					}
				}
			}
		}

		isWater(tx, ty) {
			if (tx < 0 || ty < 0 || tx >= this.w || ty >= this.h) return false;
			return this.ground[ty][tx].water;
		}
		isSolidTile(tx, ty) {
			if (tx < 0 || ty < 0 || tx >= this.w || ty >= this.h) return true;
			if (this.solidGrid.has(tx + ',' + ty)) return true;
			if (this.ground[ty][tx].water) return true;
			return false;
		}
		biomeAtWorld(wx, wy) { return biomeAt(Math.floor(wx / TILE), Math.floor(wy / TILE)); }

		spawnWorldPos() { return { x: CENTER.x * TILE, y: CENTER.y * TILE }; }

		// Resolve movement collision for a circular entity (cx,cy,radius) trying
		// to move to (nx,ny); returns the corrected position.
		resolveCollision(nx, ny, radius) {
			const corners = [
				[nx - radius, ny - radius], [nx + radius, ny - radius],
				[nx - radius, ny + radius], [nx + radius, ny + radius],
			];
			for (const [cx, cy] of corners) {
				const tx = Math.floor(cx / TILE), ty = Math.floor(cy / TILE);
				if (this.isSolidTile(tx, ty)) {
					// push out along the axis of least penetration
					const tileCx = tx * TILE + TILE / 2, tileCy = ty * TILE + TILE / 2;
					const dx = nx - tileCx, dy = ny - tileCy;
					if (Math.abs(dx) > Math.abs(dy)) nx = tileCx + Math.sign(dx) * (TILE / 2 + radius);
					else ny = tileCy + Math.sign(dy) * (TILE / 2 + radius);
				}
			}
			return { x: nx, y: ny };
		}

		// Returns {locked:boolean, biome, pushback:{x,y}} if (wx,wy) is inside a
		// locked biome, using GameState's unlock set.
		checkLock(wx, wy, unlockedSet) {
			const biomeId = this.biomeAtWorld(wx, wy);
			if (unlockedSet.has(biomeId)) return null;
			return { biome: biomeId };
		}

		render(ctx, camera, viewW, viewH, unlockedSet) {
			const t0x = Math.max(0, Math.floor(camera.x / TILE) - 1);
			const t0y = Math.max(0, Math.floor(camera.y / TILE) - 1);
			const t1x = Math.min(this.w - 1, Math.ceil((camera.x + viewW) / TILE) + 1);
			const t1y = Math.min(this.h - 1, Math.ceil((camera.y + viewH) / TILE) + 1);

			for (let ty = t0y; ty <= t1y; ty++) {
				for (let tx = t0x; tx <= t1x; tx++) {
					const cell = this.ground[ty][tx];
					const dx = tx * TILE - camera.x, dy = ty * TILE - camera.y;
					Sprites.drawTile(ctx, 'tiles_' + cell.sheet, cell.index, cell.cols, TILE, dx, dy, TILE);
					if (cell.tint) { ctx.fillStyle = cell.tint; ctx.fillRect(Math.round(dx), Math.round(dy), TILE, TILE); }
					const biome = BD.BIOMES[cell.biome];
					if (biome.tint) { ctx.fillStyle = biome.tint; ctx.fillRect(Math.round(dx), Math.round(dy), TILE, TILE); }
					if (!unlockedSet.has(cell.biome)) {
						ctx.fillStyle = 'rgba(10,5,15,0.55)';
						ctx.fillRect(Math.round(dx), Math.round(dy), TILE, TILE);
					}
				}
			}
			// decor within view
			for (const d of this.decor) {
				if (d.tx < t0x || d.tx > t1x || d.ty < t0y || d.ty > t1y) continue;
				const dx = d.tx * TILE - camera.x, dy = d.ty * TILE - camera.y - 4;
				Sprites.drawTile(ctx, 'tiles_' + d.sheet, d.index, d.cols, TILE, dx, dy, TILE);
			}
		}
	}

	root.TileMapMod = { TileMap, MAP_W, MAP_H, CENTER, TILE, SAFE_RADIUS, biomeAt };
})(typeof window !== 'undefined' ? window : globalThis);
