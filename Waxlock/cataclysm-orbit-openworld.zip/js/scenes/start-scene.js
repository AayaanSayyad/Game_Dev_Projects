/* Scene: Start — title screen, separate from the House/World. */
(function (root) {
	'use strict';
	const Game = root.Game;

	const StartScene = {
		enter() {
			const wrap = Game.el('div', 'start-ui');
			const title = Game.el('div', 'game-title', wrap);
			title.innerHTML = 'Cataclysm<span>Orbit</span>';
			const sub = Game.el('div', 'game-subtitle', wrap);
			sub.textContent = 'a cozy open-world bullet-hell on the outer rim';

			const playBtn = Game.el('button', 'btn btn-primary btn-play', wrap);
			playBtn.textContent = GameState.data.totalKills > 0 ? 'Continue' : 'Play';
			playBtn.onclick = () => {
				AudioMgr.playSfx('ui_confirm', 1, 0.7);
				Game.goto('house');
			};

			const footer = Game.el('div', 'start-footer', wrap);
			const unlocked = GameState.data.unlockedBiomes.length;
			footer.textContent = `${unlocked} / 4 biomes discovered · ${GameState.data.totalKills} trash cleared`;
		},
		update() {},
		render(ctx, t) {
			ctx.fillStyle = '#140f28';
			ctx.fillRect(0, 0, Game.W, Game.H);
			// simple starfield (fixed pseudo-random positions so it doesn't shimmer/shift)
			ctx.save();
			for (let i = 0; i < 90; i++) {
				const seed = i * 12.9898;
				const sx = (Math.sin(seed) * 0.5 + 0.5) * Game.W;
				const sy = (Math.sin(seed * 1.7 + 4.1) * 0.5 + 0.5) * (Game.H * 0.62);
				const tw = 0.4 + 0.5 * Math.abs(Math.sin(t * (0.5 + (i % 5) * 0.15) + i));
				ctx.fillStyle = `rgba(255,246,214,${tw.toFixed(2)})`;
				ctx.fillRect(sx, sy, 2, 2);
			}
			ctx.restore();
			// ground silhouette
			ctx.fillStyle = '#241a3d';
			ctx.fillRect(0, Game.H * 0.72, Game.W, Game.H * 0.3);
			ctx.fillStyle = '#1c1533';
			for (let i = 0; i < 5; i++) ctx.fillRect(60 + i * 170, Game.H * 0.68, 20, 14);

			const bob = Math.sin(t * 1.5) * 2;
			const frame = Math.floor(t * 2) % 2;
			Sprites.drawSprite(ctx, `cat_stray_down_${frame}`, Game.W / 2 - 48, Game.H * 0.62 + bob, 96, 96, false);
		},
		exit() {},
	};

	Game.registerScene('start', StartScene);
})(typeof window !== 'undefined' ? window : globalThis);
