/* Tutorial — a short, fast, dismissible card sequence. Shown every time the
 * player enters the World (that was an explicit request) — kept to 4 cards
 * with big icons so re-reading it costs a returning player ~2 seconds, not
 * an annoyance. Space/click/Enter advances; Esc skips straight through.
 */
(function (root) {
	'use strict';
	const Game = root.Game;

	const CARDS = [
		{ icon: '⌨', title: 'Move & Aim', text: 'WASD to move. Mouse to aim — your cat always faces the cursor.' },
		{ icon: '🖱', title: 'Fight', text: 'Hold Click (or Space) to attack. Press E for your active skill.' },
		{ icon: '⚡', title: 'Dash', text: 'Shift to dash — brief invincibility, short cooldown. Use it to dodge.' },
		{ icon: '🗺', title: 'Explore', text: 'Clear trash to open new biomes. Fish go straight to your Vault at the House — spend them on upgrades.' },
	];

	function show(onDone) {
		let idx = 0;
		const overlay = Game.el('div', 'tutorial-overlay');
		const card = Game.el('div', 'tutorial-card', overlay);

		function render() {
			const c = CARDS[idx];
			card.innerHTML = `
				<div class="tutorial-icon">${c.icon}</div>
				<div class="tutorial-title">${c.title}</div>
				<div class="tutorial-text">${c.text}</div>
				<div class="tutorial-dots">${CARDS.map((_, i) => `<span class="${i === idx ? 'on' : ''}"></span>`).join('')}</div>
				<div class="tutorial-hint">${idx < CARDS.length - 1 ? 'Click / Space to continue' : 'Click / Space to start'}</div>
			`;
		}
		function advance() {
			idx++;
			if (idx >= CARDS.length) { finish(); return; }
			render();
		}
		function finish() {
			overlay.remove();
			window.removeEventListener('keydown', onKey);
			onDone();
		}
		function onKey(e) {
			if (e.code === 'Escape') { finish(); return; }
			if (e.code === 'Space' || e.code === 'Enter') advance();
		}
		overlay.addEventListener('click', advance);
		window.addEventListener('keydown', onKey);
		render();
	}

	root.Tutorial = { show };
})(typeof window !== 'undefined' ? window : globalThis);
