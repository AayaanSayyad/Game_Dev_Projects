/* Scene: House — entered by walking into the structure on the map, left by
 * a button. Simpler than the old build: fish go straight to the vault on
 * pickup now, so there's no satchel/death-penalty/Compost Bin bookkeeping
 * left to show here — just Roster, Vault, Blueprint.
 */
(function (root) {
	'use strict';
	const Game = root.Game, GD = root.GameData, FD = root.FishData, BD = root.BiomeData;

	let selectedCat = 'stray';
	let selectedAmiibo = [null, null];
	let panelOverlay = null, noticeEl = null;

	function showNotice(text) {
		noticeEl.textContent = text;
		noticeEl.classList.remove('show'); void noticeEl.offsetWidth; noticeEl.classList.add('show');
	}
	function closeAll() { panelOverlay.classList.remove('open'); panelOverlay.innerHTML = ''; }
	function openPanel(title, buildFn) {
		AudioMgr.playSfx('ui_move', 1, 0.5);
		panelOverlay.innerHTML = ''; panelOverlay.classList.add('open');
		const panel = Game.el('div', 'panel', panelOverlay);
		Game.el('div', 'panel-title', panel).textContent = title;
		const body = Game.el('div', 'panel-body', panel);
		buildFn(body);
		const closeBtn = Game.el('button', 'btn btn-close', panel);
		closeBtn.textContent = 'Close';
		closeBtn.onclick = closeAll;
	}

	function catCard(id, unlocked, selected, onClick) {
		const cat = GD.CATS[id];
		const card = document.createElement('button');
		card.className = 'cat-card' + (selected ? ' selected' : '') + (unlocked ? '' : ' locked');
		card.disabled = !unlocked;
		const cv = document.createElement('canvas'); cv.width = 64; cv.height = 64;
		if (unlocked) {
			const cctx = cv.getContext('2d'); cctx.imageSmoothingEnabled = false;
			Sprites.drawSprite(cctx, `cat_${id}_down_0`, 8, 8, 48, 48, false);
		}
		card.appendChild(cv);
		const label = document.createElement('div');
		const needBiome = cat.unlockBiome ? BD.BIOMES[cat.unlockBiome].name : '';
		label.textContent = unlocked ? cat.name : `${cat.name} (clear ${needBiome})`;
		card.appendChild(label);
		if (unlocked) card.onclick = onClick;
		return card;
	}

	function openRoster() {
		if (!GameState.data.rosterUnlocked.includes(selectedCat)) selectedCat = GameState.data.rosterUnlocked[0];
		selectedAmiibo = selectedAmiibo.map((id) => (id === selectedCat || (id && !GameState.data.rosterUnlocked.includes(id)) ? null : id));
		openPanel('Roster Nest', (body) => {
			const label1 = Game.el('div', 'panel-subhead', body); label1.textContent = 'Active cat:';
			const catRow = Game.el('div', 'cat-select-row', body);
			renderCatSelect(catRow);
			const label2 = Game.el('div', 'panel-subhead', body); label2.textContent = 'Amiibo slots (shrunk passives):';
			const amiiboRow = Game.el('div', 'cat-select-row', body);
			renderAmiiboSelect(amiiboRow);
			const applyBtn = Game.el('button', 'btn btn-primary', body);
			applyBtn.textContent = 'Confirm Roster';
			applyBtn.onclick = () => {
				AudioMgr.playSfx('ui_confirm');
				GameState.data.selectedCat = selectedCat;
				GameState.data.amiiboIds = selectedAmiibo.slice();
				GameState.save();
				showNotice('Roster updated!');
			};
		});
	}
	function renderCatSelect(container) {
		container.innerHTML = '';
		Object.keys(GD.CATS).forEach((id) => {
			const unlocked = GameState.data.rosterUnlocked.includes(id);
			container.appendChild(catCard(id, unlocked, id === selectedCat, () => {
				selectedCat = id;
				const idx = selectedAmiibo.indexOf(id);
				if (idx !== -1) selectedAmiibo[idx] = null;
				AudioMgr.playSfx('ui_move', 1, 0.4);
				renderCatSelect(container);
				renderAmiiboSelect(container.parentElement.querySelectorAll('.cat-select-row')[1]);
			}));
		});
	}
	function renderAmiiboSelect(container) {
		container.innerHTML = '';
		const cap = GameState.amiiboSlotCap();
		Object.keys(GD.CATS).forEach((id) => {
			if (id === selectedCat) return;
			const unlocked = GameState.data.rosterUnlocked.includes(id);
			const card = catCard(id, unlocked, selectedAmiibo.includes(id), () => {
				const idx = selectedAmiibo.indexOf(id);
				if (idx !== -1) selectedAmiibo[idx] = null;
				else {
					const empty = selectedAmiibo.findIndex((v, i) => v === null && i < cap);
					if (empty === -1) { showNotice(`No free Amiibo slot (cap ${cap}).`); return; }
					selectedAmiibo[empty] = id;
				}
				AudioMgr.playSfx('ui_move', 1, 0.4);
				renderAmiiboSelect(container);
			});
			if (unlocked) {
				const desc = document.createElement('div'); desc.className = 'amiibo-desc'; desc.textContent = GD.CATS[id].amiibo.desc;
				card.appendChild(desc);
			}
			container.appendChild(card);
		});
	}

	function openVault() {
		openPanel('Fish Vault', (body) => {
			const list = Game.el('div', 'vault-list', body);
			FD.activeSpeciesForPlanet('litter_prime').forEach((species) => {
				const row = document.createElement('div'); row.className = 'vault-row';
				const name = document.createElement('span'); name.className = 'vault-species'; name.textContent = FD.SPECIES[species].name;
				row.appendChild(name);
				['Common', 'Uncommon', 'Rare'].forEach((r) => {
					const c = document.createElement('span'); c.className = 'vault-count'; c.style.color = FD.RARITY_COLOR[r];
					c.textContent = `${r}: ${GameState.vaultCount(species, r)}`;
					row.appendChild(c);
				});
				if (GameState.hasUpgrade('smoker')) {
					const btn = document.createElement('button'); btn.className = 'btn btn-small'; btn.textContent = 'Smoke 5>1';
					btn.disabled = GameState.vaultCount(species, 'Common') < 5;
					btn.onclick = () => { if (GameState.smokeConvert(species)) { AudioMgr.playSfx('purchase'); openVault(); } };
					row.appendChild(btn);
				}
				list.appendChild(row);
			});
			const expRow = Game.el('div', 'vault-exp-row', body);
			const expLabel = document.createElement('span'); expLabel.textContent = `Account EXP: ${GameState.data.accountExp}`;
			expRow.appendChild(expLabel);
			const convertBtn = document.createElement('button'); convertBtn.className = 'btn'; convertBtn.textContent = 'Convert All to EXP';
			convertBtn.disabled = GameState.vaultTotal() <= 0;
			convertBtn.onclick = () => {
				const gained = GameState.convertVaultToExp();
				if (gained > 0) { AudioMgr.playSfx('purchase'); showNotice(`Converted vault fish into ${gained} EXP.`); }
				refreshTopInfo(); openVault();
			};
			expRow.appendChild(convertBtn);
		});
	}

	function openBlueprint() {
		openPanel('Blueprint Wall', (body) => {
			const list = Game.el('div', 'blueprint-list', body);
			GD.TRACK_ORDER.forEach((track) => {
				const head = document.createElement('div'); head.className = 'panel-subhead'; head.textContent = '-- ' + track + ' --';
				list.appendChild(head);
				Object.keys(GD.UPGRADES).forEach((id) => {
					const u = GD.UPGRADES[id];
					if (u.track !== track) return;
					list.appendChild(buildUpgradeRow(id, u));
				});
			});
		});
	}
	function buildUpgradeRow(id, data) {
		const row = document.createElement('div'); row.className = 'upgrade-row';
		const top = document.createElement('div'); top.className = 'upgrade-top';
		const name = document.createElement('span'); name.className = 'upgrade-name'; name.textContent = data.name;
		top.appendChild(name);
		const cost = document.createElement('span'); cost.className = 'upgrade-cost';
		cost.textContent = data.cost.map((l) => `${l.amount}x ${l.rarity} ${FD.SPECIES[l.species].name}`).join(', ');
		top.appendChild(cost);
		const btn = document.createElement('button'); btn.className = 'btn btn-small';
		if (GameState.hasUpgrade(id)) { btn.textContent = 'Owned'; btn.disabled = true; }
		else if (data.requires && !GameState.hasUpgrade(data.requires)) { btn.textContent = 'Needs ' + GD.UPGRADES[data.requires].name; btn.disabled = true; }
		else {
			btn.textContent = 'Buy';
			btn.disabled = !GameState.canAfford(id);
			btn.onclick = () => {
				if (GameState.purchaseUpgrade(id)) { AudioMgr.playSfx('purchase'); showNotice('Built: ' + data.name); refreshTopInfo(); openBlueprint(); }
			};
		}
		top.appendChild(btn);
		row.appendChild(top);
		const desc = document.createElement('div'); desc.className = 'upgrade-desc'; desc.textContent = data.desc;
		row.appendChild(desc);
		return row;
	}

	function refreshTopInfo() {
		document.getElementById('house-exp').textContent = 'EXP: ' + GameState.data.accountExp;
		document.getElementById('house-vault').textContent = 'Vault Fish: ' + GameState.vaultTotal();
		document.getElementById('house-biomes').textContent = 'Biomes: ' + GameState.data.unlockedBiomes.length + ' / 4';
	}

	const HouseScene = {
		enter() {
			selectedCat = GameState.data.selectedCat;
			selectedAmiibo = GameState.data.amiiboIds.slice();

			const wrap = Game.el('div', 'house-ui');
			const topInfo = Game.el('div', 'top-info', wrap);
			topInfo.innerHTML = '<span id="house-exp"></span><span id="house-vault"></span><span id="house-biomes"></span>';
			noticeEl = Game.el('div', 'notice-label', wrap);

			const hotspots = Game.el('div', 'hotspot-bar', wrap);
			[['Roster Nest', openRoster], ['Fish Vault', openVault], ['Blueprint Wall', openBlueprint]].forEach(([label, fn]) => {
				const btn = document.createElement('button'); btn.className = 'btn hotspot-btn'; btn.textContent = label; btn.onclick = fn;
				hotspots.appendChild(btn);
			});
			const leaveBtn = document.createElement('button'); leaveBtn.className = 'btn btn-primary hotspot-btn'; leaveBtn.textContent = 'Leave House';
			leaveBtn.onclick = () => { AudioMgr.playSfx('ui_move'); Game.goto('world'); };
			hotspots.appendChild(leaveBtn);

			panelOverlay = Game.el('div', 'panel-overlay', wrap);
			refreshTopInfo();
			AudioMgr.playMusic('house');
		},
		update(dt, t) { this.t = t; },
		render(ctx, t) {
			const cols = 15, rows = 10, tile = Math.min(Game.W / cols, Game.H / rows);
			const ox = (Game.W - cols * tile) / 2, oy = (Game.H - rows * tile) / 2;
			for (let y = 0; y < rows; y++) {
				for (let x = 0; x < cols; x++) {
					const border = x === 0 || y === 0 || x === cols - 1 || y === rows - 1;
					if (border) Sprites.drawTile(ctx, 'tiles_dungeon', 36, 12, 16, ox + x * tile, oy + y * tile, tile);
					else Sprites.drawTile(ctx, 'tiles_dungeon', 0, 12, 16, ox + x * tile, oy + y * tile, tile);
				}
			}
			Sprites.drawTile(ctx, 'tiles_town', 74, 12, 16, ox + Math.floor(cols / 2) * tile, oy + (rows - 1) * tile, tile);
			// a little furniture for warmth
			Sprites.drawTile(ctx, 'tiles_town', 103, 12, 16, ox + 2 * tile, oy + 2 * tile, tile);
			Sprites.drawTile(ctx, 'tiles_town', 16, 12, 16, ox + (cols - 3) * tile, oy + 2 * tile, tile);
			Sprites.drawTile(ctx, 'tiles_town', 92, 12, 16, ox + 2 * tile, oy + (rows - 3) * tile, tile);
			const cx = ox + (cols / 2) * tile, cy = oy + (rows / 2) * tile;
			ctx.fillStyle = 'rgba(150,110,90,0.5)';
			ctx.fillRect(cx - tile * 1.5, cy - tile, tile * 3, tile * 2);
			const bob = Math.sin(t * 1.6) * 2;
			Sprites.drawSprite(ctx, 'cat_' + selectedCat + '_down_0', cx - 22, cy - 30 + bob, 44, 44, false);
		},
		exit() {},
	};

	Game.registerScene('house', HouseScene);
})(typeof window !== 'undefined' ? window : globalThis);
