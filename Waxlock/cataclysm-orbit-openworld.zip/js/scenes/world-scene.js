/* Scene: World — the open map. Replaces the old fixed "Arena" entirely:
 * the player explores a big seeded tile map split into 4 biome regions,
 * fighting trash creatures that spawn near them, until each biome's
 * guardian boss is found and beaten, unlocking the next biome (and, tied
 * to that, the next cat).
 */
(function (root) {
	'use strict';
	const Game = root.Game, GD = root.GameData, FD = root.FishData, BD = root.BiomeData;
	const WE = root.WorldEntities, TM = root.TileMapMod;

	const SPAWN_MIN_DIST = 260, SPAWN_MAX_DIST = 380;
	const ENEMY_CAP_BASE = 6;

	const WorldScene = {
		enter() {
			this.map = new TM.TileMap(GameState.data.mapSeed);
			this.player = new WE.Player(GameState.data.selectedCat, this);
			this.enemies = []; this.bullets = []; this.pickups = []; this.particles = [];
			this.camera = { x: 0, y: 0, shakeT: 0, shakeAmt: 0 };
			this._spawnTimer = 0;
			this.paused = false;
			this.runOver = false;
			this.currentBiome = this.map.biomeAtWorld(this.player.pos.x, this.player.pos.y);
			this._nearHouse = false;
			this._enteringHouse = false;
			this._lockNoticeT = 0;

			this._buildUI();
			this._centerCameraOnPlayer(true);
			AudioMgr.playMusic('combat');

			this.player.frozen = true;
			Tutorial.show(() => { this.player.frozen = false; });
		},

		screenToWorld(sx, sy) { return { x: sx + this.camera.x, y: sy + this.camera.y }; },

		shake(amount, duration) {
			if (!GameState.data.settings.screenShake) return;
			this.camera.shakeT = Math.max(this.camera.shakeT, duration);
			this.camera.shakeAmt = Math.max(this.camera.shakeAmt, amount);
		},

		spawnBullet(...args) { const b = new WE.Bullet(...args); this.bullets.push(b); return b; },
		spawnSpark(x, y, c) { this.particles.push(new WE.SparkBurst(x, y, c)); },
		spawnTelegraph(x, y, r, dur, c) { this.particles.push(new WE.TelegraphFx(x, y, r, dur, c)); },
		spawnPulse(x, y, r, c) { this.particles.push(new WE.PulseFx(x, y, r, c)); },

		// Push the entity back out of a locked biome (soft boundary, same
		// pushback feel as tile collision).
		enforceBiomeLock(entity) {
			const biomeId = this.map.biomeAtWorld(entity.pos.x, entity.pos.y);
			if (GameState.isUnlocked(biomeId)) return;
			const c = { x: TM.CENTER.x * TM.TILE, y: TM.CENTER.y * TM.TILE };
			const dir = WE.normalize({ x: c.x - entity.pos.x, y: c.y - entity.pos.y });
			entity.pos.x += dir.x * 140 * (1 / 60);
			entity.pos.y += dir.y * 140 * (1 / 60);
			if (entity === this.player && !this._lockNoticeT) {
				this._lockNoticeT = 2.2;
				this._showLockNotice(biomeId);
			}
		},

		_showLockNotice(biomeId) {
			const need = BD.BIOMES[biomeId].requires;
			const needName = need ? BD.BIOMES[need].name : '';
			this.showBanner(`${BD.BIOMES[biomeId].name} is sealed off - clear ${needName || 'this area'} first`, '#ff9f9f', 2.2);
		},

		// ---------------------------------------------------------- SPAWNING
		_biomeEnemyCap(biomeId) { return ENEMY_CAP_BASE + BD.BIOMES[biomeId].order * 2; },
		_maintainSpawns(dt) {
			const p = GameState.data.biomeProgress[this.currentBiome];
			if (!p || p.bossSpawned) return; // no trash while boss is up (or defeated)
			this._spawnTimer -= dt;
			const alive = this.enemies.filter((e) => e.alive && !e.isBoss).length;
			const cap = this._biomeEnemyCap(this.currentBiome);
			if (this._spawnTimer <= 0 && alive < cap) {
				this._spawnOne();
				this._spawnTimer = 0.9 + Math.random() * 0.6;
			}
			if (GameState.bossReadyToSpawn(this.currentBiome)) this._spawnBoss();
		},
		_randomSpawnPos() {
			for (let tries = 0; tries < 12; tries++) {
				const ang = Math.random() * Math.PI * 2;
				const d = SPAWN_MIN_DIST + Math.random() * (SPAWN_MAX_DIST - SPAWN_MIN_DIST);
				const x = this.player.pos.x + Math.cos(ang) * d, y = this.player.pos.y + Math.sin(ang) * d;
				const tx = Math.floor(x / TM.TILE), ty = Math.floor(y / TM.TILE);
				if (this.map.isSolidTile(tx, ty)) continue;
				if (this.map.biomeAtWorld(x, y) !== this.currentBiome) continue;
				return { x, y };
			}
			return { x: this.player.pos.x + 300, y: this.player.pos.y };
		},
		_spawnOne() {
			const biome = BD.BIOMES[this.currentBiome];
			const type = biome.enemies[Math.floor(Math.random() * biome.enemies.length)];
			const hpMult = 1 + biome.order * 0.45;
			const pos = this._randomSpawnPos();
			const data = GD.ENEMIES[type];
			const count = data.packSize || 1;
			for (let i = 0; i < count; i++) {
				const jx = pos.x + (Math.random() * 24 - 12), jy = pos.y + (Math.random() * 24 - 12);
				this.enemies.push(new WE.Enemy(type, jx, jy, hpMult, this, false));
			}
		},
		_spawnBoss() {
			GameState.markBossSpawned(this.currentBiome);
			const biome = BD.BIOMES[this.currentBiome];
			const pos = this._randomSpawnPos();
			const hpMult = 1 + biome.order * 0.5;
			const boss = new WE.Enemy('boss', pos.x, pos.y, hpMult, this, true);
			boss.bossBiome = this.currentBiome;
			this.enemies.push(boss);
			this.showBanner(`${biome.bossName} appears!`, '#ffb35a', 2.6);
			AudioMgr.playSfx('milestone');
		},

		onEnemyDied(enemy) {
			GameState.registerKill(this.currentBiome);
			this._spawnFishDrop(enemy.pos, enemy.isBoss ? 6 : 1, enemy.isBoss);
			this.particles.push(new WE.Splat(enemy.pos.x, enemy.pos.y));
			if (enemy.isBoss) this._onBossDefeated(enemy.bossBiome);
		},
		_onBossDefeated(biomeId) {
			AudioMgr.playSfx('wave_clear');
			const unlockedNext = GameState.defeatBoss(biomeId);
			this.showBanner(`${BD.BIOMES[biomeId].name} cleared!`, '#9ef29e', 2.2);
			if (unlockedNext) {
				setTimeout(() => {
					this.showBanner(`New area unlocked: ${BD.BIOMES[unlockedNext].name}!`, '#ffe6ae', 3);
					AudioMgr.playSfx('milestone');
				}, 1500);
			}
			if (GameState.data.lastUnlocked.length) {
				const names = GameState.data.lastUnlocked.map((id) => GD.CATS[id].name);
				setTimeout(() => this.showBanner(`New cat recruited: ${names.join(', ')}!`, '#ffb7c9', 3), 3200);
				GameState.data.lastUnlocked = [];
				GameState.save();
			}
		},
		_spawnFishDrop(pos, count, isElite) {
			for (let i = 0; i < count; i++) {
				const species = FD.rollSpecies('litter_prime');
				const rarity = FD.rollRarity(isElite, GameState.buffLuckyGut());
				this.pickups.push(new WE.FishPickup(pos.x + (Math.random() * 20 - 10), pos.y + (Math.random() * 20 - 10), species, rarity));
			}
		},

		onPlayerDied() {
			this.runOver = true;
			AudioMgr.playSfx('death');
			this.showBanner('Overwhelmed! Recovering at home...', '#ff9f9f', 2);
			setTimeout(() => {
				const spawn = this.map.spawnWorldPos();
				this.player.pos = { x: spawn.x, y: spawn.y + 40 };
				this.player.alive = true;
				this.player.invulnT = 1.5;
				GameState.fullHeal();
				this.runOver = false;
				this._centerCameraOnPlayer(true);
			}, 1400);
		},

		// -------------------------------------------------------------- UI
		_buildUI() {
			const wrap = Game.el('div', 'world-ui');
			this.ui = {};
			const hud = Game.el('div', 'hud', wrap);
			this.ui.hearts = Game.el('div', 'hud-hearts', hud);
			this.ui.biome = Game.el('div', 'hud-biome', hud);
			this.ui.progress = Game.el('div', 'hud-progress', hud);
			this.ui.vault = Game.el('div', 'hud-vault', hud);
			const bars = Game.el('div', 'hud-bars', wrap);
			this.ui.dashBar = Game.el('div', 'hud-bar dash', bars); this.ui.dashBar.innerHTML = '<div class="fill"></div>';
			this.ui.skillBar = Game.el('div', 'hud-bar skill', bars); this.ui.skillBar.innerHTML = '<div class="fill"></div>';
			this.ui.banner = Game.el('div', 'hud-banner', wrap);
			this.ui.houseHint = Game.el('div', 'house-hint', wrap);
			this.ui.houseHint.textContent = 'Walk into the House to manage your Vault & Upgrades';

			GameState.on('heartsChanged', (c, m) => this._renderHearts(c, m));
			this._renderHearts(GameState.heartsCurrent, GameState.heartsMax);
			this._updateBiomeHud();

			window.addEventListener('keydown', this._onKeyDown = (e) => {
				if (e.code === 'Escape' && !this.runOver) this._togglePause();
			});
		},
		_renderHearts(cur, max) {
			this.ui.hearts.innerHTML = '';
			for (let i = 0; i < Math.ceil(max / 2); i++) {
				const remain = cur - i * 2;
				const span = document.createElement('span');
				span.className = 'heart ' + (remain >= 2 ? 'full' : remain === 1 ? 'half' : 'empty');
				span.textContent = '♥';
				this.ui.hearts.appendChild(span);
			}
		},
		_updateBiomeHud() {
			const biome = BD.BIOMES[this.currentBiome];
			this.ui.biome.textContent = biome.name;
			const p = GameState.data.biomeProgress[this.currentBiome];
			if (p.bossDefeated) this.ui.progress.textContent = 'Cleared';
			else if (p.bossSpawned) this.ui.progress.textContent = `Defeat ${biome.bossName}!`;
			else this.ui.progress.textContent = `Trash cleared: ${p.kills} / ${GD.KILLS_TO_BOSS}`;
		},
		showBanner(text, color, duration) {
			this.ui.banner.textContent = text;
			this.ui.banner.style.color = color || '#ffe6ae';
			this.ui.banner.classList.remove('show'); void this.ui.banner.offsetWidth; this.ui.banner.classList.add('show');
			this.ui.banner.style.animationDuration = (duration || 2.2) + 's';
		},

		_togglePause() {
			this.paused = !this.paused;
			if (this.paused) this._showPause(); else { const p = Game.uiLayer.querySelector('.overlay-panel'); if (p) p.remove(); }
		},
		_showPause() {
			const dim = Game.el('div', 'overlay-dim overlay-panel');
			const panel = Game.el('div', 'panel', dim);
			Game.el('div', 'panel-title', panel).textContent = 'Paused';
			const resumeBtn = Game.el('button', 'btn btn-primary', panel);
			resumeBtn.textContent = 'Resume';
			resumeBtn.onclick = () => { this.paused = false; dim.remove(); };
			const label = Game.el('label', 'shake-toggle', panel);
			const cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = GameState.data.settings.screenShake;
			cb.onchange = () => { GameState.data.settings.screenShake = cb.checked; GameState.save(); };
			label.appendChild(cb); label.appendChild(document.createTextNode(' Screen shake'));
			const homeBtn = Game.el('button', 'btn', panel);
			homeBtn.textContent = 'Go to House';
			homeBtn.onclick = () => { Game.goto('house'); };
		},

		// ------------------------------------------------------------- LOOP
		_centerCameraOnPlayer(instant) {
			const target = { x: this.player.pos.x - Game.W / 2, y: this.player.pos.y - Game.H / 2 };
			if (instant) { this.camera.x = target.x; this.camera.y = target.y; }
		},

		update(dt, t) {
			if (this.player.frozen) return; // tutorial still up
			if (this.paused) return;

			if (!this.runOver) this.player.update(dt);
			if (!this.runOver) this.enforceBiomeLock(this.player);
			this.enemies.forEach((e) => e.update(dt, this.player));
			this.enemies = this.enemies.filter((e) => e.alive);
			this.bullets.forEach((b) => b.update(dt, this));
			this.bullets = this.bullets.filter((b) => !b.dead);
			this.pickups.forEach((p) => p.update(dt, this.player));
			this.pickups = this.pickups.filter((p) => !p.collected);
			this.particles.forEach((p) => p.update(dt));
			this.particles = this.particles.filter((p) => !p.dead);

			const target = { x: this.player.pos.x - Game.W / 2, y: this.player.pos.y - Game.H / 2 };
			this.camera.x += (target.x - this.camera.x) * Math.min(1, dt * 5);
			this.camera.y += (target.y - this.camera.y) * Math.min(1, dt * 5);
			if (this.camera.shakeT > 0) this.camera.shakeT -= dt; else this.camera.shakeAmt = 0;

			if (this._lockNoticeT > 0) this._lockNoticeT = Math.max(0, this._lockNoticeT - dt);

			const newBiome = this.map.biomeAtWorld(this.player.pos.x, this.player.pos.y);
			if (newBiome !== this.currentBiome) { this.currentBiome = newBiome; this._updateBiomeHud(); }
			else if (Math.floor(t * 2) % 10 === 0) this._updateBiomeHud();

			if (!this.runOver) this._maintainSpawns(dt);

			this.ui.dashBar.querySelector('.fill').style.width = `${(1 - this.player.dashCooldownFrac()) * 100}%`;
			this.ui.skillBar.querySelector('.fill').style.width = `${(1 - this.player.skillCooldownFrac()) * 100}%`;
			this.ui.vault.textContent = `Vault: ${GameState.vaultTotal()} fish`;

			// House proximity -> auto-enter
			const houseWorld = this.map.spawnWorldPos();
			const dHouse = Math.hypot(this.player.pos.x - houseWorld.x, this.player.pos.y - houseWorld.y);
			this._nearHouse = dHouse < 70;
			this.ui.houseHint.style.display = this._nearHouse ? 'block' : 'none';
			if (dHouse < 22 && !this._enteringHouse) {
				this._enteringHouse = true;
				AudioMgr.playSfx('ui_move');
				Game.goto('house');
			}
		},

		render(ctx, t) {
			const shakeX = this.camera.shakeT > 0 ? (Math.random() * 2 - 1) * this.camera.shakeAmt : 0;
			const shakeY = this.camera.shakeT > 0 ? (Math.random() * 2 - 1) * this.camera.shakeAmt : 0;
			const cam = { x: this.camera.x + shakeX, y: this.camera.y + shakeY };

			ctx.fillStyle = '#1a1428'; ctx.fillRect(0, 0, Game.W, Game.H);
			this.map.render(ctx, cam, Game.W, Game.H, new Set(GameState.data.unlockedBiomes));

			const housePos = this.map.spawnWorldPos();
			const hs = this._toScreen(housePos.x, housePos.y, cam);
			Sprites.drawSprite(ctx, 'house_icon', hs.x - 24, hs.y - 40, 48, 42, false);

			this.particles.filter((p) => p instanceof WE.Splat).forEach((p) => { const s = this._toScreen(p.x, p.y, cam); p.render(ctx, s.x, s.y); });
			this.pickups.forEach((p) => { const s = this._toScreen(p.pos.x, p.pos.y, cam); p.render(ctx, s.x, s.y); });

			const drawables = [this.player, ...this.enemies].sort((a, b) => a.pos.y - b.pos.y);
			drawables.forEach((d) => { const s = this._toScreen(d.pos.x, d.pos.y, cam); d.render(ctx, s.x, s.y); });

			this.bullets.forEach((b) => { const s = this._toScreen(b.pos.x, b.pos.y, cam); b.render(ctx, s.x, s.y); });
			this.particles.filter((p) => !(p instanceof WE.Splat)).forEach((p) => { const s = this._toScreen(p.x, p.y, cam); p.render(ctx, s.x, s.y); });

			const g = ctx.createRadialGradient(Game.W / 2, Game.H / 2, Game.H * 0.35, Game.W / 2, Game.H / 2, Game.H * 0.75);
			g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(5,3,10,0.4)');
			ctx.fillStyle = g; ctx.fillRect(0, 0, Game.W, Game.H);
		},

		_toScreen(wx, wy, cam) { return { x: wx - cam.x, y: wy - cam.y }; },

		exit() {
			if (this._onKeyDown) window.removeEventListener('keydown', this._onKeyDown);
		},
	};

	Game.registerScene('world', WorldScene);
})(typeof window !== 'undefined' ? window : globalThis);
