"""
Enemy sprites: extracted from Kenney's CC0 "Tiny Dungeon" pack (slime, crab,
spider, ghost) and recolored to fit the trash-planet theme. Recoloring maps
each sprite's existing colors (sorted by lightness, preserving the original
shading/form) onto a new hand-picked palette — this keeps all of Kenney's
actual pixel art and shading work, just retints it, which is why these look
far more polished than fully custom sprites would in the same time budget.
"""
from PIL import Image
import os

SHEET = Image.open("/home/claude/game2/assets/tiles/dungeon_sheet.png")
COLS = 12
OUT = "/home/claude/game2/assets/sprites"

def get_tile(idx):
    x = (idx % COLS) * 16
    y = (idx // COLS) * 16
    return SHEET.crop((x, y, x + 16, y + 16)).convert("RGBA")

def recolor(img, new_palette):
    """new_palette: list of RGB tuples, light-to-dark, same length as the
    number of distinct opaque colors in img (by luminance rank)."""
    colors = {}
    for x in range(img.width):
        for y in range(img.height):
            r, g, b, a = img.getpixel((x, y))
            if a > 10:
                colors[(r, g, b)] = colors.get((r, g, b), 0) + 1
    ranked = sorted(colors.keys(), key=lambda c: -(0.299*c[0]+0.587*c[1]+0.114*c[2]))
    mapping = {}
    for i, c in enumerate(ranked):
        mapping[c] = new_palette[min(i, len(new_palette)-1)]
    out = img.copy()
    for x in range(img.width):
        for y in range(img.height):
            r, g, b, a = out.getpixel((x, y))
            if a > 10:
                nc = mapping.get((r, g, b), (r, g, b))
                out.putpixel((x, y), (*nc, a))
    return out

def upscale_nn(img, factor):
    return img.resize((img.width*factor, img.height*factor), Image.NEAREST)

ENEMIES = {
    # (source tile index, new palette light->dark, output name, upscale)
    "grub":  (108, [(150,196,90), (108,158,60), (70,110,40)], 1),
    "spitter": (110, [(190,130,220), (146,88,182), (98,52,132)], 1),
    "mite":  (120, [(232,110,130), (196,72,96), (140,45,66)], 1),
}

os.makedirs(OUT, exist_ok=True)
for name, (idx, palette, scale) in ENEMIES.items():
    tile = get_tile(idx)
    tile = recolor(tile, palette)
    if scale != 1:
        tile = upscale_nn(tile, scale)
    tile.save(os.path.join(OUT, f"enemy_{name}.png"))
    print("saved", name, tile.size)

# Boss: same ghost/blob (121) but scaled up + bulked out with junk-colored
# rectangles stamped around it so it reads as a bigger "trash golem" silhouette.
boss_base = get_tile(121)
boss_base = recolor(boss_base, [(196,196,206), (140,140,152), (90,90,100)])
boss_big = upscale_nn(boss_base, 3)  # 48x48
canvas = Image.new("RGBA", (56, 56), (0,0,0,0))
canvas.paste(boss_big, (4, 8), boss_big)
from PIL import ImageDraw
d = ImageDraw.Draw(canvas)
OUTLINE = (26, 18, 30, 255)
junk = [(10,44,10,8,(181,98,74,255)), (36,44,10,8,(95,143,138,255)),
        (6,10,8,8,(232,197,101,255)), (40,8,8,8,(150,88,182,255))]
for x,y,w,h,c in junk:
    d.rectangle([x,y,x+w,y+h], fill=c, outline=OUTLINE, width=1)
canvas.save(os.path.join(OUT, "enemy_boss.png"))
print("saved boss", canvas.size)
