"""
Hand-authored pixel-art cat character, built on a strict 32x32 pixel grid
(matching genuine pixel-art technique: hard rectangle blocks, no
anti-aliasing, no curves) so it visually matches the sourced Kenney tiles
it will stand on. Grid authored as a list of (x, y, w, h, color-key) pixel
blocks per frame, which is far more precise to hand-tune than a smooth
vector path. Iterated against actual PNG renders, not guessed blind.
"""
from PIL import Image
import os

OUT = "/home/claude/game2/assets/sprites"
os.makedirs(OUT, exist_ok=True)
G = 32  # grid size

PALETTES = {
    "stray": {"body": (232,146,92), "dark": (196,110,63), "belly": (255,227,189), "eye": (43,29,51), "nose": (201,107,79)},
    "brick": {"body": (181,98,74), "dark": (138,68,51), "belly": (232,183,154), "eye": (43,29,51), "nose": (150,70,55)},
    "soot":  {"body": (74,70,80), "dark": (51,47,58), "belly": (141,136,148), "eye": (232,201,106), "nose": (100,90,110)},
    "miso":  {"body": (242,226,196), "dark": (214,195,160), "belly": (255,248,232), "eye": (43,29,51), "nose": (224,160,176)},
}
OUTLINE = (26,18,30)

def blank():
    return [[None]*G for _ in range(G)]

def rect(grid, x, y, w, h, color):
    for yy in range(y, y+h):
        for xx in range(x, x+w):
            if 0 <= xx < G and 0 <= yy < G:
                grid[yy][xx] = color

def px(grid, x, y, color):
    if 0 <= x < G and 0 <= y < G:
        grid[y][x] = color

def outline_and_save(grid, path, scale=8):
    # auto-outline: any colored pixel adjacent to empty gets an outline pixel behind it
    h = len(grid); w = len(grid[0])
    outlined = [row[:] for row in grid]
    for y in range(h):
        for x in range(w):
            if grid[y][x] is None:
                neighbors = [(x-1,y),(x+1,y),(x,y-1),(x,y+1),(x-1,y-1),(x+1,y-1),(x-1,y+1),(x+1,y+1)]
                for nx, ny in neighbors:
                    if 0 <= nx < w and 0 <= ny < h and grid[ny][nx] is not None:
                        outlined[y][x] = OUTLINE
                        break
    img = Image.new("RGBA", (w, h), (0,0,0,0))
    for y in range(h):
        for x in range(w):
            c = outlined[y][x]
            if c: img.putpixel((x,y), (*c, 255))
    if scale != 1:
        img = img.resize((w*scale, h*scale), Image.NEAREST)
    img.save(path)
    return img

def cat_down(pal, frame):
    """Front-facing cat, walk frame 0 or 1 (leg/tail micro-animation)."""
    g = blank()
    body, dark, belly, eye, nose = pal["body"], pal["dark"], pal["belly"], pal["eye"], pal["nose"]
    bob = 1 if frame == 1 else 0
    # tail (behind body), curls to the right
    rect(g, 22, 16-bob, 3, 3, dark)
    rect(g, 24, 13-bob, 3, 3, body)
    rect(g, 25, 10-bob, 3, 3, dark)
    # back paws (alternate which is forward)
    if frame == 0:
        rect(g, 9, 27, 4, 3, dark); rect(g, 18, 26, 4, 3, dark)
    else:
        rect(g, 9, 26, 4, 3, dark); rect(g, 18, 27, 4, 3, dark)
    # body (rounded blob via stepped rectangles)
    rect(g, 9, 15-bob, 14, 2, body)
    rect(g, 7, 17-bob, 18, 8, body)
    rect(g, 8, 25-bob, 16, 2, body)
    # belly patch
    rect(g, 12, 19-bob, 8, 7, belly)
    # head
    rect(g, 8, 4-bob, 16, 2, body)
    rect(g, 6, 6-bob, 20, 10, body)
    rect(g, 7, 16-bob, 18, 1, body)
    # ears
    rect(g, 7, 1-bob, 4, 4, body); rect(g, 8, 2-bob, 2, 2, dark)
    rect(g, 21, 1-bob, 4, 4, body); rect(g, 22, 2-bob, 2, 2, dark)
    # muzzle/cheek patch
    rect(g, 10, 10-bob, 12, 6, belly)
    # eyes
    rect(g, 11, 9-bob, 3, 4, eye); rect(g, 18, 9-bob, 3, 4, eye)
    px(g, 12, 9-bob, (255,255,255)); px(g, 19, 9-bob, (255,255,255))
    # nose + mouth
    rect(g, 15, 13-bob, 2, 2, nose)
    px(g, 14, 15-bob, eye); px(g, 17, 15-bob, eye)
    # front paws
    rect(g, 10, 24-bob, 3, 3, belly); rect(g, 19, 24-bob, 3, 3, belly)
    return g

def cat_up(pal, frame):
    """Back-facing cat (walking away) — ears, back, tail, no face."""
    g = blank()
    body, dark, belly, eye, nose = pal["body"], pal["dark"], pal["belly"], pal["eye"], pal["nose"]
    bob = 1 if frame == 1 else 0
    rect(g, 22, 16-bob, 3, 3, dark)
    rect(g, 24, 13-bob, 3, 3, body)
    rect(g, 25, 10-bob, 3, 3, dark)
    if frame == 0:
        rect(g, 9, 27, 4, 3, dark); rect(g, 18, 26, 4, 3, dark)
    else:
        rect(g, 9, 26, 4, 3, dark); rect(g, 18, 27, 4, 3, dark)
    rect(g, 9, 15-bob, 14, 2, body)
    rect(g, 7, 17-bob, 18, 8, body)
    rect(g, 8, 25-bob, 16, 2, body)
    # spine stripe
    rect(g, 14, 18-bob, 4, 8, dark)
    rect(g, 8, 4-bob, 16, 2, body)
    rect(g, 6, 6-bob, 20, 10, body)
    rect(g, 7, 16-bob, 18, 1, body)
    rect(g, 7, 1-bob, 4, 4, body); rect(g, 8, 1-bob, 2, 2, dark)
    rect(g, 21, 1-bob, 4, 4, body); rect(g, 22, 1-bob, 2, 2, dark)
    rect(g, 11, 6-bob, 10, 4, dark)  # back-of-head marking
    return g

def cat_side(pal, frame):
    """Left-facing profile (flip for right)."""
    g = blank()
    body, dark, belly, eye, nose = pal["body"], pal["dark"], pal["belly"], pal["eye"], pal["nose"]
    bob = 1 if frame == 1 else 0
    # tail curls up-back (to the right, since facing left)
    rect(g, 19, 17-bob, 3, 3, dark)
    rect(g, 21, 13-bob, 3, 4, body)
    rect(g, 21, 9-bob, 3, 4, dark)
    if frame == 0:
        rect(g, 11, 27, 4, 3, dark); rect(g, 17, 26, 3, 3, dark)
    else:
        rect(g, 11, 26, 4, 3, dark); rect(g, 17, 27, 3, 3, dark)
    rect(g, 9, 15-bob, 13, 2, body)
    rect(g, 7, 17-bob, 15, 8, body)
    rect(g, 8, 25-bob, 13, 2, body)
    rect(g, 9, 20-bob, 6, 5, belly)
    # head (offset toward left/front)
    rect(g, 3, 5-bob, 14, 10, body)
    rect(g, 5, 3-bob, 10, 2, body)
    rect(g, 4, 15-bob, 12, 1, body)
    # ear
    rect(g, 5, 0-bob, 4, 4, body); rect(g, 6, 1-bob, 2, 2, dark)
    rect(g, 12, 1-bob, 3, 3, body)
    # muzzle
    rect(g, 2, 9-bob, 5, 5, belly)
    # eye (one visible)
    rect(g, 6, 8-bob, 3, 4, eye); px(g, 7, 8-bob, (255,255,255))
    rect(g, 1, 11-bob, 2, 2, nose)
    # front/back paw
    rect(g, 9, 24-bob, 3, 3, belly)
    return g

def build_all():
    manifest = {}
    for name, pal in PALETTES.items():
        frames = {
            "down_0": cat_down(pal, 0), "down_1": cat_down(pal, 1),
            "up_0": cat_up(pal, 0), "up_1": cat_up(pal, 1),
            "side_0": cat_side(pal, 0), "side_1": cat_side(pal, 1),
        }
        for fname, grid in frames.items():
            path = os.path.join(OUT, f"cat_{name}_{fname}.png")
            outline_and_save(grid, path, scale=1)  # keep native res; scale in-browser
        print("built", name)

if __name__ == "__main__":
    build_all()
