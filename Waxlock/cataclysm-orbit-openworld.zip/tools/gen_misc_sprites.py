"""Fish pickup icons (one base shape, recolored per rarity) and the House
structure marker placed at the player's spawn point on the map."""
from PIL import Image, ImageDraw
import os

OUT = "/home/claude/game2/assets/sprites"
os.makedirs(OUT, exist_ok=True)
OUTLINE = (26, 18, 30, 255)

def outline_grid(grid, w, h):
    out = [row[:] for row in grid]
    for y in range(h):
        for x in range(w):
            if grid[y][x] is None:
                for nx, ny in [(x-1,y),(x+1,y),(x,y-1),(x,y+1)]:
                    if 0 <= nx < w and 0 <= ny < h and grid[ny][nx] is not None:
                        out[y][x] = OUTLINE[:3]
                        break
    return out

def to_img(grid, w, h):
    img = Image.new("RGBA", (w, h), (0,0,0,0))
    for y in range(h):
        for x in range(w):
            if grid[y][x]:
                img.putpixel((x,y), (*grid[y][x], 255))
    return img

# ---- fish icon: simple side-view fish, 12x8 native ----
RARITY_COLORS = {
    "common": (150, 190, 110), "uncommon": (95, 200, 200),
    "rare": (170, 130, 225), "epic": (230, 195, 95), "legendary": (240, 140, 200),
}
W, H = 14, 10
for rarity, color in RARITY_COLORS.items():
    g = [[None]*W for _ in range(H)]
    dark = tuple(int(c*0.65) for c in color)
    # body
    for y in range(2,8):
        for x in range(2,10):
            g[y][x] = color
    # tail
    for y in range(3,7):
        g[y][10] = dark; g[y][11] = dark if y in (4,5) else None
    for y in (2,7):
        for x in range(2,10):
            g[y][x] = dark
    g[4][3] = (20,20,25)  # eye
    g = outline_grid(g, W, H)
    to_img(g, W, H).save(os.path.join(OUT, f"fish_{rarity}.png"))
print("fish icons done")

# ---- house structure: small cozy cat-house, 32x28 ----
W, H = 32, 28
g = [[None]*W for _ in range(H)]
roof = (196, 90, 90); roof_dark = (156, 66, 66)
wall = (222, 178, 132); wall_dark = (188, 142, 100)
door = (110, 74, 50)
for y in range(0, 10):
    span = y
    for x in range(15-span, 17+span):
        if 0 <= x < W:
            g[y][x] = roof if y < 8 else roof_dark
for y in range(10, 26):
    for x in range(6, 26):
        g[y][x] = wall
for x in range(6, 26):
    g[25][x] = wall_dark
for y in range(16, 26):
    for x in range(14, 19):
        g[y][x] = door
for y in range(13, 16):
    for x in range(9, 13):
        g[y][x] = (140, 200, 220)
    for x in range(19, 23):
        g[y][x] = (140, 200, 220)
g = outline_grid(g, W, H)
to_img(g, W, H).save(os.path.join(OUT, "house_icon.png"))
print("house icon done")
