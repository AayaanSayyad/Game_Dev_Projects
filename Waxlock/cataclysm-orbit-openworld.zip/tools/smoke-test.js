/*
 * Headless smoke test for Cataclysm Orbit (open-world build).
 *
 * Loads index.html's real script pipeline in jsdom + node-canvas (no
 * browser needed), drives it with simulated input and DOM events, and
 * fails loudly on any thrown error or wrong result. Specifically checks
 * the two systems that were reported broken in the previous build
 * (melee contact damage, fish -> vault -> EXP).
 *
 * Setup (one-time):  cd tools && npm install jsdom canvas
 * Run:                node tools/smoke-test.js
 */
const { JSDOM } = require('jsdom');
const fs = require('fs');
const path = require('path');

const GAME_DIR = path.join(__dirname, '..');
const html = fs.readFileSync(path.join(GAME_DIR, 'index.html'), 'utf8');
const dom = new JSDOM(html, { url: 'http://localhost/', runScripts: 'outside-only', resources: 'usable', pretendToBeVisual: true });
const { window } = dom;

const store = {};
window.localStorage = {
	getItem: (k) => (k in store ? store[k] : null),
	setItem: (k, v) => { store[k] = String(v); },
	removeItem: (k) => { delete store[k]; },
};
window.requestAnimationFrame = () => 0;
window.performance = window.performance || { now: () => Date.now() };
window.HTMLMediaElement.prototype.play = function () { return Promise.resolve(); };
window.HTMLMediaElement.prototype.pause = function () {};

let haveCanvas = false;
try {
	const { createCanvas, Image } = require('canvas');
	window.HTMLCanvasElement.prototype.getContext = function (type) {
		if (!this._nodeCanvas) this._nodeCanvas = createCanvas(this.width || 300, this.height || 150);
		if (this._nodeCanvas.width !== this.width) this._nodeCanvas.width = this.width || 300;
		if (this._nodeCanvas.height !== this.height) this._nodeCanvas.height = this.height || 150;
		return this._nodeCanvas.getContext(type);
	};
	class GameImage extends Image {
		set src(v) {
			let p = v.startsWith('http://localhost/') ? v.replace('http://localhost/', '') : v;
			try { super.src = fs.readFileSync(path.join(GAME_DIR, p)); }
			catch (e) { setTimeout(() => { if (this.onerror) this.onerror(e); }, 0); }
		}
		get src() { return super.src; }
	}
	window.Image = GameImage;
	haveCanvas = true;
} catch (e) {
	console.log('(no `canvas` package found — sprites will fail to "load" but scene logic still runs)');
	function noopCtx() { const h = { get(t, p) { if (p === 'canvas') return {}; return function () {}; } }; return new Proxy({}, h); }
	window.HTMLCanvasElement.prototype.getContext = () => noopCtx();
}

let errorCount = 0;
window.addEventListener('error', (e) => { errorCount++; console.error('WINDOW ERROR:', e.error ? (e.error.stack || e.error.message) : e.message); });
process.on('unhandledRejection', (e) => { errorCount++; console.error('UNHANDLED REJECTION:', e); });
process.on('uncaughtException', (e) => { errorCount++; console.error('UNCAUGHT EXCEPTION:', e.stack || e.message); });

const scripts = [
	'js/engine/sprite-loader.js', 'js/data/fish-data.js', 'js/data/game-data.js', 'js/data/biome-data.js',
	'js/engine/game-state.js', 'js/engine/input.js', 'js/engine/audio-mgr.js', 'js/engine/game.js',
	'js/world/tilemap.js', 'js/world/entities.js',
	'js/scenes/tutorial.js', 'js/scenes/start-scene.js', 'js/scenes/house-scene.js', 'js/scenes/world-scene.js',
];
for (const s of scripts) {
	try { window.eval(fs.readFileSync(path.join(GAME_DIR, s), 'utf8')); }
	catch (e) { errorCount++; console.error(`ERROR loading ${s}:`, e.stack || e.message); }
}

const Game = window.Game, GS = window.GameState;

function tick(n, dt) {
	dt = dt || 0.05;
	for (let i = 0; i < n; i++) {
		Game.t += dt;
		try {
			if (Game.current && Game.current.update) Game.current.update(dt, Game.t);
			if (haveCanvas) { Game.ctx.clearRect(0, 0, Game.W, Game.H); if (Game.current && Game.current.render) Game.current.render(Game.ctx, Game.t); }
		} catch (e) { errorCount++; console.error(`TICK ERROR on '${Game.currentName}':`, e.stack || e.message); return false; }
		window.Input.endFrame();
	}
	return true;
}

async function main() {
	Game.init();
	await new Promise((r) => setTimeout(r, 400));
	for (let i = 0; i < 10 && !Game.ready; i++) { if (window.Sprites.allLoaded()) { Game.ready = true; Game.goto('start'); } await new Promise((r) => setTimeout(r, 50)); }
	console.log('[ok] Game.init() + preload ->', Game.currentName);

	window.document.querySelector('.btn-play').dispatchEvent(new window.MouseEvent('click', { bubbles: true }));
	tick(3);
	console.log(`[${Game.currentName === 'house' ? 'ok' : 'FAIL'}] Start -> House`);

	for (const label of ['Roster Nest', 'Fish Vault', 'Blueprint Wall']) {
		const btn = [...window.document.querySelectorAll('.hotspot-btn')].find((b) => b.textContent === label);
		if (!btn) { errorCount++; console.error('MISSING hotspot button:', label); continue; }
		btn.click(); tick(2);
		console.log(`[${window.document.querySelector('.panel') ? 'ok' : 'FAIL'}] panel opens: ${label}`);
		window.document.querySelector('.btn-close')?.click(); tick(1);
	}

	[...window.document.querySelectorAll('.hotspot-btn')].find((b) => b.textContent === 'Leave House').click();
	tick(3);
	console.log(`[${Game.currentName === 'world' ? 'ok' : 'FAIL'}] House -> World, tutorial shown: ${!!window.document.querySelector('.tutorial-overlay')}`);
	window.document.querySelector('.tutorial-overlay')?.remove();
	Game.current.player.frozen = false;

	// --- the two previously-reported-broken systems ---
	const WE = window.WorldEntities;
	const w = Game.current;
	const heartsBefore = GS.heartsCurrent;
	w.player.invulnT = 0;
	const grub = new WE.Enemy('grub', w.player.pos.x, w.player.pos.y, 1, w, false);
	w.enemies.push(grub);
	tick(3);
	console.log(`[${GS.heartsCurrent < heartsBefore ? 'ok' : 'FAIL'}] melee contact damage applies (${heartsBefore} -> ${GS.heartsCurrent})`);

	const vaultBefore = GS.vaultTotal();
	w.pickups.push(new WE.FishPickup(w.player.pos.x, w.player.pos.y, 'sardine_rotten', 'Common'));
	tick(3);
	const gained = GS.convertVaultToExp();
	console.log(`[${GS.vaultTotal() >= vaultBefore && gained > 0 ? 'ok' : 'FAIL'}] fish pickup -> vault -> EXP conversion (gained ${gained} EXP)`);

	// --- extended stability ---
	window.Input.mouse.down = true;
	let ok = true;
	for (let b = 0; b < 40 && ok; b++) {
		const ang = b * 0.3;
		window.Input.mouse.x = w.player.pos.x + Math.cos(ang) * 200 - w.camera.x;
		window.Input.mouse.y = w.player.pos.y + Math.sin(ang) * 150 - w.camera.y;
		window.Input.keys['KeyD'] = Math.cos(ang) > 0; window.Input.keys['KeyA'] = Math.cos(ang) <= 0;
		ok = tick(30);
	}
	console.log(`[${ok ? 'ok' : 'FAIL'}] ~60s simulated open-world play without throwing`);

	console.log(`\n${errorCount === 0 ? 'PASS' : 'FAIL'} — ${errorCount} error(s).`);
	process.exit(errorCount > 0 ? 1 : 0);
}
main();
