import numpy as np, wave, struct, os, math

SR = 22050
OUT = "../assets/audio"
os.makedirs(OUT, exist_ok=True)

def save_wav(samples, name):
    samples = np.clip(samples, -1.0, 1.0)
    pcm = (samples * 32767).astype(np.int16)
    path = os.path.join(OUT, name)
    with wave.open(path, "w") as f:
        f.setnchannels(1)
        f.setsampwidth(2)
        f.setframerate(SR)
        f.writeframes(pcm.tobytes())
    print("wrote", path, f"{len(samples)/SR:.2f}s")

def env_ad(n, attack=0.02, decay=0.3):
    t = np.linspace(0, 1, n)
    a = np.clip(t / max(attack, 1e-4), 0, 1)
    d = np.exp(-t / max(decay, 1e-4))
    return np.minimum(a, 1.0) * d

def tone(freq, dur, wave_type="square", vol=0.3, attack=0.01, decay=0.25, vibrato=0.0, glide_to=None):
    n = int(SR * dur)
    t = np.arange(n) / SR
    f = np.full(n, freq, dtype=float)
    if glide_to is not None:
        f = np.linspace(freq, glide_to, n)
    if vibrato > 0:
        f = f * (1.0 + 0.02 * np.sin(2*np.pi*vibrato*t))
    phase = 2*np.pi*np.cumsum(f)/SR
    if wave_type == "square":
        s = np.sign(np.sin(phase))
    elif wave_type == "tri":
        s = 2*np.abs(2*(phase/(2*np.pi) - np.floor(phase/(2*np.pi)+0.5)))-1
    elif wave_type == "sine":
        s = np.sin(phase)
    else:
        s = np.sin(phase)
    s *= env_ad(n, attack, decay) * vol
    return s

def noise_burst(dur, vol=0.25, hp=0.0, decay=0.15):
    n = int(SR*dur)
    s = (np.random.rand(n)*2-1)
    if hp > 0:
        # crude high-pass via differencing
        s = np.diff(s, prepend=0)
    s *= env_ad(n, 0.005, decay) * vol
    return s

def chain(*parts):
    return np.concatenate(parts)

def mix(*parts):
    n = max(len(p) for p in parts)
    out = np.zeros(n)
    for p in parts:
        out[:len(p)] += p
    return out

def silence(dur):
    return np.zeros(int(SR*dur))

# ---- SFX -------------------------------------------------------------
save_wav(tone(880, 0.05, "square", 0.35, 0.002, 0.05), "sfx_hit.wav")

save_wav(chain(tone(500, 0.05, "tri", 0.3, 0.002, 0.05, glide_to=180),
                tone(180, 0.08, "tri", 0.25, 0.001, 0.08, glide_to=90)), "sfx_splat.wav")

save_wav(tone(660, 0.07, "sine", 0.3, 0.002, 0.09, glide_to=880), "sfx_pickup_common.wav")
save_wav(tone(780, 0.08, "sine", 0.32, 0.002, 0.1, glide_to=1040), "sfx_pickup_uncommon.wav")
save_wav(chain(tone(880,0.05,"sine",0.3,0.001,0.05, glide_to=1180), tone(1180,0.06,"sine",0.28,0.001,0.08,glide_to=1400)), "sfx_pickup_rare.wav")

save_wav(noise_burst(0.14, 0.22, hp=1.0, decay=0.09), "sfx_dash.wav")

save_wav(chain(tone(523,0.08,"square",0.25,0.002,0.08), tone(659,0.08,"square",0.25,0.002,0.08), tone(784,0.14,"square",0.28,0.002,0.14)), "sfx_wave_clear.wav")

save_wav(mix(tone(392,0.5,"tri",0.22,0.01,0.5), tone(523,0.5,"tri",0.18,0.01,0.5), tone(659,0.5,"tri",0.16,0.01,0.5)), "sfx_milestone.wav")

save_wav(chain(tone(300,0.06,"square",0.3,0.001,0.06,glide_to=160), tone(160,0.1,"square",0.25,0.001,0.1,glide_to=90)), "sfx_player_hurt.wav")

save_wav(chain(tone(700,0.04,"square",0.25,0.001,0.04), tone(1050,0.06,"square",0.28,0.001,0.07)), "sfx_purchase.wav")

save_wav(chain(tone(220,0.05,"square",0.25,0.001,0.05), tone(140,0.12,"square",0.2,0.001,0.12,glide_to=80)), "sfx_death.wav")

save_wav(mix(tone(440,0.35,"tri",0.25,0.01,0.35), tone(554,0.35,"tri",0.2,0.01,0.35)), "sfx_skill.wav")

save_wav(tone(1046, 0.05, "square", 0.2, 0.001, 0.05), "sfx_ui_move.wav")
save_wav(chain(tone(660,0.05,"square",0.28,0.001,0.05), tone(990,0.08,"square",0.28,0.001,0.09)), "sfx_ui_confirm.wav")

# telegraph "wind up" whine for enemy attacks
n = int(SR*0.75)
t = np.arange(n)/SR
f = np.linspace(180, 520, n)
phase = 2*np.pi*np.cumsum(f)/SR
s = np.sin(phase) * np.linspace(0.05, 0.32, n)
save_wav(s, "sfx_telegraph.wav")

# ---- MUSIC BEDS (short, seamless-ish loops) --------------------------
def pad_chord(freqs, dur, vol=0.12):
    parts = [tone(f, dur, "sine", vol, 0.4, dur*0.9) for f in freqs]
    return mix(*parts)

house = mix(
    pad_chord([196.0, 246.94, 293.66], 4.0, 0.10),   # G major-ish pad
    chain(silence(2.0), pad_chord([220.0, 277.18, 329.63], 2.0, 0.07)),
)
save_wav(house, "music_house_loop.wav")

def blip(freq, t0, dur=0.12, vol=0.14):
    s = tone(freq, dur, "square", vol, 0.002, dur*0.8)
    pad = silence(0)
    return s

notes = [262,294,330,262, 294,330,349,330, 262,294,330,262, 349,330,294,262]
combat_parts = []
step = 0.28
for i, note in enumerate(notes):
    combat_parts.append(silence(step*i))
combat = np.zeros(int(SR*step*len(notes)+SR*0.3))
for i, note in enumerate(notes):
    b = tone(note, 0.14, "square", 0.12, 0.002, 0.12)
    start = int(SR*step*i)
    combat[start:start+len(b)] += b
save_wav(combat, "music_combat_loop.wav")

print("DONE")
