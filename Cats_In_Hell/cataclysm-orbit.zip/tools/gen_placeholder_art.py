"""
Procedural placeholder-art generator for Cataclysm Orbit.
Produces small, clean, cute pixel-ish PNGs (no external assets) so the
project has real visuals in place of gray boxes. Everything is drawn with
PIL primitives at a small canvas size then left un-antialiased-ish for a
pixel-art feel (nearest-neighbour friendly).
"""
import math, random, os
from PIL import Image, ImageDraw

OUT = "../assets/sprites"
random.seed(7)

def canvas(w, h):
    return Image.new("RGBA", (w, h), (0, 0, 0, 0))

def save(img, path, scale=1):
    if scale != 1:
        img = img.resize((img.width * scale, img.height * scale), Image.NEAREST)
    full = os.path.join(OUT, path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    img.save(full)
    print("wrote", full, img.size)

def outline_ellipse(d, box, fill, outline=(30, 20, 25, 255), width=1):
    d.ellipse(box, fill=fill, outline=outline, width=width)

def darken(c, amt=0.75):
    return (int(c[0]*amt), int(c[1]*amt), int(c[2]*amt), c[3] if len(c) > 3 else 255)

def lighten(c, amt=1.25):
    return (min(255,int(c[0]*amt)), min(255,int(c[1]*amt)), min(255,int(c[2]*amt)), c[3] if len(c) > 3 else 255)

# ---------------------------------------------------------------- CATS -----
def draw_cat(body_color, marking_color, eye_color=(30, 30, 35, 255), accent=None, pose="idle"):
    """32x32 chibi cat, facing 'down' (south), simple iso-friendly blob shape."""
    W = H = 32
    img = canvas(W, H)
    d = ImageDraw.Draw(img)
    cx, cy = 16, 19
    # shadow
    d.ellipse((cx-9, 27, cx+9, 31), fill=(10, 10, 15, 90))
    # tail (curled, behind body)
    tail_col = darken(body_color, 0.9)
    d.line([(cx+8,20),(cx+13,16),(cx+12,10),(cx+8,9)], fill=tail_col, width=3, joint="curve")
    # ears
    ear = darken(body_color, 0.85)
    d.polygon([(cx-9,7),(cx-13,-1+8),(cx-4,6)], fill=body_color, outline=(30,20,25,255))
    d.polygon([(cx+9,7),(cx+13,-1+8),(cx+4,6)], fill=body_color, outline=(30,20,25,255))
    d.polygon([(cx-8,7),(cx-10,2+8),(cx-5,6.5)], fill=(255,190,200,255))
    d.polygon([(cx+8,7),(cx+10,2+8),(cx+5,6.5)], fill=(255,190,200,255))
    # body
    outline_ellipse(d, (cx-10, cy-11, cx+10, cy+11), fill=body_color)
    # belly marking
    d.ellipse((cx-5, cy-2, cx+5, cy+9), fill=marking_color)
    # stripes / spots
    for sx, sy, sw, sh in [(-8,-6,5,3),(4,-8,5,3),(-9,1,4,3)]:
        d.ellipse((cx+sx, cy+sy, cx+sx+sw, cy+sy+sh), fill=marking_color)
    # face
    d.ellipse((cx-3, cy-4, cx-1, cy-2), fill=eye_color)  # left eye
    d.ellipse((cx+1, cy-4, cx+3, cy-2), fill=eye_color)  # right eye
    d.polygon([(cx-1, cy-1), (cx+1, cy-1), (cx, cy+1)], fill=(255,150,170,255))  # nose
    # whiskers
    for dy in (-1, 1, 3):
        d.line([(cx-9, cy+dy), (cx-4, cy+dy-1)], fill=(255,255,255,160), width=1)
        d.line([(cx+9, cy+dy), (cx+4, cy+dy-1)], fill=(255,255,255,160), width=1)
    # paws
    d.ellipse((cx-8,cy+7,cx-2,cy+12), fill=body_color, outline=(30,20,25,255))
    d.ellipse((cx+2,cy+7,cx+8,cy+12), fill=body_color, outline=(30,20,25,255))
    if accent:
        accent(d, cx, cy)
    return img

def gen_cats():
    # Stray - orange tabby, Scratch Claws
    def stray_accent(d, cx, cy):
        d.line([(cx-14,cy+2),(cx-10,cy-2)], fill=(230,230,230,255), width=2)
        d.line([(cx-12,cy+4),(cx-8,cy+0)], fill=(230,230,230,255), width=2)
    img = draw_cat((235,140,60,255), (255,214,168,255), accent=stray_accent)
    save(img, "cats/stray.png", scale=3)

    # Brick - reddish brown, Hairball Slingshot
    def brick_accent(d, cx, cy):
        d.ellipse((cx+9, cy+1, cx+15, cy+7), outline=(90,60,40,255), width=2)
        d.line([(cx+12,cy+1),(cx+12,cy+7)], fill=(90,60,40,255), width=1)
    img = draw_cat((160,80,60,255), (224,170,140,255), accent=brick_accent)
    save(img, "cats/brick.png", scale=3)

    # Soot - black/grey, Rusty Forge Hammer
    def soot_accent(d, cx, cy):
        d.rectangle((cx+9, cy-6, cx+12, cy+4), fill=(120,110,105,255), outline=(40,35,30,255))
        d.rectangle((cx+6, cy-9, cx+15, cy-5), fill=(150,90,60,255), outline=(40,35,30,255))
    img = draw_cat((60,60,68,255), (150,150,160,255), eye_color=(230,220,60,255), accent=soot_accent)
    save(img, "cats/soot.png", scale=3)

    # Miso - cream/white, Purr Charm
    def miso_accent(d, cx, cy):
        d.ellipse((cx-14, cy-2, cx-9, cy+3), fill=(255,120,170,255), outline=(120,40,70,255))
    img = draw_cat((245,230,200,255), (255,250,240,255), accent=miso_accent)
    save(img, "cats/miso.png", scale=3)

def gen_amiibo():
    for name in ["stray", "brick", "soot", "miso"]:
        img = Image.open(os.path.join(OUT, f"cats/{name}.png")).convert("RGBA")
        small = img.resize((16, 16), Image.LANCZOS)
        # glassy shrink bubble
        bub = canvas(24, 24)
        bd = ImageDraw.Draw(bub)
        bd.ellipse((0,0,23,23), fill=(150,220,255,70), outline=(210,245,255,190), width=2)
        bub.alpha_composite(small, (4, 4))
        save(bub, f"cats/{name}_amiibo.png", scale=2)

# -------------------------------------------------------------- ENEMIES ----
def gen_grub():
    W=H=28
    img = canvas(W,H)
    d = ImageDraw.Draw(img)
    cx,cy=14,16
    d.ellipse((cx-8,26,cx+8,28), fill=(10,10,15,80))
    body=(120,190,70,255)
    outline_ellipse(d,(cx-9,cy-8,cx+9,cy+10), fill=body)
    for i,seg in enumerate([-6,-1,4]):
        d.line([(cx-9,cy+seg),(cx+9,cy+seg)], fill=darken(body,0.8), width=1)
    d.ellipse((cx-4,cy-6,cx-1,cy-3), fill=(20,20,20,255))
    d.ellipse((cx+1,cy-6,cx+4,cy-3), fill=(20,20,20,255))
    d.polygon([(cx-6,cy-9),(cx-3,cy-9),(cx-5,cy-13)], fill=(90,150,50,255))
    d.polygon([(cx+6,cy-9),(cx+3,cy-9),(cx+5,cy-13)], fill=(90,150,50,255))
    save(img, "enemies/grub.png", scale=3)

def gen_spitter():
    W=H=28
    img = canvas(W,H)
    d = ImageDraw.Draw(img)
    cx,cy=14,16
    d.ellipse((cx-8,26,cx+8,28), fill=(10,10,15,80))
    body=(150,90,190,255)
    outline_ellipse(d,(cx-9,cy-9,cx+9,cy+9), fill=body)
    d.ellipse((cx-8,cy-3,cx+8,cy+8), fill=lighten(body,1.15))
    d.ellipse((cx-3,cy-3,cx,cy0:=0+cy) if False else (cx-3,cy-3,cx,cy), fill=(230,255,120,255))
    d.ellipse((cx-4,cy-5,cx-1,cy-2), fill=(20,20,20,255))
    d.ellipse((cx+1,cy-5,cx+4,cy-2), fill=(20,20,20,255))
    d.ellipse((cx-2,cy+2,cx+2,cy+6), fill=(60,20,70,255), outline=(20,10,25,255))  # spore mouth
    save(img, "enemies/spitter.png", scale=3)

def gen_trash_golem():
    W=H=48
    img = canvas(W,H)
    d = ImageDraw.Draw(img)
    cx,cy=24,26
    d.ellipse((cx-16,44,cx+16,47), fill=(10,10,15,100))
    body=(110,120,100,255)
    d.rectangle((cx-15,cy-16,cx+15,cy+16), fill=body, outline=(40,40,35,255), width=2)
    for (rx,ry,rw,rh,c) in [(-10,-12,8,6,(150,60,50,255)),(2,-10,9,7,(90,140,160,255)),
                              (-11,0,7,8,(180,170,60,255)),(1,2,10,9,(120,90,150,255))]:
        d.rectangle((cx+rx,cy+ry,cx+rx+rw,cy+ry+rh), fill=c, outline=(40,40,35,255))
    d.ellipse((cx-8,cy-6,cx-3,cy-1), fill=(255,60,60,255))
    d.ellipse((cx+3,cy-6,cx+8,cy-1), fill=(255,60,60,255))
    save(img, "enemies/trash_golem.png", scale=3)

def gen_mite():
    W=H=16
    img=canvas(W,H)
    d=ImageDraw.Draw(img)
    cx,cy=8,9
    body=(220,90,110,255)
    outline_ellipse(d,(cx-6,cy-5,cx+6,cy+5), fill=body)
    d.ellipse((cx-2,cy-2,cx,cy), fill=(20,20,20,255))
    d.ellipse((cx+0,cy-2,cx+2,cy), fill=(20,20,20,255))
    for a in (-1,1):
        d.line([(cx+a*5,cy),(cx+a*8,cy-3)], fill=darken(body), width=1)
        d.line([(cx+a*5,cy+2),(cx+a*8,cy+4)], fill=darken(body), width=1)
    save(img, "enemies/mite.png", scale=3)

# ---------------------------------------------------------------- FISH -----
RARITY_COLORS = {
    "Common": (120,150,110,255),
    "Uncommon": (70,190,190,255),
    "Rare": (150,110,220,255),
    "Epic": (225,190,60,255),
    "Legendary": (240,120,200,255),
}
def gen_fish():
    for rarity, col in RARITY_COLORS.items():
        W=H=16
        img=canvas(W,H)
        d=ImageDraw.Draw(img)
        d.polygon([(2,8),(11,3),(14,8),(11,13)], fill=col, outline=(25,20,20,255))
        d.polygon([(2,8),(-2,4),(-2,12)], fill=darken(col))
        d.ellipse((9,6,11,8), fill=(20,20,20,255))
        d.line([(4,6),(8,8),(4,10)], fill=lighten(col,1.3), width=1)
        # rarity glow ring
        glow = canvas(20,20)
        gd = ImageDraw.Draw(glow)
        gd.ellipse((0,0,19,19), outline=(*col[:3],140), width=2)
        glow.alpha_composite(img, (2,2))
        save(glow, f"fish/fish_{rarity.lower()}.png", scale=3)

# ------------------------------------------------------------------ FX -----
def gen_fx():
    # splat decals (green / purple cartoon goo, no red)
    for name, col in [("green", (110,180,70,255)), ("purple", (150,90,190,255))]:
        W=H=32
        img=canvas(W,H)
        d=ImageDraw.Draw(img)
        random.seed(hash(name) % 1000)
        for _ in range(7):
            r = random.randint(3,9)
            x = 16+random.randint(-9,9)
            y = 16+random.randint(-9,9)
            d.ellipse((x-r,y-r,x+r,y+r), fill=(*col[:3], random.randint(90,150)))
        for _ in range(4):
            x=16+random.randint(-6,6); y=16+random.randint(-6,6)
            d.ellipse((x-1,y-1,x+3,y+3), fill=(255,255,255,180))  # star sparkle bits
        save(img, f"fx/splat_{name}.png", scale=2)

    # small particle dot for pooled bursts
    img=canvas(8,8)
    d=ImageDraw.Draw(img)
    d.ellipse((0,0,7,7), fill=(255,255,255,255))
    save(img, "fx/spark.png", scale=1)

    # telegraph ring (enemy wind-up indicator)
    img=canvas(64,64)
    d=ImageDraw.Draw(img)
    d.ellipse((2,2,61,61), outline=(255,90,90,220), width=4)
    save(img, "fx/telegraph_ring.png", scale=1)

    # hit flash star burst
    img=canvas(24,24)
    d=ImageDraw.Draw(img)
    d.polygon([(12,0),(15,9),(24,12),(15,15),(12,24),(9,15),(0,12),(9,9)], fill=(255,255,255,230))
    save(img, "fx/hitflash.png", scale=1)

# --------------------------------------------------------------- BULLETS ---
def gen_bullets():
    img=canvas(10,10)
    d=ImageDraw.Draw(img)
    d.ellipse((1,1,8,8), fill=(255,235,140,255), outline=(200,140,20,255))
    save(img, "fx/bullet_player.png", scale=2)

    img=canvas(10,10)
    d=ImageDraw.Draw(img)
    d.ellipse((1,1,8,8), fill=(190,110,230,255), outline=(90,40,120,255))
    save(img, "fx/bullet_enemy.png", scale=2)

    img=canvas(12,12)
    d=ImageDraw.Draw(img)
    d.ellipse((1,1,10,10), fill=(255,180,90,255), outline=(150,80,20,255))
    d.ellipse((3,3,8,8), fill=(255,230,180,255))
    save(img, "fx/bullet_lob.png", scale=2)

# ---------------------------------------------------------------- ENV ------
def gen_iso_tile():
    # 64x32 diamond tile, pixel-snap friendly
    W,H=64,32
    img=canvas(W,H)
    d=ImageDraw.Draw(img)
    top=(150,215,150,255)
    d.polygon([(32,0),(63,16),(32,31),(0,16)], fill=top, outline=(70,120,70,255))
    d.line([(32,0),(0,16)], fill=lighten(top,1.15), width=1)
    save(img, "env/tile_ground.png", scale=2)

    img=canvas(W,H)
    d=ImageDraw.Draw(img)
    top=(120,150,235,255)
    d.polygon([(32,0),(63,16),(32,31),(0,16)], fill=top, outline=(50,70,140,255))
    save(img, "env/tile_arena.png", scale=2)

    img=canvas(W,H)
    d=ImageDraw.Draw(img)
    top=(210,170,110,255)
    d.polygon([(32,0),(63,16),(32,31),(0,16)], fill=top, outline=(130,90,50,255))
    save(img, "env/tile_house.png", scale=2)

def gen_house_bg():
    W,H=480,270
    img=canvas(W,H)
    d=ImageDraw.Draw(img)
    # sky gradient (evening, litter-planet)
    for y in range(H):
        t=y/H
        c=(int(30+40*t), int(15+30*t), int(45+60*(1-t)))
        d.line([(0,y),(W,y)], fill=c)
    # stars
    random.seed(3)
    for _ in range(70):
        x=random.randint(0,W-1); y=random.randint(0,int(H*0.55))
        b=random.randint(120,255)
        d.point((x,y), fill=(b,b,b,255))
    # planet horizon curve (little moon rock in bg)
    d.ellipse((-120,140,180,420), fill=(70,60,90,255))
    # ground platform (iso diamond big)
    cx,cy=240,190
    d.polygon([(cx,cy-70),(cx+190,cy+35),(cx,cy+140),(cx-190,cy+35)], fill=(110,150,110,255), outline=(60,90,60,255), width=3)
    d.polygon([(cx,cy-70+10),(cx+175,cy+40),(cx,cy+130),(cx-175,cy+40)], fill=(130,175,130,255))
    # house structure (cardboard-box cat house)
    hx,hy=cx-40,cy-40
    d.polygon([(hx,hy),(hx+110,hy+10),(hx+110,hy+90),(hx,hy+80)], fill=(190,140,90,255), outline=(110,75,40,255), width=2)
    d.polygon([(hx,hy),(hx-55,hy+35),(hx-55,hy+115),(hx,hy+80)], fill=(160,115,70,255), outline=(100,65,35,255), width=2)
    d.polygon([(hx-55,hy+35),(hx,hy),(hx+110,hy+10),(hx+55,hy-25)], fill=(225,90,90,255), outline=(120,50,40,255), width=2)  # roof
    d.ellipse((hx+15,hy+40,hx+55,hy+80), fill=(60,40,30,255))  # door hole
    # small fish-bone flag
    d.line([(hx+55,hy-25),(hx+55,hy-55)], fill=(90,70,50,255), width=2)
    d.polygon([(hx+55,hy-55),(hx+80,hy-48),(hx+55,hy-40)], fill=(240,220,150,255))
    # crates around (hotspot landmarks): forge, vault, blueprint, radio
    def crate(x,y,w,h,col):
        d.rectangle((x,y,x+w,y+h), fill=col, outline=(40,30,25,255), width=2)
        d.line([(x,y),(x+w,y+h)], fill=darken(col), width=1)
    crate(cx-165,cy+10,44,34,(150,110,80,255))   # rescue radio crate
    crate(cx+120,cy+8,46,36,(90,110,150,255))    # fish vault crate
    crate(cx-60,cy+70,50,30,(120,130,90,255))    # blueprint wall crate
    crate(cx+55,cy+75,46,28,(150,90,90,255))     # forge / gear rack
    # launch pad ring (front center)
    d.ellipse((cx-45,cy+95,cx+45,cy+125), outline=(255,220,120,255), width=3)
    d.ellipse((cx-25,cy+102,cx+25,cy+118), outline=(255,220,120,180), width=2)
    save(img, "env/house_bg.png", scale=1)

def gen_arena_bg():
    W,H=480,270
    img=canvas(W,H)
    d=ImageDraw.Draw(img)
    for y in range(H):
        t=y/H
        c=(int(20+20*t), int(10+20*t), int(35+40*(1-t)))
        d.line([(0,y),(W,y)], fill=c)
    random.seed(9)
    for _ in range(90):
        x=random.randint(0,W-1); y=random.randint(0,int(H*0.5))
        b=random.randint(120,255)
        d.point((x,y), fill=(b,b,b,255))
    cx,cy=240,150
    d.polygon([(cx,cy-90),(cx+230,cy+30),(cx,cy+150),(cx-230,cy+30)], fill=(70,90,140,255), outline=(40,55,100,255), width=3)
    d.polygon([(cx,cy-78),(cx+210,cy+34),(cx,cy+138),(cx-210,cy+34)], fill=(90,115,170,255))
    # arena boundary glow ring
    d.polygon([(cx,cy-78),(cx+210,cy+34),(cx,cy+138),(cx-210,cy+34)], outline=(180,220,255,140), width=2)
    save(img, "env/arena_bg.png", scale=1)

# ----------------------------------------------------------------- UI ------
def gen_ui():
    img=canvas(16,16)
    d=ImageDraw.Draw(img)
    d.polygon([(8,3),(11,0),(15,3),(15,7),(8,15),(1,7),(1,3),(5,0)], fill=(255,90,120,255), outline=(140,30,50,255))
    save(img, "ui/heart_full.png", scale=2)

    img=canvas(16,16)
    d=ImageDraw.Draw(img)
    d.polygon([(8,3),(11,0),(15,3),(15,7),(8,15),(1,7),(1,3),(5,0)], fill=(70,60,70,255), outline=(30,25,30,255))
    save(img, "ui/heart_empty.png", scale=2)

    img=canvas(16,16)
    d=ImageDraw.Draw(img)
    d.polygon([(8,3),(11,0),(15,3),(15,7),(8,15),(1,7),(1,3),(5,0)], fill=(255,220,90,255), outline=(160,120,20,255))
    save(img, "ui/heart_half.png", scale=2)

    for name, col in [("dash",(120,220,255,255)), ("skill",(255,180,90,255))]:
        img=canvas(16,16)
        d=ImageDraw.Draw(img)
        d.ellipse((0,0,15,15), fill=col, outline=(30,30,40,255))
        save(img, f"ui/icon_{name}.png", scale=2)

    # simple fish-bone cursor icon for pointer hotspots (optional use)
    img=canvas(16,16)
    d=ImageDraw.Draw(img)
    d.line([(2,2),(13,13)], fill=(255,255,255,255), width=2)
    save(img, "ui/hotspot_marker.png", scale=2)

if __name__ == "__main__":
    gen_cats()
    gen_amiibo()
    gen_grub()
    gen_spitter()
    gen_trash_golem()
    gen_mite()
    gen_fish()
    gen_fx()
    gen_bullets()
    gen_iso_tile()
    gen_house_bg()
    gen_arena_bg()
    gen_ui()
    print("DONE")
