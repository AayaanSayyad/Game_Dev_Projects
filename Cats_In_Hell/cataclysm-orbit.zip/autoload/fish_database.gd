extends Node
## FishDatabase — autoload singleton.
## Holds the 12-species rotten-fish table from the design doc (section 8).
## Fish are NOT fungible currency: every pickup is species_id + rarity.
## `v1_active` species are the ones that can actually drop in this build
## (Litter Prime / Planet 1 slice). The rest are modelled now so future
## planets are pure data additions, no code changes.

enum Rarity { COMMON, UNCOMMON, RARE, EPIC, LEGENDARY }

const RARITY_NAMES := ["Common", "Uncommon", "Rare", "Epic", "Legendary"]

# Global drop-weight tables (design doc section 8).
const DROP_WEIGHTS_NORMAL := {
	Rarity.COMMON: 0.70, Rarity.UNCOMMON: 0.22, Rarity.RARE: 0.06,
	Rarity.EPIC: 0.018, Rarity.LEGENDARY: 0.002,
}
const DROP_WEIGHTS_ELITE := {
	Rarity.COMMON: 0.40, Rarity.UNCOMMON: 0.35, Rarity.RARE: 0.18,
	Rarity.EPIC: 0.05, Rarity.LEGENDARY: 0.02,
}

# species_id -> data
var species := {
	"sardine_rotten": {"name": "Sardine", "planets": ["litter_prime"], "base_exp": 2, "use": "Basic EXP, early upgrades", "v1_active": true},
	"mackerel_foul":  {"name": "Mackerel", "planets": ["litter_prime"], "base_exp": 3, "use": "Forge tier 1", "v1_active": true},
	"tuna_mold":      {"name": "Tuna", "planets": ["litter_prime", "ring_of_yarn"], "base_exp": 5, "use": "Ammo crafting", "v1_active": true},
	"salmon_sour":    {"name": "Salmon", "planets": ["ring_of_yarn"], "base_exp": 6, "use": "Healer Amiibo unlock", "v1_active": false},
	"herring_haunt":  {"name": "Herring", "planets": ["ring_of_yarn"], "base_exp": 6, "use": "Signal tower", "v1_active": false},
	"squid_inked":    {"name": "Squid", "planets": ["ring_of_yarn", "fishbone_nebula"], "base_exp": 7, "use": "Mage gear", "v1_active": false},
	"crab_old":       {"name": "Crab", "planets": ["fishbone_nebula"], "base_exp": 8, "use": "Tank armor", "v1_active": false},
	"eel_coil":       {"name": "Eel", "planets": ["fishbone_nebula"], "base_exp": 8, "use": "Dash mods", "v1_active": false},
	"lobster_red":    {"name": "Lobster", "planets": ["fishbone_nebula", "hairball_core"], "base_exp": 10, "use": "Epic house room", "v1_active": false},
	"whale_bit":      {"name": "Whale Bit", "planets": ["hairball_core"], "base_exp": 14, "use": "Legendary crafts", "v1_active": false},
	"space_koi":      {"name": "Space Koi", "planets": ["any"], "base_exp": 12, "use": "Any epic upgrade substitute (1:1 premium)", "v1_active": false},
	"void_anchovy":   {"name": "Void Anchovy", "planets": ["boss_only"], "base_exp": 20, "use": "Planet unlock tokens", "v1_active": false},
}

func active_species_for_planet(planet_id: String) -> Array:
	var out := []
	for id in species.keys():
		var s = species[id]
		if s.v1_active and (s.planets.has(planet_id) or s.planets.has("any")):
			out.append(id)
	return out

func display_name(species_id: String) -> String:
	return species.get(species_id, {}).get("name", species_id)

func base_exp(species_id: String) -> int:
	return species.get(species_id, {}).get("base_exp", 1)

func rarity_mult(rarity: int) -> float:
	match rarity:
		Rarity.COMMON: return 1.0
		Rarity.UNCOMMON: return 2.0
		Rarity.RARE: return 5.0
		Rarity.EPIC: return 12.0
		Rarity.LEGENDARY: return 30.0
	return 1.0

func rarity_name(rarity: int) -> String:
	return RARITY_NAMES[rarity]

## Roll a rarity from a weighted table (elite enemies use the richer table).
## `lucky` re-rolls once and keeps the rarer of the two (Lucky Gut buff).
func roll_rarity(is_elite: bool = false, lucky: bool = false) -> int:
	var r := _roll_rarity_once(is_elite)
	if lucky:
		var r2 := _roll_rarity_once(is_elite)
		r = max(r, r2)
	return r

func _roll_rarity_once(is_elite: bool) -> int:
	var table = DROP_WEIGHTS_ELITE if is_elite else DROP_WEIGHTS_NORMAL
	var roll := randf()
	var acc := 0.0
	for r in [Rarity.COMMON, Rarity.UNCOMMON, Rarity.RARE, Rarity.EPIC, Rarity.LEGENDARY]:
		acc += table[r]
		if roll <= acc:
			return r
	return Rarity.COMMON

## Pick a random active species available on a planet.
func roll_species(planet_id: String) -> String:
	var pool = active_species_for_planet(planet_id)
	if pool.is_empty():
		return "sardine_rotten"
	return pool[randi() % pool.size()]

func sprite_for_rarity(rarity: int) -> String:
	return "res://assets/sprites/fish/fish_%s.png" % rarity_name(rarity).to_lower()
