extends Node
## AudioManager — autoload singleton. Thin wrapper around a small pool of
## AudioStreamPlayers so any script can call AudioManager.play_sfx("hit")
## without worrying about node setup. Music beds loop via a dedicated player.

const SFX := {
	"hit": "res://assets/audio/sfx_hit.wav",
	"splat": "res://assets/audio/sfx_splat.wav",
	"pickup_common": "res://assets/audio/sfx_pickup_common.wav",
	"pickup_uncommon": "res://assets/audio/sfx_pickup_uncommon.wav",
	"pickup_rare": "res://assets/audio/sfx_pickup_rare.wav",
	"dash": "res://assets/audio/sfx_dash.wav",
	"wave_clear": "res://assets/audio/sfx_wave_clear.wav",
	"milestone": "res://assets/audio/sfx_milestone.wav",
	"player_hurt": "res://assets/audio/sfx_player_hurt.wav",
	"purchase": "res://assets/audio/sfx_purchase.wav",
	"death": "res://assets/audio/sfx_death.wav",
	"skill": "res://assets/audio/sfx_skill.wav",
	"ui_move": "res://assets/audio/sfx_ui_move.wav",
	"ui_confirm": "res://assets/audio/sfx_ui_confirm.wav",
	"telegraph": "res://assets/audio/sfx_telegraph.wav",
}
const MUSIC := {
	"house": "res://assets/audio/music_house_loop.wav",
	"combat": "res://assets/audio/music_combat_loop.wav",
}

var _streams := {}
var _sfx_players: Array = []
const POOL_SIZE := 8
var _pool_index := 0
var _music_player: AudioStreamPlayer

func _ready() -> void:
	for key in SFX.keys():
		_streams[key] = load(SFX[key])
	for key in MUSIC.keys():
		var s = load(MUSIC[key])
		s.loop_mode = AudioStreamWAV.LOOP_FORWARD if s is AudioStreamWAV else 0
		_streams["music_" + key] = s
	for i in POOL_SIZE:
		var p := AudioStreamPlayer.new()
		p.bus = "Master"
		add_child(p)
		_sfx_players.append(p)
	_music_player = AudioStreamPlayer.new()
	_music_player.bus = "Master"
	_music_player.volume_db = -8.0
	add_child(_music_player)

func play_sfx(key: String, pitch: float = 1.0, volume_db: float = -4.0) -> void:
	if not _streams.has(key):
		return
	var p: AudioStreamPlayer = _sfx_players[_pool_index]
	_pool_index = (_pool_index + 1) % POOL_SIZE
	p.stream = _streams[key]
	p.pitch_scale = pitch
	p.volume_db = volume_db
	p.play()

func play_music(key: String) -> void:
	var stream_key = "music_" + key
	if not _streams.has(stream_key):
		return
	if _music_player.stream == _streams[stream_key] and _music_player.playing:
		return
	_music_player.stream = _streams[stream_key]
	_music_player.play()

func stop_music() -> void:
	_music_player.stop()
