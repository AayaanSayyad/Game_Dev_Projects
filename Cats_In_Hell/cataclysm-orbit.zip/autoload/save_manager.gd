extends Node
## SaveManager — autoload singleton. Persists GameState's meta-progression to
## user://save.json (see design doc section 17 for the schema this mirrors).

const SAVE_PATH := "user://save.json"

func _ready() -> void:
	load_game()

func save_game() -> void:
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f == null:
		push_warning("SaveManager: could not open save file for writing.")
		return
	f.store_string(JSON.stringify(GameState.to_save_dict(), "\t"))
	f.close()

func load_game() -> bool:
	if not FileAccess.file_exists(SAVE_PATH):
		return false
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		return false
	var text := f.get_as_text()
	f.close()
	var parsed = JSON.parse_string(text)
	if typeof(parsed) != TYPE_DICTIONARY:
		push_warning("SaveManager: save file was corrupt, ignoring.")
		return false
	GameState.load_from_dict(parsed)
	return true

func delete_save() -> void:
	if FileAccess.file_exists(SAVE_PATH):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(SAVE_PATH))
