extends Node
## WaveDirector — autoload singleton. Pure data/formula layer (design doc
## section 6): given a wave number, tells the Arena how fast to spawn, how
## strong enemies should be, and whether this wave is a scripted milestone.
## Deliberately holds no scene-tree state so it's easy to unit-poke.

const MAX_WAVE := 100

func spawn_interval(wave: int) -> float:
	return lerp(2.5, 0.6, clamp(float(wave) / 100.0, 0.0, 1.0))

func enemy_hp_mult(wave: int) -> float:
	return 1.0 + float(wave) * 0.04

func bullet_speed_mult(wave: int) -> float:
	return 1.0 + float(wave) * 0.003

func enemy_count_cap(wave: int) -> int:
	return min(8 + int(floor(float(wave) / 5.0)), 24)

## Every 10th non-milestone wave is a themed "set piece" burst for variety.
func is_setpiece(wave: int) -> bool:
	return wave % 10 == 0 and not is_milestone(wave)

func is_milestone(wave: int) -> bool:
	return wave in [10, 25, 50, 75, 100]

## Returns milestone metadata for the given wave, or an empty dict if none.
## type: "checkpoint_buff" | "miniboss" | "midboss" | "elite_wave" | "planetboss"
func milestone_info(wave: int) -> Dictionary:
	match wave:
		10:
			return {"type": "checkpoint_buff", "checkpoint": 10, "label": "Wave 10 — Checkpoint"}
		25:
			return {"type": "miniboss", "checkpoint": 25, "label": "Wave 25 — Trash Golem", "boss": "trash_golem"}
		50:
			return {"type": "midboss", "checkpoint": 50, "label": "Wave 50 — Orbital Compactor",
					"note": "Unique mid-boss encounter is Phase 2 content; this build reuses a scaled Trash Golem as a stand-in so the ladder is still climbable."}
		75:
			return {"type": "elite_wave", "checkpoint": 0, "label": "Wave 75 — Elite Modifier",
					"hp_mult": 1.5, "speed_mult": 1.3}
		100:
			return {"type": "planetboss", "checkpoint": 0, "label": "Wave 100 — The Great Flea",
					"note": "Unique 3-phase boss is Phase 3 content; this build spawns a Trash Golem pair as a placeholder finale."}
	return {}

## Builds the roll table (enemy id -> weight) for a normal wave.
func enemy_pool_weights(wave: int) -> Dictionary:
	var pool = EnemyData.pool_for_wave(wave)
	var weights := {}
	for id in pool:
		# earlier-intro enemies stay common; later ones start rarer then ramp up
		var intro = EnemyData.get_enemy(id).intro_wave
		var age = max(0, wave - intro)
		weights[id] = 1.0 + min(age / 10.0, 2.0)
	return weights

func roll_enemy(wave: int) -> String:
	var weights = enemy_pool_weights(wave)
	var total := 0.0
	for w in weights.values():
		total += w
	var roll := randf() * total
	var acc := 0.0
	for id in weights.keys():
		acc += weights[id]
		if roll <= acc:
			return id
	return weights.keys()[0]
