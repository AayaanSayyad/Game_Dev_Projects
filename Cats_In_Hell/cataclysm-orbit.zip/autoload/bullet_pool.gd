extends Node2D
## BulletPool — autoload singleton. Object-pools every bullet in the game so
## a 100-wave bullet-hell run doesn't spam instantiate()/queue_free(). Caps
## simultaneous active bullets (design doc section 5: "max 120 active web,
## 200 desktop" — this build uses one conservative cap for both).

const MAX_ACTIVE := 160
const BULLET_SCENE := preload("res://scenes/entities/bullets/bullet.tscn")

var _pool: Array = []
var _active_count := 0
var _container: Node2D = null

func set_container(node: Node2D) -> void:
	_container = node

## params: position, direction(Vector2, normalized), speed, damage, from_player(bool),
## texture(Texture2D), pierce(int, default 0), lifetime(float), radius(float),
## lob(bool, default false), splash_radius(float, default 0.0)
func spawn(params: Dictionary):
	if _active_count >= MAX_ACTIVE or _container == null:
		return null
	var b
	if _pool.is_empty():
		b = BULLET_SCENE.instantiate()
	else:
		b = _pool.pop_back()
	if b.get_parent() != _container:
		if b.get_parent():
			b.get_parent().remove_child(b)
		_container.add_child(b)
	b.setup(params, self)
	_active_count += 1
	return b

func release(b) -> void:
	if not is_instance_valid(b):
		return
	b.reset_visual()
	if b.get_parent():
		b.get_parent().remove_child(b)
	add_child(b)
	_pool.append(b)
	_active_count = max(0, _active_count - 1)

## Called when the Arena scene is torn down (death / retreat to House) so no
## stray bullets keep simulating against a container that no longer exists.
func clear_all_active() -> void:
	if _container == null:
		return
	for child in _container.get_children():
		if child.is_in_group("bullet"):
			release(child)
	_active_count = 0

func active_count() -> int:
	return _active_count
