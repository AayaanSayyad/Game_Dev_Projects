extends Node
## GameState — autoload singleton. Single source of truth for persistent
## meta-progression (vault, upgrades, roster, planet progress) AND the
## transient state of the run currently in progress. SaveManager reads/writes
## the persistent half of this; the run half resets every time a run starts.

signal fish_deposited
signal upgrade_purchased(id: String)
signal cat_unlocked(id: String)
signal run_started
signal run_ended(died: bool)
signal hearts_changed(current: int, max: int)

const PLANET_ID := "litter_prime"

# ---------------------------------------------------------------- PERSISTENT
var vault_fish := {}                 # species_id -> {"Common": n, "Uncommon": n, ...}
var account_exp := 0
var house_upgrades: Array = []       # owned upgrade ids
var roster_unlocked: Array = ["stray"]
var planet_progress := {
	"litter_prime": {"best_wave": 0, "checkpoint": 0, "cleared": false}
}
var settings := {"screen_shake": true, "aim_mode": "mouse"}
var compost_pool := {}               # species_id -> {"Common": n, ...} recoverable fish
var last_unlocked: Array = []        # cats unlocked since House last read+cleared this

# ------------------------------------------------------------------- RUN
var run_active := false
var run_satchel := {}                # same shape as vault_fish, this run only
var selected_cat_id := "stray"
var amiibo_slot_ids: Array = [null, null]
var current_wave := 1
var start_wave := 1                  # wave the run launched from (checkpoint)
var hearts_current := 6
var hearts_max := 6
var active_buffs: Array = []         # buff ids picked at milestones this run
var second_wind_used := false
var dash_cooldown_bonus := 0.0

const BUFF_POOL := {
	"warm_milk": {"name": "Warm Milk", "desc": "+1 heart, right now."},
	"fish_magnet": {"name": "Fish Magnet", "desc": "+30% fish pickup range."},
	"lucky_gut": {"name": "Lucky Gut", "desc": "Better odds at rare fish."},
	"second_wind": {"name": "Second Wind", "desc": "Revive once at 1 heart."},
	"piercing_claws": {"name": "Piercing Claws", "desc": "+1 pierce on your primary, for the run."},
}

func _ready() -> void:
	for id in FishDatabase.species.keys():
		vault_fish[id] = {}
		compost_pool[id] = {}

# ------------------------------------------------------------- VAULT / FISH
func add_run_fish(species_id: String, rarity: int, amount: int = 1) -> void:
	var rname = FishDatabase.rarity_name(rarity)
	if not run_satchel.has(species_id):
		run_satchel[species_id] = {}
	run_satchel[species_id][rname] = run_satchel[species_id].get(rname, 0) + amount

func run_satchel_total() -> int:
	var total := 0
	for sp in run_satchel.values():
		for n in sp.values():
			total += n
	return total

func deposit_run_satchel_to_vault() -> void:
	for species_id in run_satchel.keys():
		for rname in run_satchel[species_id].keys():
			var n = run_satchel[species_id][rname]
			if n <= 0:
				continue
			if not vault_fish.has(species_id):
				vault_fish[species_id] = {}
			vault_fish[species_id][rname] = vault_fish[species_id].get(rname, 0) + n
	run_satchel.clear()
	fish_deposited.emit()
	SaveManager.save_game()

## Applies the death fish penalty to the current run_satchel: destroys half
## of the lost portion outright, the other half goes to the recoverable
## compost pool. Returns a summary dict for the death-summary UI.
func apply_death_fish_penalty() -> Dictionary:
	var loss_pct := 0.40
	if house_upgrades.has("fish_safe"):
		loss_pct = 0.20
	var kept := {}
	var destroyed := {}
	var composted := {}
	for species_id in run_satchel.keys():
		kept[species_id] = {}
		for rname in run_satchel[species_id].keys():
			var n: int = run_satchel[species_id][rname]
			var lost := int(floor(n * loss_pct))
			var keep := n - lost
			var destroyed_n := int(ceil(lost / 2.0))
			var composted_n := lost - destroyed_n
			kept[species_id][rname] = keep
			if destroyed_n > 0:
				destroyed[species_id] = destroyed.get(species_id, {})
				destroyed[species_id][rname] = destroyed_n
			if composted_n > 0:
				composted[species_id] = composted.get(species_id, {})
				composted[species_id][rname] = composted_n
				compost_pool[species_id] = compost_pool.get(species_id, {})
				compost_pool[species_id][rname] = compost_pool[species_id].get(rname, 0) + composted_n
	run_satchel = kept
	return {"loss_pct": loss_pct, "destroyed": destroyed, "composted": composted, "kept_total": run_satchel_total()}

func compost_pool_total() -> int:
	var total := 0
	for sp in compost_pool.values():
		for n in sp.values():
			total += n
	return total

func claim_compost_pool() -> void:
	for species_id in compost_pool.keys():
		for rname in compost_pool[species_id].keys():
			var n = compost_pool[species_id][rname]
			if n <= 0:
				continue
			vault_fish[species_id] = vault_fish.get(species_id, {})
			vault_fish[species_id][rname] = vault_fish[species_id].get(rname, 0) + n
			compost_pool[species_id][rname] = 0
	fish_deposited.emit()
	SaveManager.save_game()

func vault_count(species_id: String, rarity_name: String) -> int:
	return vault_fish.get(species_id, {}).get(rarity_name, 0)

func vault_species_total(species_id: String) -> int:
	var total := 0
	for n in vault_fish.get(species_id, {}).values():
		total += n
	return total

## Convert ALL vault fish into account EXP (Fish Vault "Convert EXP" action).
func convert_vault_to_exp() -> int:
	var gained := 0
	for species_id in vault_fish.keys():
		for rname in vault_fish[species_id].keys():
			var n = vault_fish[species_id][rname]
			if n <= 0:
				continue
			var rarity_idx = FishDatabase.RARITY_NAMES.find(rname)
			gained += int(round(n * FishDatabase.base_exp(species_id) * FishDatabase.rarity_mult(rarity_idx)))
			vault_fish[species_id][rname] = 0
	account_exp += gained
	SaveManager.save_game()
	return gained

## Smoker upgrade action: 5 Common -> 1 Uncommon of same species.
func smoke_convert(species_id: String) -> bool:
	if vault_count(species_id, "Common") < 5:
		return false
	vault_fish[species_id]["Common"] -= 5
	vault_fish[species_id]["Uncommon"] = vault_fish[species_id].get("Uncommon", 0) + 1
	SaveManager.save_game()
	return true

# --------------------------------------------------------------- UPGRADES
func has_upgrade(id: String) -> bool:
	return house_upgrades.has(id)

func can_afford(id: String) -> bool:
	var data = HouseUpgradesData.get_upgrade(id)
	if data.is_empty() or has_upgrade(id):
		return false
	if data.requires != "" and not has_upgrade(data.requires):
		return false
	for line in data.cost:
		if vault_count(line.species, line.rarity) < line.amount:
			return false
	return true

func purchase_upgrade(id: String) -> bool:
	if not can_afford(id):
		return false
	var data = HouseUpgradesData.get_upgrade(id)
	for line in data.cost:
		vault_fish[line.species][line.rarity] -= line.amount
	house_upgrades.append(id)
	upgrade_purchased.emit(id)
	SaveManager.save_game()
	return true

func checkpoint_wave_for_planet(planet_id: String = PLANET_ID) -> int:
	if not has_upgrade("tent"):
		return 1
	var cp := 1
	if has_upgrade("shack"):
		cp = 10
	if has_upgrade("cat_house"):
		cp = 50
	return max(cp, planet_progress.get(planet_id, {}).get("checkpoint", 1))

func amiibo_slot_cap() -> int:
	return 2 if has_upgrade("window_perch") else 1

# ------------------------------------------------------------------ ROSTER
func check_roster_unlocks(best_wave: int) -> Array:
	var newly := []
	for id in CatData.table().keys():
		var uw = CatData.get_cat(id).unlock_wave
		if best_wave >= uw and not roster_unlocked.has(id):
			roster_unlocked.append(id)
			newly.append(id)
			cat_unlocked.emit(id)
	if not newly.is_empty():
		last_unlocked.append_array(newly)
		SaveManager.save_game()
	return newly

# --------------------------------------------------------------------- RUN
func start_run(cat_id: String, amiibo_ids: Array) -> void:
	selected_cat_id = cat_id
	amiibo_slot_ids = amiibo_ids.duplicate()
	run_satchel.clear()
	active_buffs.clear()
	second_wind_used = false
	dash_cooldown_bonus = 0.0
	var cat = CatData.get_cat(cat_id)
	hearts_max = cat.max_hp
	for slot_id in amiibo_slot_ids:
		if slot_id != null and CatData.get_cat(slot_id).amiibo_passive.key == "bonus_half_hearts":
			hearts_max += CatData.get_cat(slot_id).amiibo_passive.value
	hearts_current = hearts_max
	start_wave = checkpoint_wave_for_planet()
	current_wave = start_wave
	run_active = true
	run_started.emit()

func end_run(died: bool) -> void:
	run_active = false
	var pp = planet_progress[PLANET_ID]
	if current_wave > pp.best_wave:
		pp.best_wave = current_wave
	if not died:
		# reached a milestone this run without dying yet (extract or milestone autosave)
		pass
	check_roster_unlocks(pp.best_wave)
	run_ended.emit(died)
	SaveManager.save_game()

func reach_checkpoint(wave: int) -> void:
	var pp = planet_progress[PLANET_ID]
	if wave > pp.checkpoint:
		pp.checkpoint = wave
	if wave > pp.best_wave:
		pp.best_wave = wave
	check_roster_unlocks(pp.best_wave)
	SaveManager.save_game()

func amiibo_passive_value(key: String) -> float:
	var total := 0.0
	for id in amiibo_slot_ids:
		if id == null:
			continue
		var p = CatData.get_cat(id).amiibo_passive
		if p.key == key:
			total += p.value
	return total

# ---------------------------------------------------------------- BUFFS
func has_buff(id: String) -> bool:
	return active_buffs.has(id)

func offer_buff_choices(count: int = 3) -> Array:
	var pool = BUFF_POOL.keys().filter(func(id): return not active_buffs.has(id))
	pool.shuffle()
	return pool.slice(0, min(count, pool.size()))

func apply_buff(id: String) -> void:
	if active_buffs.has(id):
		return
	active_buffs.append(id)
	match id:
		"warm_milk":
			hearts_max += 2
			hearts_current = min(hearts_max, hearts_current + 2)
			hearts_changed.emit(hearts_current, hearts_max)

func buff_pickup_range_bonus() -> float:
	return 0.30 if has_buff("fish_magnet") else 0.0

func buff_pierce_bonus() -> int:
	return 1 if has_buff("piercing_claws") else 0

func buff_lucky_gut() -> bool:
	return has_buff("lucky_gut")

func take_damage(half_hearts: int) -> void:
	hearts_current = max(0, hearts_current - half_hearts)
	hearts_changed.emit(hearts_current, hearts_max)

func heal(half_hearts: int) -> void:
	hearts_current = min(hearts_max, hearts_current + half_hearts)
	hearts_changed.emit(hearts_current, hearts_max)

func to_save_dict() -> Dictionary:
	return {
		"version": 1,
		"vault_fish": vault_fish,
		"account_exp": account_exp,
		"house_upgrades": house_upgrades,
		"roster_unlocked": roster_unlocked,
		"planet_progress": planet_progress,
		"settings": settings,
		"compost_pool": compost_pool,
	}

func load_from_dict(d: Dictionary) -> void:
	vault_fish = d.get("vault_fish", vault_fish)
	account_exp = d.get("account_exp", 0)
	house_upgrades = d.get("house_upgrades", [])
	roster_unlocked = d.get("roster_unlocked", ["stray"])
	planet_progress = d.get("planet_progress", planet_progress)
	settings = d.get("settings", settings)
	compost_pool = d.get("compost_pool", compost_pool)
