extends RefCounted
class_name WeaponData
## Primary-fire weapon kits. fire_mode drives PlayerCat's firing branch:
##   "projectile_rapid"   - straight shot, fast cooldown
##   "projectile_lob_splash" - arcing lob, small AoE on impact
##   "melee_arc"          - short swing hitbox in front of the cat

static func weapons() -> Dictionary:
	return {
		"scratch_claws": {
			"display_name": "Scratch Claws", "fire_mode": "projectile_rapid",
			"cooldown": 0.14, "damage": 1, "projectile_speed": 170.0,
			"spread_deg": 6.0, "pierce": 0, "range": 150.0,
			"texture": "res://assets/sprites/fx/bullet_player.png",
		},
		"hairball_slingshot": {
			"display_name": "Hairball Slingshot", "fire_mode": "projectile_lob_splash",
			"cooldown": 0.55, "damage": 2, "projectile_speed": 150.0,
			"spread_deg": 3.0, "pierce": 0, "range": 170.0, "splash_radius": 20.0,
			"texture": "res://assets/sprites/fx/bullet_lob.png",
		},
		"rusty_forge_hammer": {
			"display_name": "Rusty Forge Hammer", "fire_mode": "melee_arc",
			"cooldown": 0.85, "damage": 3, "melee_range": 28.0, "melee_angle_deg": 110.0,
			"knockback": 190.0,
		},
		"purr_wave": {
			"display_name": "Purr Wave", "fire_mode": "projectile_rapid",
			"cooldown": 0.32, "damage": 1, "projectile_speed": 130.0,
			"spread_deg": 4.0, "pierce": 1, "range": 140.0,
			"texture": "res://assets/sprites/fx/bullet_player.png",
		},
	}

static func get_weapon(id: String) -> Dictionary:
	return weapons().get(id, weapons()["scratch_claws"])

## Active skills (E / LB). type drives PlayerCat.use_active_skill().
static func skills() -> Dictionary:
	return {
		"fleet_paws": {"display_name": "Fleet Paws", "type": "speed_burst", "cooldown": 9.0, "duration": 2.0, "multiplier": 1.6},
		"hairball_barrage": {"display_name": "Hairball Barrage", "type": "burst_fire", "cooldown": 11.0, "count": 5, "spread_deg": 55.0, "damage": 2},
		"anvil_slam": {"display_name": "Anvil Slam", "type": "aoe_slam", "cooldown": 10.0, "damage": 5, "radius": 42.0, "windup": 0.45, "knockback": 260.0},
		"purr_charm": {"display_name": "Purr Charm", "type": "heal_pulse", "cooldown": 13.0, "heal_half_hearts": 2, "radius": 60.0},
	}

static func get_skill(id: String) -> Dictionary:
	return skills().get(id, skills()["fleet_paws"])
