extends RefCounted
class_name EnemyData
## Enemy pool for Litter Prime (Planet 1). "intro_wave" gates when the
## WaveDirector starts drawing that enemy into the spawn pool, matching the
## design doc's table in section 12. Two are fully implemented for the
## Phase 1 slice (Grub, Spitter); Mite Swarm and the Trash Golem mini-boss
## extend into Phase 2 territory since they were cheap to add and add a lot
## of variety for the wave-25 milestone fight.

static func enemies() -> Dictionary:
	return {
		"grub": {
			"display_name": "Grub", "scene": "res://scenes/entities/enemies/grub.tscn",
			"max_hp": 3, "move_speed": 55.0, "contact_damage": 1, "intro_wave": 1,
			"fish_drops": 1, "score": 10,
		},
		"spitter": {
			"display_name": "Spitter", "scene": "res://scenes/entities/enemies/spitter.tscn",
			"max_hp": 4, "move_speed": 22.0, "contact_damage": 1, "intro_wave": 3,
			"fish_drops": 1, "score": 15,
			"telegraph_time": 0.8, "bullet_speed": 75.0, "bullet_damage": 1, "attack_cooldown": 2.2, "attack_range": 160.0,
		},
		"mite": {
			"display_name": "Mite Swarm", "scene": "res://scenes/entities/enemies/mite.tscn",
			"max_hp": 1, "move_speed": 115.0, "contact_damage": 1, "intro_wave": 12,
			"fish_drops": 1, "score": 5, "pack_size": 4,
		},
	}

static func get_enemy(id: String) -> Dictionary:
	return enemies().get(id, enemies()["grub"])

## Pool of spawnable trash-enemy ids available at a given wave (excludes
## the Trash Golem mini-boss, which is a scripted set-piece).
static func pool_for_wave(wave: int) -> Array:
	var out := []
	for id in enemies().keys():
		if enemies()[id].intro_wave <= wave:
			out.append(id)
	if out.is_empty():
		out.append("grub")
	return out

static func miniboss() -> Dictionary:
	return {
		"display_name": "Trash Golem", "scene": "res://scenes/entities/enemies/trash_golem.tscn",
		"max_hp": 55, "move_speed": 34.0, "contact_damage": 2, "fish_drops": 5, "score": 200,
		"slam_cooldown": 3.2, "slam_telegraph": 0.9, "slam_radius": 46.0, "slam_damage": 2,
		"ring_bullet_count": 10, "ring_bullet_speed": 60.0,
	}
