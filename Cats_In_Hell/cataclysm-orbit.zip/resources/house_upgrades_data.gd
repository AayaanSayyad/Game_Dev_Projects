extends RefCounted
class_name HouseUpgradesData
## Fixed Blueprint Wall tree. Costs use ONLY fish species that actually drop
## on Litter Prime in this build (sardine_rotten, mackerel_foul, tuna_mold) so
## every upgrade is reachable in the v1 slice. `fish_safe`'s recipe is
## intentionally substituted from the doc's "2x lobster Epic" (lobster is a
## Planet 3/4 fish, unreachable here) to "4x tuna_mold Rare" — swap back once
## later planets exist. `requires` gates purchase order within a track.

static func upgrades() -> Dictionary:
	return {
		"tent": {
			"name": "Tent", "track": "Shelter", "requires": "",
			"cost": [{"species": "sardine_rotten", "rarity": "Common", "amount": 5}],
			"effect": "unlock_checkpoints",
			"desc": "A cardboard tent — the bare minimum. Enables checkpoint saves.",
		},
		"shack": {
			"name": "Shack", "track": "Shelter", "requires": "tent",
			"cost": [{"species": "mackerel_foul", "rarity": "Uncommon", "amount": 3},
					 {"species": "sardine_rotten", "rarity": "Common", "amount": 2}],
			"effect": "checkpoint_10",
			"desc": "Checkpoint save at wave 10.",
		},
		"cat_house": {
			"name": "Cat House", "track": "Shelter", "requires": "shack",
			"cost": [{"species": "tuna_mold", "rarity": "Rare", "amount": 2},
					 {"species": "mackerel_foul", "rarity": "Common", "amount": 5}],
			"effect": "checkpoint_50",
			"desc": "Checkpoint save at wave 50.",
		},
		"smoker": {
			"name": "Smoker", "track": "Workshop", "requires": "tent",
			"cost": [{"species": "sardine_rotten", "rarity": "Uncommon", "amount": 6}],
			"effect": "unlock_smoker",
			"desc": "Convert 5 Common fish into 1 Uncommon of the same species, from the Vault.",
		},
		"fish_safe": {
			"name": "Fish Safe", "track": "Workshop", "requires": "tent",
			"cost": [{"species": "tuna_mold", "rarity": "Rare", "amount": 4}],
			"effect": "fish_loss_reduction",
			"desc": "Death fish loss reduced from 40% to 20% of your run satchel.",
		},
		"window_perch": {
			"name": "Window Perch", "track": "Colony", "requires": "tent",
			"cost": [{"species": "sardine_rotten", "rarity": "Common", "amount": 8}],
			"effect": "amiibo_slot_2",
			"desc": "Unlocks your second Amiibo slot.",
		},
	}

static func get_upgrade(id: String) -> Dictionary:
	return upgrades().get(id, {})

static func track_order() -> Array:
	return ["Shelter", "Workshop", "Colony"]
