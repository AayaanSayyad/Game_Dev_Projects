extends RefCounted
class_name CatData
## v1 roster: 4 of the 16 designed cats (Stray, Brick, Soot, Miso — the doc's
## own "implement first" list). HP is stored in half-hearts (2 = 1 heart).
## Speeds/accel are tuned for the 480x270 internal viewport.

static func table() -> Dictionary:
	return {
		"stray": {
			"display_name": "Stray", "role": "Balanced",
			"sprite": "res://assets/sprites/cats/stray.png",
			"amiibo_sprite": "res://assets/sprites/cats/stray_amiibo.png",
			"max_hp": 6, "move_speed": 95.0, "accel": 700.0, "friction": 900.0, "weight": 1.0,
			"dash_speed": 260.0, "dash_time": 0.16, "dash_iframes": 0.18, "dash_cooldown": 1.4,
			"weapon": "scratch_claws", "active_skill": "fleet_paws",
			"starter_gear": "Scratch Claws",
			"amiibo_passive": {"desc": "+5% move speed", "key": "move_speed_pct", "value": 0.05},
			"unlock_wave": 0,
		},
		"brick": {
			"display_name": "Brick", "role": "Ranged",
			"sprite": "res://assets/sprites/cats/brick.png",
			"amiibo_sprite": "res://assets/sprites/cats/brick_amiibo.png",
			"max_hp": 6, "move_speed": 85.0, "accel": 600.0, "friction": 850.0, "weight": 1.1,
			"dash_speed": 250.0, "dash_time": 0.16, "dash_iframes": 0.18, "dash_cooldown": 1.5,
			"weapon": "hairball_slingshot", "active_skill": "hairball_barrage",
			"starter_gear": "Hairball Slingshot",
			"amiibo_passive": {"desc": "+1 pierce on primary", "key": "pierce_add", "value": 1},
			"unlock_wave": 5,
		},
		"soot": {
			"display_name": "Soot", "role": "Bruiser",
			"sprite": "res://assets/sprites/cats/soot.png",
			"amiibo_sprite": "res://assets/sprites/cats/soot_amiibo.png",
			"max_hp": 8, "move_speed": 70.0, "accel": 480.0, "friction": 750.0, "weight": 1.6,
			"dash_speed": 220.0, "dash_time": 0.14, "dash_iframes": 0.16, "dash_cooldown": 1.7,
			"weapon": "rusty_forge_hammer", "active_skill": "anvil_slam",
			"starter_gear": "Rusty Forge Hammer",
			"amiibo_passive": {"desc": "-10% gear loss (Phase 2)", "key": "gear_loss_pct", "value": -0.10},
			"unlock_wave": 15,
		},
		"miso": {
			"display_name": "Miso", "role": "Support",
			"sprite": "res://assets/sprites/cats/miso.png",
			"amiibo_sprite": "res://assets/sprites/cats/miso_amiibo.png",
			"max_hp": 6, "move_speed": 90.0, "accel": 650.0, "friction": 880.0, "weight": 0.9,
			"dash_speed": 250.0, "dash_time": 0.16, "dash_iframes": 0.18, "dash_cooldown": 1.4,
			"weapon": "purr_wave", "active_skill": "purr_charm",
			"starter_gear": "Purr Charm",
			"amiibo_passive": {"desc": "+0.5 heart start", "key": "bonus_half_hearts", "value": 1},
			"unlock_wave": 25,
		},
	}

static func get_cat(id: String) -> Dictionary:
	return table().get(id, table()["stray"])
