extends RefCounted
class_name CLayers
## Bitmask values for project.godot's [layer_names] (layer N -> bit 1<<(N-1)).
## See design doc section 5 combat-layers table.

const PLAYER_BODY := 1        # layer 1
const PLAYER_HURTBOX := 2     # layer 2
const PLAYER_PROJ := 4        # layer 3
const ENEMY := 8              # layer 4
const ENEMY_PROJ := 16        # layer 5
const PICKUP := 32            # layer 6
const WALL := 64              # layer 7
