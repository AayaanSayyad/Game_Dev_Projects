extends Node
## Main — thin bootstrapper. Design doc section 16: "Title -> House (skip
## splash v1)". Kept as its own scene (rather than pointing project.godot
## straight at House) so a real title/splash screen is a one-line change
## later instead of a project-settings change.

func _ready() -> void:
	# Deferred: calling change_scene_to_file() synchronously inside _ready()
	# races with the engine still finishing the initial add-to-tree pass and
	# throws "Parent node is busy adding/removing children".
	call_deferred("_go_to_house")

func _go_to_house() -> void:
	get_tree().change_scene_to_file("res://scenes/house/house_screen.tscn")
