extends CanvasLayer
## Arena HUD (design doc section 16, item 4): hearts, wave #/100, satchel
## fish-by-species summary, dash CD, skill CD. Arena drives it with a small
## explicit API rather than the HUD reaching into GameState for everything,
## so it stays easy to reuse/re-skin later.

const HEART_FULL := preload("res://assets/sprites/ui/heart_full.png")
const HEART_HALF := preload("res://assets/sprites/ui/heart_half.png")
const HEART_EMPTY := preload("res://assets/sprites/ui/heart_empty.png")

var player: Node = null
var _satchel_refresh_t := 0.0

@onready var hearts_box: HBoxContainer = $Root/TopBar/Hearts
@onready var wave_label: Label = $Root/TopBar/WaveLabel
@onready var satchel_box: HBoxContainer = $Root/TopBar/Satchel
@onready var dash_bar: ProgressBar = $Root/BottomBar/DashBar
@onready var skill_bar: ProgressBar = $Root/BottomBar/SkillBar
@onready var breather_label: Label = $Root/BreatherLabel
@onready var banner_label: Label = $Root/BannerLabel

func _ready() -> void:
	GameState.hearts_changed.connect(_on_hearts_changed)
	_on_hearts_changed(GameState.hearts_current, GameState.hearts_max)
	breather_label.visible = false
	banner_label.modulate.a = 0.0

func bind_player(p: Node) -> void:
	player = p

func set_wave(n: int) -> void:
	wave_label.text = "Wave %d / 100" % n

func _process(delta: float) -> void:
	if player and is_instance_valid(player):
		dash_bar.value = (1.0 - player.dash_cooldown_fraction()) * 100.0
		skill_bar.value = (1.0 - player.skill_cooldown_fraction()) * 100.0
	_satchel_refresh_t -= delta
	if _satchel_refresh_t <= 0.0:
		_satchel_refresh_t = 0.35
		_refresh_satchel()

func _on_hearts_changed(current: int, max_hearts: int) -> void:
	for c in hearts_box.get_children():
		c.queue_free()
	var whole := max_hearts / 2
	var remainder := max_hearts % 2
	var cur := current
	for i in whole:
		var tr := TextureRect.new()
		tr.custom_minimum_size = Vector2(14, 14)
		tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		if cur >= 2:
			tr.texture = HEART_FULL
		elif cur == 1:
			tr.texture = HEART_HALF
		else:
			tr.texture = HEART_EMPTY
		cur = max(0, cur - 2)
		hearts_box.add_child(tr)
	if remainder > 0:
		var tr := TextureRect.new()
		tr.custom_minimum_size = Vector2(10, 14)
		tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		tr.texture = HEART_HALF if cur > 0 else HEART_EMPTY
		hearts_box.add_child(tr)

func _refresh_satchel() -> void:
	for c in satchel_box.get_children():
		c.queue_free()
	for species_id in GameState.run_satchel.keys():
		var total := 0
		for n in GameState.run_satchel[species_id].values():
			total += n
		if total <= 0:
			continue
		var lbl := Label.new()
		lbl.text = "%s x%d" % [FishDatabase.display_name(species_id), total]
		lbl.add_theme_font_size_override("font_size", 12)
		satchel_box.add_child(lbl)

func set_breather(active: bool, seconds_left: float = 0.0) -> void:
	breather_label.visible = active
	if active:
		breather_label.text = "Wave clear! Next wave in %.0f..." % ceil(seconds_left)

func show_banner(text: String, color: Color = Color(1, 1, 1, 1), duration: float = 2.2) -> void:
	banner_label.text = text
	banner_label.modulate = Color(color.r, color.g, color.b, 0.0)
	var t := create_tween()
	t.tween_property(banner_label, "modulate:a", 1.0, 0.25)
	t.tween_interval(duration)
	t.tween_property(banner_label, "modulate:a", 0.0, 0.5)
