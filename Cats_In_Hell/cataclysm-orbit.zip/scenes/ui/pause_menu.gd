extends CanvasLayer
## Pause menu (design doc section 16, item 8). Toggled by the "pause_game"
## input action from Arena; also exposes a screen-shake settings toggle
## since GameState.settings already has the field.

signal resume_pressed
signal quit_to_house_pressed

@onready var resume_btn: Button = $Panel/VBox/ResumeButton
@onready var shake_check: CheckButton = $Panel/VBox/ShakeCheck
@onready var quit_btn: Button = $Panel/VBox/QuitButton

func _ready() -> void:
	visible = false
	resume_btn.pressed.connect(func():
		AudioManager.play_sfx("ui_confirm")
		resume_pressed.emit())
	quit_btn.pressed.connect(func():
		AudioManager.play_sfx("ui_confirm")
		quit_to_house_pressed.emit())
	shake_check.toggled.connect(func(pressed): GameState.settings.screen_shake = pressed)

func open() -> void:
	shake_check.button_pressed = GameState.settings.screen_shake
	visible = true

func close() -> void:
	visible = false
