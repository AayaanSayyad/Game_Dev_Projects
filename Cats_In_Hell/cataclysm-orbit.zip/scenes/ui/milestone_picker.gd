extends CanvasLayer
## Milestone reward picker (design doc section 6: "Wave 10: checkpoint save;
## choose 1 of 3 minor buffs"). Buff pool + effects live in GameState.

signal buff_chosen(id: String)

@onready var title: Label = $Panel/VBox/Title
@onready var buttons_box: VBoxContainer = $Panel/VBox/Buttons

func _ready() -> void:
	visible = false

func present(label_text: String, choices: Array) -> void:
	title.text = label_text
	for c in buttons_box.get_children():
		c.queue_free()
	for id in choices:
		var data = GameState.BUFF_POOL[id]
		var btn := Button.new()
		btn.text = "%s — %s" % [data.name, data.desc]
		btn.custom_minimum_size = Vector2(220, 0)
		btn.pressed.connect(func():
			AudioManager.play_sfx("ui_confirm")
			GameState.apply_buff(id)
			visible = false
			buff_chosen.emit(id))
		buttons_box.add_child(btn)
	visible = true
