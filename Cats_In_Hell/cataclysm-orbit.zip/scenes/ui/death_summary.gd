extends CanvasLayer
## Death summary (design doc section 16, item 7): fish lost, gear lost
## (none yet — v1 has no gear-loss system), retry/home buttons.

signal retry_pressed
signal home_pressed

@onready var title: Label = $Panel/VBox/Title
@onready var info: Label = $Panel/VBox/Info
@onready var retry_btn: Button = $Panel/VBox/Buttons/RetryButton
@onready var home_btn: Button = $Panel/VBox/Buttons/HomeButton

func _ready() -> void:
	visible = false
	retry_btn.pressed.connect(func():
		AudioManager.play_sfx("ui_confirm")
		retry_pressed.emit())
	home_btn.pressed.connect(func():
		AudioManager.play_sfx("ui_confirm")
		home_pressed.emit())

func show_summary(wave_reached: int, penalty: Dictionary) -> void:
	visible = true
	title.text = "You died on Wave %d" % wave_reached
	var destroyed_total := _sum(penalty.destroyed)
	var composted_total := _sum(penalty.composted)
	info.text = "Lost %d%% of your run satchel.\n%d fish gone for good, %d recoverable from the Compost Bin.\nKept %d fish for the vault." % [
		int(penalty.loss_pct * 100), destroyed_total, composted_total, penalty.kept_total
	]

func _sum(d: Dictionary) -> int:
	var t := 0
	for sp in d.values():
		for n in sp.values():
			t += n
	return t
