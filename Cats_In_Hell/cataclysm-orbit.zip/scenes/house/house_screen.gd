extends Control
## House screen (design doc section 9): the home-screen hub. Hotspots open
## panels rather than being a walkable diorama (doc explicitly recommends
## this for scope — section 20, recommendation #9). All panel content is
## built at runtime from GameState/CatData/FishDatabase/HouseUpgradesData so
## adding a cat, fish species, or upgrade later is a data change, not a
## scene-editing change.

const ARENA_SCENE := "res://scenes/arena/arena.tscn"

@onready var exp_label: Label = $TopInfo/ExpLabel
@onready var wave_label: Label = $TopInfo/WaveLabel
@onready var vault_label: Label = $TopInfo/VaultLabel
@onready var notice_label: Label = $NoticeLabel

@onready var loadout_panel: Panel = $Panels/LoadoutPanel
@onready var cat_select_box: HBoxContainer = $Panels/LoadoutPanel/VBox/CatSelect
@onready var amiibo_select_box: HBoxContainer = $Panels/LoadoutPanel/VBox/AmiiboSelect
@onready var checkpoint_label: Label = $Panels/LoadoutPanel/VBox/CheckpointLabel
@onready var start_button: Button = $Panels/LoadoutPanel/VBox/Buttons/StartButton

@onready var roster_panel: Panel = $Panels/RosterPanel
@onready var roster_list: VBoxContainer = $Panels/RosterPanel/VBox/Scroll/List

@onready var vault_panel: Panel = $Panels/VaultPanel
@onready var vault_list: VBoxContainer = $Panels/VaultPanel/VBox/Scroll/List
@onready var vault_exp_label: Label = $Panels/VaultPanel/VBox/ExpRow/ExpLabel

@onready var blueprint_panel: Panel = $Panels/BlueprintPanel
@onready var blueprint_list: VBoxContainer = $Panels/BlueprintPanel/VBox/Scroll/List

@onready var compost_panel: Panel = $Panels/CompostPanel
@onready var compost_label: Label = $Panels/CompostPanel/VBox/CompostLabel
@onready var compost_claim_btn: Button = $Panels/CompostPanel/VBox/ClaimButton

var _selected_cat := "stray"
var _selected_amiibo: Array = [null, null]
var _all_panels: Array = []

func _ready() -> void:
	_all_panels = [loadout_panel, roster_panel, vault_panel, blueprint_panel, compost_panel]
	for p in _all_panels:
		p.visible = false
	notice_label.modulate.a = 0.0
	AudioManager.play_music("house")

	$HotspotBar/LaunchButton.pressed.connect(_open_loadout)
	$HotspotBar/RosterButton.pressed.connect(_open_roster)
	$HotspotBar/VaultButton.pressed.connect(_open_vault)
	$HotspotBar/BlueprintButton.pressed.connect(_open_blueprint)
	$HotspotBar/CompostButton.pressed.connect(_open_compost)

	$Panels/LoadoutPanel/VBox/Buttons/CloseButton.pressed.connect(func(): _close_all())
	$Panels/RosterPanel/VBox/CloseButton.pressed.connect(func(): _close_all())
	$Panels/VaultPanel/VBox/CloseButton.pressed.connect(func(): _close_all())
	$Panels/BlueprintPanel/VBox/CloseButton.pressed.connect(func(): _close_all())
	$Panels/CompostPanel/VBox/CloseButton.pressed.connect(func(): _close_all())

	start_button.pressed.connect(_start_run)
	$Panels/VaultPanel/VBox/ExpRow/ConvertButton.pressed.connect(_convert_exp)
	compost_claim_btn.pressed.connect(_claim_compost)

	_refresh_top_info()
	_announce_unlocks()

func _close_all() -> void:
	for p in _all_panels:
		p.visible = false

func _refresh_top_info() -> void:
	exp_label.text = "EXP: %d" % GameState.account_exp
	wave_label.text = "Best Wave: %d / 100" % GameState.planet_progress[GameState.PLANET_ID].best_wave
	var total := 0
	for sp in GameState.vault_fish.values():
		for n in sp.values():
			total += n
	vault_label.text = "Vault Fish: %d" % total

func _announce_unlocks() -> void:
	if GameState.last_unlocked.is_empty():
		return
	var names := []
	for id in GameState.last_unlocked:
		names.append(CatData.get_cat(id).display_name)
	_show_notice("New cat recruited: %s!" % ", ".join(names))
	GameState.last_unlocked.clear()

func _show_notice(text: String) -> void:
	notice_label.text = text
	notice_label.modulate.a = 0.0
	var t := create_tween()
	t.tween_property(notice_label, "modulate:a", 1.0, 0.3)
	t.tween_interval(2.6)
	t.tween_property(notice_label, "modulate:a", 0.0, 0.6)

# ------------------------------------------------------------- LAUNCH PAD
func _open_loadout() -> void:
	_close_all()
	AudioManager.play_sfx("ui_move")
	if not GameState.roster_unlocked.has(_selected_cat):
		_selected_cat = GameState.roster_unlocked[0]
	_selected_amiibo = GameState.amiibo_slot_ids.duplicate()
	for i in _selected_amiibo.size():
		if _selected_amiibo[i] != null and (_selected_amiibo[i] == _selected_cat or not GameState.roster_unlocked.has(_selected_amiibo[i])):
			_selected_amiibo[i] = null
	_rebuild_cat_select()
	_rebuild_amiibo_select()
	_update_checkpoint_label()
	loadout_panel.visible = true

func _rebuild_cat_select() -> void:
	for c in cat_select_box.get_children():
		c.queue_free()
	for id in CatData.table().keys():
		var data: Dictionary = CatData.get_cat(id)
		var unlocked: bool = GameState.roster_unlocked.has(id)
		var btn := Button.new()
		btn.custom_minimum_size = Vector2(64, 64)
		btn.toggle_mode = true
		btn.button_pressed = (id == _selected_cat)
		btn.disabled = not unlocked
		btn.text = data.display_name if unlocked else "%s\n(wave %d)" % [data.display_name, data.unlock_wave]
		btn.icon = load(data.sprite) if unlocked else null
		btn.pressed.connect(func():
			if not unlocked:
				return
			_selected_cat = id
			if _selected_amiibo.has(id):
				_selected_amiibo[_selected_amiibo.find(id)] = null
			AudioManager.play_sfx("ui_move")
			_rebuild_cat_select()
			_rebuild_amiibo_select()
			_update_checkpoint_label())
		cat_select_box.add_child(btn)

func _rebuild_amiibo_select() -> void:
	for c in amiibo_select_box.get_children():
		c.queue_free()
	var cap: int = GameState.amiibo_slot_cap()
	for id in CatData.table().keys():
		var unlocked: bool = GameState.roster_unlocked.has(id)
		if id == _selected_cat:
			continue
		var data: Dictionary = CatData.get_cat(id)
		var btn := Button.new()
		btn.custom_minimum_size = Vector2(64, 64)
		btn.toggle_mode = true
		btn.button_pressed = _selected_amiibo.has(id)
		btn.disabled = not unlocked
		if unlocked:
			btn.text = "%s\nAmiibo: %s" % [data.display_name, data.amiibo_passive.desc]
			btn.tooltip_text = "" if cap > 1 else "Slot 2 needs Window Perch"
		else:
			btn.text = "%s\n(wave %d)" % [data.display_name, data.unlock_wave]
		btn.icon = load(data.amiibo_sprite) if unlocked else null
		btn.pressed.connect(func():
			if not unlocked:
				return
			if _selected_amiibo.has(id):
				_selected_amiibo[_selected_amiibo.find(id)] = null
			else:
				var empty_slot := _selected_amiibo.find(null)
				if empty_slot == -1 or empty_slot >= cap:
					_show_notice("No free Amiibo slot (cap %d)." % cap)
					return
				_selected_amiibo[empty_slot] = id
			AudioManager.play_sfx("ui_move")
			_rebuild_amiibo_select())
		amiibo_select_box.add_child(btn)

func _update_checkpoint_label() -> void:
	var cp := GameState.checkpoint_wave_for_planet()
	checkpoint_label.text = "Launching into Litter Prime at wave %d (checkpoint)." % cp
	if not GameState.has_upgrade("tent"):
		checkpoint_label.text += "\nBuild a Tent at the Blueprint Wall to enable checkpoints."

func _start_run() -> void:
	AudioManager.play_sfx("ui_confirm")
	GameState.start_run(_selected_cat, _selected_amiibo)
	get_tree().change_scene_to_file(ARENA_SCENE)

# ----------------------------------------------------------------- ROSTER
func _open_roster() -> void:
	_close_all()
	AudioManager.play_sfx("ui_move")
	for c in roster_list.get_children():
		c.queue_free()
	for id in CatData.table().keys():
		var data: Dictionary = CatData.get_cat(id)
		var unlocked: bool = GameState.roster_unlocked.has(id)
		var row := HBoxContainer.new()
		var icon := TextureRect.new()
		icon.custom_minimum_size = Vector2(28, 28)
		icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		icon.texture = load(data.sprite) if unlocked else null
		row.add_child(icon)
		var lbl := Label.new()
		lbl.autowrap_mode = TextServer.AUTOWRAP_WORD
		lbl.custom_minimum_size = Vector2(300, 0)
		if unlocked:
			lbl.text = "%s (%s) — %s | HP %d | Amiibo: %s" % [
				data.display_name, data.role, data.starter_gear, data.max_hp / 2, data.amiibo_passive.desc
			]
		else:
			lbl.text = "%s — locked, unlocks at best wave %d" % [data.display_name, data.unlock_wave]
			lbl.modulate.a = 0.55
		row.add_child(lbl)
		roster_list.add_child(row)
	roster_panel.visible = true

# ------------------------------------------------------------------ VAULT
func _open_vault() -> void:
	_close_all()
	AudioManager.play_sfx("ui_move")
	for c in vault_list.get_children():
		c.queue_free()
	for species_id in FishDatabase.active_species_for_planet(GameState.PLANET_ID):
		var row := HBoxContainer.new()
		var lbl := Label.new()
		lbl.custom_minimum_size = Vector2(90, 0)
		lbl.text = FishDatabase.display_name(species_id)
		row.add_child(lbl)
		for rname in ["Common", "Uncommon", "Rare"]:
			var n: int = GameState.vault_count(species_id, rname)
			var c_lbl := Label.new()
			c_lbl.custom_minimum_size = Vector2(70, 0)
			c_lbl.text = "%s: %d" % [rname, n]
			row.add_child(c_lbl)
		if GameState.has_upgrade("smoker"):
			var smoke_btn := Button.new()
			smoke_btn.text = "Smoke 5→1"
			smoke_btn.disabled = GameState.vault_count(species_id, "Common") < 5
			smoke_btn.pressed.connect(func():
				if GameState.smoke_convert(species_id):
					AudioManager.play_sfx("purchase")
					_open_vault())
			row.add_child(smoke_btn)
		vault_list.add_child(row)
	vault_exp_label.text = "Account EXP: %d" % GameState.account_exp
	vault_panel.visible = true

func _convert_exp() -> void:
	var gained := GameState.convert_vault_to_exp()
	if gained > 0:
		AudioManager.play_sfx("purchase")
		_show_notice("Converted vault fish into %d EXP." % gained)
	_refresh_top_info()
	_open_vault()

# -------------------------------------------------------------- BLUEPRINT
func _open_blueprint() -> void:
	_close_all()
	AudioManager.play_sfx("ui_move")
	for c in blueprint_list.get_children():
		c.queue_free()
	for track in HouseUpgradesData.track_order():
		var track_lbl := Label.new()
		track_lbl.text = "— %s —" % track
		track_lbl.add_theme_font_size_override("font_size", 14)
		blueprint_list.add_child(track_lbl)
		for id in HouseUpgradesData.upgrades().keys():
			var data: Dictionary = HouseUpgradesData.get_upgrade(id)
			if data.track != track:
				continue
			blueprint_list.add_child(_build_upgrade_row(id, data))
	blueprint_panel.visible = true

func _build_upgrade_row(id: String, data: Dictionary) -> Control:
	var row := VBoxContainer.new()
	var top := HBoxContainer.new()
	var name_lbl := Label.new()
	name_lbl.custom_minimum_size = Vector2(120, 0)
	name_lbl.text = data.name
	top.add_child(name_lbl)
	var cost_parts := []
	for line in data.cost:
		cost_parts.append("%dx %s %s" % [line.amount, line.rarity, FishDatabase.display_name(line.species)])
	var cost_lbl := Label.new()
	cost_lbl.custom_minimum_size = Vector2(180, 0)
	cost_lbl.text = ", ".join(cost_parts)
	top.add_child(cost_lbl)
	var btn := Button.new()
	if GameState.has_upgrade(id):
		btn.text = "Owned"
		btn.disabled = true
	elif data.requires != "" and not GameState.has_upgrade(data.requires):
		btn.text = "Needs %s" % HouseUpgradesData.get_upgrade(data.requires).name
		btn.disabled = true
	else:
		btn.text = "Buy"
		btn.disabled = not GameState.can_afford(id)
		btn.pressed.connect(func():
			if GameState.purchase_upgrade(id):
				AudioManager.play_sfx("purchase")
				_show_notice("Built: %s" % data.name)
				_refresh_top_info()
				_open_blueprint())
	top.add_child(btn)
	row.add_child(top)
	var desc_lbl := Label.new()
	desc_lbl.text = data.desc
	desc_lbl.modulate.a = 0.75
	desc_lbl.add_theme_font_size_override("font_size", 11)
	row.add_child(desc_lbl)
	return row

# -------------------------------------------------------------- COMPOST
func _open_compost() -> void:
	_close_all()
	AudioManager.play_sfx("ui_move")
	var total := GameState.compost_pool_total()
	compost_label.text = "Recoverable fish in the Compost Bin: %d" % total
	compost_claim_btn.disabled = total <= 0
	compost_panel.visible = true

func _claim_compost() -> void:
	GameState.claim_compost_pool()
	AudioManager.play_sfx("purchase")
	_refresh_top_info()
	_open_compost()
