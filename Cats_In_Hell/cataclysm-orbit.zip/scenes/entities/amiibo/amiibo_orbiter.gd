extends Node2D
## Purely visual orbiter for a slotted Amiibo cat (design doc section 10:
## "shrunk figurine orbits player; grants passive + small stat boost. Cannot
## attack."). The actual passive math lives in GameState.amiibo_passive_value()
## — this node just sells the fantasy cheaply with an 8x8-ish sprite on an
## orbit path, as doc recommendation #5 suggests.

var orbit_radius := 26.0
var orbit_speed := 1.4
var angle_offset := 0.0
var target: Node2D = null
var paused := false
var _t := 0.0

@onready var sprite: Sprite2D = $Sprite2D

func setup(cat_id: String, offset: float, target_ref: Node2D) -> void:
	sprite.texture = load(CatData.get_cat(cat_id).amiibo_sprite)
	angle_offset = offset
	target = target_ref
	z_index = 10

func set_paused(p: bool) -> void:
	paused = p
	visible = not p

func _process(delta: float) -> void:
	if paused or target == null or not is_instance_valid(target):
		return
	_t += delta * orbit_speed
	var ang := _t + angle_offset
	global_position = target.global_position + Vector2(cos(ang), sin(ang) * 0.5) * orbit_radius + Vector2(0, -16)
