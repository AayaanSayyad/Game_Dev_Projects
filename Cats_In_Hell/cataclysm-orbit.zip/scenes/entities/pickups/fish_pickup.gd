extends Area2D
## Rotten-fish pickup. Uses a manual distance check each frame (instead of
## physics signals) so the magnet-pull behaviour (design doc recommendation
## #5 / section 6 "between waves: pick up remaining fish, magnet pulse") is
## simple to tune: it eases in strength as the player gets closer.

var species_id := "sardine_rotten"
var rarity: int = 0
var player: Node2D = null
var magnet_radius := 55.0
var pickup_radius := 11.0
var _collected := false

@onready var sprite: Sprite2D = $Sprite2D

func _ready() -> void:
	add_to_group("fish_pickup")
	collision_layer = 0
	collision_mask = 0
	monitoring = false
	monitorable = false

func setup(pos: Vector2, sp_id: String, rar: int, player_ref: Node2D) -> void:
	global_position = pos
	species_id = sp_id
	rarity = rar
	player = player_ref
	sprite.texture = load(FishDatabase.sprite_for_rarity(rarity))
	scale = Vector2(0.3, 0.3)
	var hop_target_y := position.y - 7.0
	var start_y := position.y
	var t := create_tween()
	t.set_parallel(true)
	t.tween_property(self, "scale", Vector2(1, 1), 0.22).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	t.tween_property(self, "position:y", hop_target_y, 0.16).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	t.chain().tween_property(self, "position:y", start_y, 0.18).set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)

func force_magnet() -> void:
	magnet_radius = 4000.0

func _physics_process(delta: float) -> void:
	if _collected or player == null or not is_instance_valid(player):
		return
	var dist := global_position.distance_to(player.global_position)
	var magnet_r: float = magnet_radius * (1.0 + GameState.amiibo_passive_value("pickup_radius_pct") + GameState.buff_pickup_range_bonus())
	if dist <= magnet_r:
		var speed: float = lerp(70.0, 280.0, 1.0 - clamp(dist / max(magnet_r, 1.0), 0.0, 1.0))
		global_position = global_position.move_toward(player.global_position, speed * delta)
		dist = global_position.distance_to(player.global_position)
	if dist <= pickup_radius:
		_collect()

func _collect() -> void:
	if _collected:
		return
	_collected = true
	GameState.add_run_fish(species_id, rarity, 1)
	var sfx := "pickup_common"
	if rarity == FishDatabase.Rarity.UNCOMMON:
		sfx = "pickup_uncommon"
	elif rarity >= FishDatabase.Rarity.RARE:
		sfx = "pickup_rare"
	AudioManager.play_sfx(sfx, randf_range(0.95, 1.15), -7.0)
	queue_free()
