extends Area2D
## Pooled bullet. Handles three of the design doc's bullet behaviours:
## straight/rapid, piercing, and lobbed-with-splash (Brick's Hairball
## Slingshot). Never queue_free()s itself in normal play — always released
## back to BulletPool so pooling actually pays off during 100-wave runs.

const TEX_PLAYER := preload("res://assets/sprites/fx/bullet_player.png")
const TEX_ENEMY := preload("res://assets/sprites/fx/bullet_enemy.png")
const TEX_LOB := preload("res://assets/sprites/fx/bullet_lob.png")

var direction := Vector2.RIGHT
var speed := 150.0
var damage := 1
var from_player := true
var pierce_remaining := 0
var max_range := 200.0
var travel_distance := 0.0
var is_lob := false
var splash_radius := 0.0
var max_lifetime := 3.0
var lifetime := 0.0
var pool_ref: Node = null

func _ready() -> void:
	add_to_group("bullet")
	area_entered.connect(_on_area_entered)
	body_entered.connect(_on_body_entered)

func setup(params: Dictionary, pool) -> void:
	pool_ref = pool
	global_position = params.get("position", Vector2.ZERO)
	direction = params.get("direction", Vector2.RIGHT).normalized()
	speed = params.get("speed", 150.0)
	damage = params.get("damage", 1)
	from_player = params.get("from_player", true)
	pierce_remaining = params.get("pierce", 0)
	max_range = params.get("range", 200.0)
	is_lob = params.get("lob", false)
	splash_radius = params.get("splash_radius", 0.0)
	max_lifetime = params.get("lifetime", 3.0)
	lifetime = 0.0
	travel_distance = 0.0
	rotation = direction.angle()
	scale = Vector2.ONE
	modulate = Color(1, 1, 1, 1)
	visible = true

	match params.get("kind", "player"):
		"player":
			$Sprite2D.texture = TEX_PLAYER
		"enemy":
			$Sprite2D.texture = TEX_ENEMY
		"lob":
			$Sprite2D.texture = TEX_LOB

	if from_player:
		collision_layer = CLayers.PLAYER_PROJ
		collision_mask = CLayers.ENEMY
	else:
		collision_layer = CLayers.ENEMY_PROJ
		collision_mask = CLayers.PLAYER_HURTBOX

	monitoring = not is_lob
	set_physics_process(true)

func _physics_process(delta: float) -> void:
	lifetime += delta
	var move := direction * speed * delta
	global_position += move
	travel_distance += move.length()

	if is_lob:
		var t: float = clamp(travel_distance / max_range, 0.0, 1.0)
		scale = Vector2.ONE * (1.0 + sin(t * PI) * 0.7)
		if t >= 1.0:
			_detonate()
			return
	elif travel_distance >= max_range:
		_despawn()
		return

	if lifetime >= max_lifetime:
		_despawn()

func _on_area_entered(area: Area2D) -> void:
	_handle_hit(area)

func _on_body_entered(body: Node) -> void:
	_handle_hit(body)

func _handle_hit(target: Node) -> void:
	if not is_instance_valid(target) or is_lob:
		return
	if target.has_method("take_hit"):
		target.take_hit(damage, direction)
		AudioManager.play_sfx("hit", randf_range(0.9, 1.1), -10.0)
	if pierce_remaining > 0:
		pierce_remaining -= 1
	else:
		_despawn()

func _detonate() -> void:
	if splash_radius > 0.0:
		var space_state := get_world_2d().direct_space_state
		var shape := CircleShape2D.new()
		shape.radius = splash_radius
		var query := PhysicsShapeQueryParameters2D.new()
		query.shape = shape
		query.transform = Transform2D(0.0, global_position)
		query.collision_mask = CLayers.ENEMY if from_player else CLayers.PLAYER_HURTBOX
		query.collide_with_bodies = true
		query.collide_with_areas = true
		var results := space_state.intersect_shape(query, 8)
		for r in results:
			var col = r.collider
			if is_instance_valid(col) and col.has_method("take_hit"):
				col.take_hit(damage, Vector2.ZERO)
	AudioManager.play_sfx("hit", 0.75, -8.0)
	_despawn()

func _despawn() -> void:
	set_physics_process(false)
	if pool_ref:
		pool_ref.release(self)
	else:
		queue_free()

func reset_visual() -> void:
	visible = false
	scale = Vector2.ONE
	monitoring = false
	set_physics_process(false)
