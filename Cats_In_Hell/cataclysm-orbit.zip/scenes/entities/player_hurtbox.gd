extends Area2D
## Child Area2D of PlayerCat on the player_hurtbox layer. Forwards both
## "hit by an enemy bullet" (area_entered check inside Bullet.gd calls
## take_hit() on whatever it detected) and "touched an enemy body" (contact
## damage) up to the owning PlayerCat, which does the actual HP/i-frame work.

signal hit_by_bullet(damage: int, dir: Vector2)
signal hit_by_body(body: Node)

func _ready() -> void:
	body_entered.connect(func(b): hit_by_body.emit(b))

## Called by Bullet.gd via duck-typing (`target.has_method("take_hit")`).
func take_hit(damage: int, dir: Vector2) -> void:
	hit_by_bullet.emit(damage, dir)
