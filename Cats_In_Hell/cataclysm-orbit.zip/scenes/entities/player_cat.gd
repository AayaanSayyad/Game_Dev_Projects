extends CharacterBody2D
## PlayerCat — the twin-stick controlled cat (design doc section 4-5).
## Momentum-based movement (accel/friction per cat "weight"), mouse aim
## (v1 default per doc section 22), dash with tight i-frames, and a primary
## fire + active skill pulled from WeaponData / CatData for whichever cat is
## selected. One instance exists per run; Arena calls setup(cat_id) once.

signal died
signal hurt(amount: int)
signal fired
signal dashed
signal skill_used(skill_id: String)

var cat_id := "stray"
var cat: Dictionary
var weapon: Dictionary
var skill: Dictionary

var move_speed := 90.0
var accel := 650.0
var friction := 850.0
var weight := 1.0

var dash_speed := 250.0
var dash_time := 0.16
var dash_iframes := 0.18
var dash_cooldown := 1.4

var fire_cooldown := 0.14
var skill_cooldown_max := 10.0

var _input_dir := Vector2.ZERO
var _aim_dir := Vector2.DOWN
var _is_dashing := false
var _dash_timer := 0.0
var _dash_cd_timer := 0.0
var _fire_timer := 0.0
var _skill_cd_timer := 0.0
var _skill_active_mult := 1.0
var _skill_speed_timer := 0.0
var _invuln_timer := 0.0
var _hurt_cd := 0.0
var _alive := true
var _frozen := false

const HURT_IFRAMES := 0.55
const HURT_KNOCKBACK := 90.0

@onready var sprite: Sprite2D = $Sprite2D
@onready var hurtbox: Area2D = $Hurtbox

func _ready() -> void:
	collision_layer = CLayers.PLAYER_BODY
	collision_mask = CLayers.WALL
	hurtbox.hit_by_bullet.connect(_on_hit_by_bullet)
	hurtbox.hit_by_body.connect(_on_hit_by_body)

func setup(id: String) -> void:
	cat_id = id
	cat = CatData.get_cat(id)
	weapon = WeaponData.get_weapon(cat.weapon)
	skill = WeaponData.get_skill(cat.active_skill)
	sprite.texture = load(cat.sprite)
	move_speed = cat.move_speed
	accel = cat.accel
	friction = cat.friction
	weight = cat.weight
	dash_speed = cat.dash_speed
	dash_time = cat.dash_time
	dash_iframes = cat.dash_iframes
	dash_cooldown = cat.dash_cooldown
	skill_cooldown_max = skill.cooldown
	# amiibo passive: move speed bonus applies for whichever cat is playing
	move_speed *= (1.0 + GameState.amiibo_passive_value("move_speed_pct"))

func set_frozen(f: bool) -> void:
	_frozen = f
	if f:
		velocity = Vector2.ZERO

func _physics_process(delta: float) -> void:
	if not _alive:
		return
	_tick_timers(delta)
	if _frozen:
		velocity = Vector2.ZERO
		move_and_slide()
		return

	_input_dir = Input.get_vector("move_left", "move_right", "move_up", "move_down")
	_aim_dir = (get_global_mouse_position() - global_position)
	if _aim_dir.length() < 0.001:
		_aim_dir = Vector2.DOWN
	else:
		_aim_dir = _aim_dir.normalized()

	if Input.is_action_just_pressed("dash") and _dash_cd_timer <= 0.0 and not _is_dashing:
		_start_dash()

	if _is_dashing:
		_dash_timer -= delta
		if _dash_timer <= 0.0:
			_is_dashing = false
	else:
		var target_speed := move_speed * _skill_active_mult
		if _input_dir.length() > 0.01:
			velocity = velocity.move_toward(_input_dir.normalized() * target_speed, accel * delta)
		else:
			velocity = velocity.move_toward(Vector2.ZERO, friction * delta)

	move_and_slide()
	_clamp_to_arena()

	if abs(_aim_dir.x) > 0.05:
		sprite.flip_h = _aim_dir.x < 0.0

	_handle_fire(delta)
	if Input.is_action_just_pressed("active_skill") and _skill_cd_timer <= 0.0:
		_use_active_skill()

func _tick_timers(delta: float) -> void:
	if _dash_cd_timer > 0.0:
		_dash_cd_timer -= delta
	if _fire_timer > 0.0:
		_fire_timer -= delta
	if _skill_cd_timer > 0.0:
		_skill_cd_timer -= delta
	if _invuln_timer > 0.0:
		_invuln_timer -= delta
	if _hurt_cd > 0.0:
		_hurt_cd -= delta
	if _skill_speed_timer > 0.0:
		_skill_speed_timer -= delta
		if _skill_speed_timer <= 0.0:
			_skill_active_mult = 1.0

func is_invulnerable() -> bool:
	return _invuln_timer > 0.0

# ------------------------------------------------------------------- DASH
func _start_dash() -> void:
	var dir := _input_dir.normalized() if _input_dir.length() > 0.01 else _aim_dir
	_is_dashing = true
	_dash_timer = dash_time
	_dash_cd_timer = dash_cooldown
	_invuln_timer = max(_invuln_timer, dash_iframes)
	velocity = dir * dash_speed
	AudioManager.play_sfx("dash", 1.0, -6.0)
	dashed.emit()
	var t := create_tween()
	t.tween_property(sprite, "scale", Vector2(1.25, 0.8), 0.06)
	t.tween_property(sprite, "scale", Vector2(1, 1), 0.12)

func dash_cooldown_fraction() -> float:
	return clamp(_dash_cd_timer / dash_cooldown, 0.0, 1.0)

# ------------------------------------------------------------------- FIRE
func _handle_fire(delta: float) -> void:
	if not Input.is_action_pressed("fire"):
		return
	if _fire_timer > 0.0:
		return
	_fire_timer = weapon.cooldown
	match weapon.fire_mode:
		"projectile_rapid":
			_fire_projectile(_aim_dir, weapon)
		"projectile_lob_splash":
			_fire_lob(_aim_dir, weapon)
		"melee_arc":
			_fire_melee(weapon)
	fired.emit()

func _fire_projectile(dir: Vector2, w: Dictionary) -> void:
	var spread: float = deg_to_rad(w.get("spread_deg", 0.0))
	var d: Vector2 = dir.rotated(randf_range(-spread, spread))
	BulletPool.spawn({
		"position": global_position + dir * 10.0, "direction": d,
		"speed": w.projectile_speed, "damage": w.damage, "from_player": true,
		"kind": "player", "pierce": int(w.get("pierce", 0)) + int(GameState.amiibo_passive_value("pierce_add")) + GameState.buff_pierce_bonus(),
		"range": w.get("range", 200.0), "lifetime": 3.0,
	})

func _fire_lob(dir: Vector2, w: Dictionary) -> void:
	var spread: float = deg_to_rad(w.get("spread_deg", 0.0))
	var d: Vector2 = dir.rotated(randf_range(-spread, spread))
	BulletPool.spawn({
		"position": global_position + dir * 10.0, "direction": d,
		"speed": w.projectile_speed, "damage": w.damage, "from_player": true,
		"kind": "lob", "lob": true, "splash_radius": w.get("splash_radius", 16.0),
		"range": w.get("range", 170.0), "lifetime": 3.0,
	})

func _fire_melee(w: Dictionary) -> void:
	var origin: Vector2 = global_position + _aim_dir * (w.melee_range * 0.5)
	var t := create_tween()
	t.tween_property(sprite, "rotation", sprite.rotation + (0.5 if not sprite.flip_h else -0.5), 0.06)
	t.tween_property(sprite, "rotation", 0.0, 0.1)
	var space_state := get_world_2d().direct_space_state
	var shape := CircleShape2D.new()
	shape.radius = w.melee_range * 0.6
	var query := PhysicsShapeQueryParameters2D.new()
	query.shape = shape
	query.transform = Transform2D(0.0, origin)
	query.collision_mask = CLayers.ENEMY
	var results := space_state.intersect_shape(query, 10)
	var hit_any := false
	for r in results:
		var col = r.collider
		if is_instance_valid(col) and col.has_method("take_hit"):
			col.take_hit(w.damage, (col.global_position - global_position).normalized())
			if col.has_method("apply_knockback"):
				col.apply_knockback((col.global_position - global_position).normalized(), w.get("knockback", 150.0))
			hit_any = true
	if hit_any:
		AudioManager.play_sfx("hit", 0.85, -6.0)

# --------------------------------------------------------------- ACTIVE SKILL
func _use_active_skill() -> void:
	_skill_cd_timer = skill_cooldown_max
	match skill.type:
		"speed_burst":
			_skill_active_mult = skill.multiplier
			_skill_speed_timer = skill.duration
		"burst_fire":
			var count: int = skill.count
			var spread: float = deg_to_rad(skill.spread_deg)
			for i in count:
				var frac: float = (float(i) / float(max(count - 1, 1))) - 0.5
				var d: Vector2 = _aim_dir.rotated(frac * spread)
				BulletPool.spawn({
					"position": global_position + _aim_dir * 10.0, "direction": d,
					"speed": weapon.get("projectile_speed", 150.0), "damage": skill.damage,
					"from_player": true, "kind": "lob", "lob": true,
					"splash_radius": weapon.get("splash_radius", 16.0), "range": 170.0, "lifetime": 3.0,
				})
		"aoe_slam":
			_do_slam(skill)
		"heal_pulse":
			GameState.heal(skill.heal_half_hearts)
			AudioManager.play_sfx("skill", 1.0, -3.0)
			_pulse_visual(skill.radius, Color(1.0, 0.6, 0.8, 0.5))
	AudioManager.play_sfx("skill", 1.0, -4.0)
	skill_used.emit(cat.active_skill)

func _do_slam(s: Dictionary) -> void:
	await get_tree().create_timer(s.windup).timeout
	if not _alive:
		return
	AudioManager.play_sfx("hit", 0.6, -2.0)
	_pulse_visual(s.radius, Color(1.0, 0.85, 0.4, 0.55))
	var space_state := get_world_2d().direct_space_state
	var shape := CircleShape2D.new()
	shape.radius = s.radius
	var query := PhysicsShapeQueryParameters2D.new()
	query.shape = shape
	query.transform = Transform2D(0.0, global_position)
	query.collision_mask = CLayers.ENEMY
	var results := space_state.intersect_shape(query, 12)
	for r in results:
		var col = r.collider
		if is_instance_valid(col) and col.has_method("take_hit"):
			col.take_hit(s.damage, (col.global_position - global_position).normalized())
			if col.has_method("apply_knockback"):
				col.apply_knockback((col.global_position - global_position).normalized(), s.knockback)

func _pulse_visual(radius: float, color: Color) -> void:
	var ring := Sprite2D.new()
	ring.texture = load("res://assets/sprites/fx/telegraph_ring.png")
	ring.modulate = color
	ring.scale = Vector2.ONE * 0.1
	ring.z_index = 6
	get_parent().add_child(ring)
	ring.global_position = global_position
	var t := create_tween()
	t.tween_property(ring, "scale", Vector2.ONE * (radius / 32.0), 0.28).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	t.parallel().tween_property(ring, "modulate:a", 0.0, 0.32)
	t.tween_callback(ring.queue_free)

func skill_cooldown_fraction() -> float:
	return clamp(_skill_cd_timer / skill_cooldown_max, 0.0, 1.0)

## Design doc section 4: "bounded edge with gentle pushback force" — arena
## is centred on (0,0) in local coordinates of its container Node2D.
const ARENA_RADIUS := 150.0
func _clamp_to_arena() -> void:
	if position.length() > ARENA_RADIUS:
		position = position.move_toward(Vector2.ZERO, position.length() - ARENA_RADIUS)

# ---------------------------------------------------------------------- HURT
func _on_hit_by_bullet(damage: int, dir: Vector2) -> void:
	_apply_damage(damage, dir)

func _on_hit_by_body(body: Node) -> void:
	if body.is_in_group("enemy") and "contact_damage" in body:
		_apply_damage(body.contact_damage, (global_position - body.global_position).normalized())

func _apply_damage(amount: int, dir: Vector2) -> void:
	if not _alive or is_invulnerable():
		return
	_invuln_timer = HURT_IFRAMES
	_hurt_cd = HURT_IFRAMES
	GameState.take_damage(amount)
	velocity += dir * HURT_KNOCKBACK / weight
	AudioManager.play_sfx("player_hurt", 1.0, -3.0)
	hurt.emit(amount)
	sprite.modulate = Color(1.6, 0.7, 0.7, 1.0)
	var t := create_tween()
	t.tween_property(sprite, "modulate", Color(1, 1, 1, 1), 0.25)
	if GameState.hearts_current <= 0:
		if GameState.has_buff("second_wind") and not GameState.second_wind_used:
			GameState.second_wind_used = true
			GameState.hearts_current = 2
			GameState.hearts_changed.emit(2, GameState.hearts_max)
			AudioManager.play_sfx("milestone")
			return
		_die()

func _die() -> void:
	if not _alive:
		return
	_alive = false
	AudioManager.play_sfx("death")
	set_physics_process(false)
	var t := create_tween()
	t.tween_property(sprite, "modulate:a", 0.0, 0.4)
	t.parallel().tween_property(sprite, "scale", Vector2(1.4, 1.4), 0.4)
	died.emit()
