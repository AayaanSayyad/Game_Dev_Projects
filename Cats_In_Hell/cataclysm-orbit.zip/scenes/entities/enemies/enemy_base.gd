extends CharacterBody2D
class_name EnemyBase
## Shared enemy behaviour (design doc section 12): mandatory hit-flash +
## cartoon-splat death animation, HP/knockback, and a `died` signal the
## Arena listens to for fish drops / score / wave bookkeeping. Concrete
## enemies (Grub, Spitter, Mite, TrashGolem) extend this and implement
## `_enemy_physics_process(delta)` for their own movement/attack behaviour.

signal died(enemy: EnemyBase)

var enemy_id := "grub"
var max_hp := 3
var hp := 3
var move_speed := 55.0
var contact_damage := 1
var fish_drops := 1
var score := 10
var is_elite := false
var splat_color := "green"

var player: Node2D = null
var _dead := false
var _knockback := Vector2.ZERO
var _hit_flash_tween: Tween

@onready var sprite: Sprite2D = $Sprite2D

func _ready() -> void:
	add_to_group("enemy")
	collision_layer = CLayers.ENEMY
	collision_mask = CLayers.WALL

func configure(data: Dictionary, hp_mult: float, speed_mult: float, elite: bool = false) -> void:
	enemy_id = data.get("display_name", enemy_id)
	max_hp = max(1, int(ceil(float(data.get("max_hp", 3)) * hp_mult)))
	hp = max_hp
	move_speed = float(data.get("move_speed", 55.0)) * speed_mult
	contact_damage = int(data.get("contact_damage", 1))
	fish_drops = int(data.get("fish_drops", 1))
	score = int(data.get("score", 10))
	is_elite = elite
	if is_elite:
		modulate = Color(1.25, 1.0, 1.35, 1.0)
		scale = Vector2(1.15, 1.15)

func _physics_process(delta: float) -> void:
	if _dead:
		return
	_knockback = _knockback.lerp(Vector2.ZERO, min(1.0, delta * 8.0))
	var desired := _enemy_physics_process(delta)
	velocity = desired + _knockback
	move_and_slide()
	_clamp_to_arena()
	if velocity.length() > 1.0:
		sprite.flip_h = velocity.x < 0.0

## Override in subclasses. Return the desired (non-knockback) velocity.
func _enemy_physics_process(_delta: float) -> Vector2:
	return Vector2.ZERO

func take_hit(dmg: int, from_dir: Vector2) -> void:
	if _dead:
		return
	hp -= dmg
	_knockback += from_dir.normalized() * 70.0 if from_dir.length() > 0.01 else Vector2.ZERO
	_flash()
	if hp <= 0:
		die()

func apply_knockback(dir: Vector2, force: float) -> void:
	_knockback += dir.normalized() * force

## Same soft boundary as the player (design doc section 4).
const ARENA_RADIUS := 155.0
func _clamp_to_arena() -> void:
	if position.length() > ARENA_RADIUS:
		position = position.move_toward(Vector2.ZERO, position.length() - ARENA_RADIUS)

func _flash() -> void:
	if _hit_flash_tween:
		_hit_flash_tween.kill()
	var base_scale := Vector2.ONE * (1.15 if is_elite else 1.0)
	sprite.modulate = Color(2.6, 2.6, 2.6, 1.0)
	scale = base_scale * Vector2(1.18, 0.85)
	_hit_flash_tween = create_tween()
	_hit_flash_tween.set_parallel(true)
	_hit_flash_tween.tween_property(sprite, "modulate", Color(1, 1, 1, 1), 0.1)
	_hit_flash_tween.tween_property(self, "scale", base_scale, 0.12)

func die() -> void:
	if _dead:
		return
	_dead = true
	collision_layer = 0
	collision_mask = 0
	died.emit(self)
	AudioManager.play_sfx("splat", randf_range(0.9, 1.1))
	var t := create_tween()
	t.set_parallel(true)
	t.tween_property(self, "scale", scale * 1.35, 0.09)
	t.tween_property(self, "modulate:a", 0.0, 0.16).set_delay(0.05)
	t.chain().tween_callback(queue_free)
