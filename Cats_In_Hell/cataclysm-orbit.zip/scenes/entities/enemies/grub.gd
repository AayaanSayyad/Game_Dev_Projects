extends "res://scenes/entities/enemies/enemy_base.gd"
## Grub — chase melee. The doc's first enemy: walks straight at the player.

func _ready() -> void:
	super._ready()
	splat_color = "green"

func _enemy_physics_process(_delta: float) -> Vector2:
	if player == null or not is_instance_valid(player):
		return Vector2.ZERO
	return (player.global_position - global_position).normalized() * move_speed
