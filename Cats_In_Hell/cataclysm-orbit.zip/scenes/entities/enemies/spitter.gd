extends "res://scenes/entities/enemies/enemy_base.gd"
## Spitter — slow aimed spores. Keeps its distance, telegraphs 0.6-1.2s
## (design doc section 5) before firing an aimed bullet at the player.

var attack_cooldown := 2.2
var attack_range := 160.0
var telegraph_time := 0.8
var bullet_speed := 75.0
var bullet_damage := 1

var _cd_timer := 0.0
var _telegraphing := false
var _telegraph_t := 0.0

@onready var telegraph_sprite: Sprite2D = $TelegraphRing

func _ready() -> void:
	super._ready()
	splat_color = "purple"
	telegraph_sprite.visible = false

func configure(data: Dictionary, hp_mult: float, speed_mult: float, elite: bool = false, bullet_speed_mult: float = 1.0) -> void:
	super.configure(data, hp_mult, speed_mult, elite)
	attack_cooldown = float(data.get("attack_cooldown", 2.2))
	attack_range = float(data.get("attack_range", 160.0))
	telegraph_time = float(data.get("telegraph_time", 0.8))
	bullet_speed = float(data.get("bullet_speed", 75.0)) * bullet_speed_mult
	bullet_damage = int(data.get("bullet_damage", 1))
	_cd_timer = randf_range(0.5, attack_cooldown)

func _enemy_physics_process(delta: float) -> Vector2:
	if player == null or not is_instance_valid(player):
		return Vector2.ZERO
	var to_player := player.global_position - global_position
	var dist := to_player.length()
	var desired := Vector2.ZERO

	if _telegraphing:
		_telegraph_t -= delta
		var t: float = 1.0 - clamp(_telegraph_t / telegraph_time, 0.0, 1.0)
		telegraph_sprite.scale = Vector2.ONE * (0.25 + t * 0.55)
		telegraph_sprite.modulate.a = 0.85
		if _telegraph_t <= 0.0:
			_fire()
	else:
		if dist > attack_range:
			desired = to_player.normalized() * move_speed
		elif dist < attack_range * 0.5:
			desired = -to_player.normalized() * move_speed * 0.6
		_cd_timer -= delta
		if _cd_timer <= 0.0 and dist <= attack_range * 1.3:
			_start_telegraph()
	return desired

func _start_telegraph() -> void:
	_telegraphing = true
	_telegraph_t = telegraph_time
	telegraph_sprite.visible = true
	telegraph_sprite.scale = Vector2.ONE * 0.25
	AudioManager.play_sfx("telegraph", 1.0, -16.0)

func _fire() -> void:
	_telegraphing = false
	telegraph_sprite.visible = false
	_cd_timer = attack_cooldown
	if player == null or not is_instance_valid(player):
		return
	var dir := (player.global_position - global_position).normalized()
	BulletPool.spawn({
		"position": global_position, "direction": dir, "speed": bullet_speed,
		"damage": bullet_damage, "from_player": false, "kind": "enemy",
		"range": 300.0, "lifetime": 4.5,
	})
