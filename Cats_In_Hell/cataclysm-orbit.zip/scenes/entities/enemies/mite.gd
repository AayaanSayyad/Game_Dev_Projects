extends "res://scenes/entities/enemies/enemy_base.gd"
## Mite Swarm — fast, weak, spawned in packs by the Arena (intro wave 12).

func _ready() -> void:
	super._ready()
	splat_color = "purple"

func _enemy_physics_process(_delta: float) -> Vector2:
	if player == null or not is_instance_valid(player):
		return Vector2.ZERO
	return (player.global_position - global_position).normalized() * move_speed
