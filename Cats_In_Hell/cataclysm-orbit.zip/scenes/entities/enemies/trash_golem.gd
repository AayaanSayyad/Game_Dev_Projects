extends "res://scenes/entities/enemies/enemy_base.gd"
## Trash Golem — wave 25 mini-boss (design doc section 12: "slam + arc
## bullets"). Alternates a telegraphed melee slam with a ring bullet burst.
## Also reused (scaled up) as the wave-50 / wave-100 placeholder set pieces
## until the unique Orbital Compactor / Great Flea bosses are built.

var slam_cooldown := 3.2
var slam_telegraph := 0.9
var slam_radius := 46.0
var slam_damage := 2
var ring_bullet_count := 10
var ring_bullet_speed := 60.0

var _cd_timer := 1.5
var _telegraphing := false
var _telegraph_t := 0.0
var _next_is_slam := true

@onready var telegraph_sprite: Sprite2D = $TelegraphRing
signal boss_defeated

func _ready() -> void:
	super._ready()
	splat_color = "green"
	telegraph_sprite.visible = false

func configure_boss(data: Dictionary, hp_mult: float, speed_mult: float, bullet_speed_mult: float = 1.0) -> void:
	configure(data, hp_mult, speed_mult, false)
	slam_cooldown = float(data.get("slam_cooldown", 3.2))
	slam_telegraph = float(data.get("slam_telegraph", 0.9))
	slam_radius = float(data.get("slam_radius", 46.0))
	slam_damage = int(data.get("slam_damage", 2))
	ring_bullet_count = int(data.get("ring_bullet_count", 10))
	ring_bullet_speed = float(data.get("ring_bullet_speed", 60.0)) * bullet_speed_mult

func _enemy_physics_process(delta: float) -> Vector2:
	if player == null or not is_instance_valid(player):
		return Vector2.ZERO
	var to_player := player.global_position - global_position
	var dist := to_player.length()
	var desired := Vector2.ZERO

	if _telegraphing:
		_telegraph_t -= delta
		var t: float = 1.0 - clamp(_telegraph_t / slam_telegraph, 0.0, 1.0)
		telegraph_sprite.scale = Vector2.ONE * (0.4 + t * (slam_radius / 32.0))
		telegraph_sprite.modulate.a = 0.8
		if _telegraph_t <= 0.0:
			_execute_attack()
	else:
		if dist > 50.0:
			desired = to_player.normalized() * move_speed
		_cd_timer -= delta
		if _cd_timer <= 0.0:
			_start_telegraph()
	return desired

func _start_telegraph() -> void:
	_telegraphing = true
	_telegraph_t = slam_telegraph
	telegraph_sprite.visible = _next_is_slam
	AudioManager.play_sfx("telegraph", 0.7, -10.0)

func _execute_attack() -> void:
	_telegraphing = false
	telegraph_sprite.visible = false
	_cd_timer = slam_cooldown
	if _next_is_slam:
		_do_slam()
	else:
		_do_ring_burst()
	_next_is_slam = not _next_is_slam

func _do_slam() -> void:
	if player and is_instance_valid(player):
		if global_position.distance_to(player.global_position) <= slam_radius and player.has_method("take_hit"):
			player.take_hit(slam_damage, (player.global_position - global_position).normalized())
	AudioManager.play_sfx("hit", 0.6, -4.0)

func _do_ring_burst() -> void:
	for i in ring_bullet_count:
		var ang := TAU * float(i) / float(ring_bullet_count)
		var dir := Vector2.RIGHT.rotated(ang)
		BulletPool.spawn({
			"position": global_position, "direction": dir, "speed": ring_bullet_speed,
			"damage": 1, "from_player": false, "kind": "enemy", "range": 280.0, "lifetime": 5.0,
		})

func die() -> void:
	boss_defeated.emit()
	super.die()
