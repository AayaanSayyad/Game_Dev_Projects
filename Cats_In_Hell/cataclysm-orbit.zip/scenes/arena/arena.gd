extends Node2D
## Arena — ties together WaveDirector (formulas), BulletPool (container),
## the player, enemies, pickups and the in-run UI. One Arena instance = one
## attempt at the run, launched from House and torn down back to House on
## death or explicit retreat.

const GRUB_SCENE := preload("res://scenes/entities/enemies/grub.tscn")
const SPITTER_SCENE := preload("res://scenes/entities/enemies/spitter.tscn")
const MITE_SCENE := preload("res://scenes/entities/enemies/mite.tscn")
const TRASH_GOLEM_SCENE := preload("res://scenes/entities/enemies/trash_golem.tscn")
const FISH_PICKUP_SCENE := preload("res://scenes/entities/pickups/fish_pickup.tscn")
const AMIIBO_SCENE := preload("res://scenes/entities/amiibo/amiibo_orbiter.tscn")
const PLAYER_SCENE := preload("res://scenes/entities/player_cat.tscn")
const SPLAT_GREEN := preload("res://assets/sprites/fx/splat_green.png")
const SPLAT_PURPLE := preload("res://assets/sprites/fx/splat_purple.png")

const ENEMY_SCENES := {"grub": GRUB_SCENE, "spitter": SPITTER_SCENE, "mite": MITE_SCENE}
const SPAWN_RADIUS := 150.0
const BREATHER_TIME := 5.0

@onready var world: Node2D = $World
@onready var camera: Camera2D = $Camera2D
@onready var hud = $HUD
@onready var death_summary = $DeathSummary
@onready var milestone_picker = $MilestonePicker
@onready var pause_menu = $PauseMenu

var player: CharacterBody2D
var current_wave := 1
var _wave_active := false
var _boss_wave := false
var _quota := 0
var _spawned_this_wave := 0
var _spawn_timer := 0.0
var _breather := false
var _breather_timer := 0.0
var _paused := false
var _current_boss: Node = null
var _elite_hp_mult := 1.0
var _elite_speed_mult := 1.0
var _shake_time := 0.0
var _shake_amount := 0.0
var _run_over := false

func _ready() -> void:
	get_tree().paused = false
	pause_menu.process_mode = Node.PROCESS_MODE_ALWAYS
	death_summary.process_mode = Node.PROCESS_MODE_ALWAYS
	milestone_picker.process_mode = Node.PROCESS_MODE_ALWAYS

	BulletPool.set_container(world)
	camera.make_current()
	camera.rotation_degrees = 0.0
	var t := create_tween()
	t.tween_property(camera, "rotation_degrees", 9.0, 1.5).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)

	pause_menu.resume_pressed.connect(_on_resume)
	pause_menu.quit_to_house_pressed.connect(_on_quit_to_house)
	death_summary.retry_pressed.connect(_on_retry)
	death_summary.home_pressed.connect(_on_quit_to_house)
	milestone_picker.buff_chosen.connect(_on_buff_chosen)

	_spawn_player()
	_spawn_amiibo()
	hud.bind_player(player)
	current_wave = GameState.current_wave
	hud.set_wave(current_wave)
	AudioManager.play_music("combat")
	_start_wave(current_wave)

func _spawn_player() -> void:
	player = PLAYER_SCENE.instantiate()
	world.add_child(player)
	player.setup(GameState.selected_cat_id)
	player.global_position = Vector2.ZERO
	player.died.connect(_on_player_died)
	player.hurt.connect(func(_amt): request_shake(2.5, 0.12))
	camera.global_position = Vector2.ZERO

func _spawn_amiibo() -> void:
	var offset := 0.0
	for id in GameState.amiibo_slot_ids:
		if id == null:
			offset += PI
			continue
		var a = AMIIBO_SCENE.instantiate()
		world.add_child(a)
		a.setup(id, offset, player)
		offset += PI

func request_shake(amount: float = 3.0, duration: float = 0.15) -> void:
	if not GameState.settings.get("screen_shake", true):
		return
	_shake_time = max(_shake_time, duration)
	_shake_amount = max(_shake_amount, amount)

func _process(delta: float) -> void:
	if _run_over:
		return
	if not _paused and Input.is_action_just_pressed("pause_game"):
		_open_pause()
		return
	if get_tree().paused:
		return

	# camera soft-follow with a tiny dead zone (design doc section 4)
	if player and is_instance_valid(player):
		var diff: Vector2 = player.global_position - camera.global_position
		if diff.length() > 2.0:
			camera.global_position = camera.global_position.lerp(player.global_position, min(1.0, delta * 4.0))
	if _shake_time > 0.0:
		_shake_time -= delta
		camera.offset = Vector2(randf_range(-1, 1), randf_range(-1, 1)) * _shake_amount
		if _shake_time <= 0.0:
			camera.offset = Vector2.ZERO

	if _boss_wave:
		return
	elif _wave_active:
		_spawn_timer -= delta
		var cap: int = WaveDirector.enemy_count_cap(current_wave)
		if _spawn_timer <= 0.0 and _spawned_this_wave < _quota and _alive_enemy_count() < cap:
			_spawn_one_enemy()
			_spawn_timer = WaveDirector.spawn_interval(current_wave)
		if _spawned_this_wave >= _quota and _alive_enemy_count() == 0:
			_on_wave_cleared()
	elif _breather:
		_breather_timer -= delta
		hud.set_breather(true, _breather_timer)
		if _breather_timer <= 0.0:
			hud.set_breather(false)
			_advance_wave()

func _alive_enemy_count() -> int:
	return get_tree().get_nodes_in_group("enemy").size()

# ------------------------------------------------------------------- WAVES
func _start_wave(wave: int) -> void:
	GameState.current_wave = wave
	hud.set_wave(wave)
	var milestone: Dictionary = WaveDirector.milestone_info(wave)
	_elite_hp_mult = 1.0
	_elite_speed_mult = 1.0

	if milestone.get("type", "") in ["miniboss", "midboss", "planetboss"]:
		_start_boss_wave(wave, milestone)
		return

	if milestone.get("type", "") == "elite_wave":
		_elite_hp_mult = milestone.get("hp_mult", 1.0)
		_elite_speed_mult = milestone.get("speed_mult", 1.0)
		hud.show_banner(milestone.label, Color(1, 0.5, 0.5, 1))

	_boss_wave = false
	_wave_active = true
	_quota = WaveDirector.enemy_count_cap(wave) + 2
	_spawned_this_wave = 0
	_spawn_timer = 0.15

func _spawn_one_enemy() -> void:
	var id: String = WaveDirector.roll_enemy(current_wave)
	var data: Dictionary = EnemyData.get_enemy(id)
	var count: int = int(data.get("pack_size", 1))
	for i in count:
		_spawn_enemy_instance(id, data)
	_spawned_this_wave += count

func _spawn_enemy_instance(id: String, data: Dictionary) -> void:
	var scene: PackedScene = ENEMY_SCENES.get(id)
	if scene == null:
		return
	var e = scene.instantiate()
	world.add_child(e)
	var hp_mult: float = WaveDirector.enemy_hp_mult(current_wave) * _elite_hp_mult
	var bullet_mult: float = WaveDirector.bullet_speed_mult(current_wave)
	var is_elite: bool = _elite_hp_mult > 1.0
	if id == "spitter":
		e.configure(data, hp_mult, _elite_speed_mult, is_elite, bullet_mult)
	else:
		e.configure(data, hp_mult, _elite_speed_mult, is_elite)
	e.player = player
	var ang := randf() * TAU
	e.global_position = Vector2(cos(ang), sin(ang)) * SPAWN_RADIUS
	e.died.connect(_on_enemy_died)

func _on_enemy_died(enemy: Node) -> void:
	_spawn_fish_drop(enemy.global_position, enemy.fish_drops, enemy.is_elite)
	_spawn_splat(enemy.global_position, enemy.splat_color)

func _on_wave_cleared() -> void:
	_wave_active = false
	AudioManager.play_sfx("wave_clear")
	var milestone: Dictionary = WaveDirector.milestone_info(current_wave)
	if milestone.get("type", "") == "checkpoint_buff":
		_trigger_checkpoint_buff(milestone)
		return
	_breather = true
	_breather_timer = BREATHER_TIME
	hud.set_breather(true, _breather_timer)

func _advance_wave() -> void:
	_breather = false
	current_wave += 1
	if current_wave > WaveDirector.MAX_WAVE:
		_planet_cleared()
		return
	_start_wave(current_wave)

# ----------------------------------------------------------------- BOSSES
func _start_boss_wave(wave: int, milestone: Dictionary) -> void:
	_boss_wave = true
	_wave_active = false
	hud.show_banner(milestone.label, Color(1, 0.6, 0.3, 1))
	AudioManager.play_sfx("milestone")
	var data: Dictionary = EnemyData.miniboss()
	var hp_mult: float = WaveDirector.enemy_hp_mult(wave)
	var bullet_mult: float = WaveDirector.bullet_speed_mult(wave)
	var boss_count: int = 2 if milestone.get("type") == "planetboss" else 1
	var remaining := boss_count
	for i in boss_count:
		var b = TRASH_GOLEM_SCENE.instantiate()
		world.add_child(b)
		var this_hp_mult: float = hp_mult * (1.0 + 0.3 * i)
		b.configure_boss(data, this_hp_mult, 1.0, bullet_mult)
		b.player = player
		var ang := TAU * float(i) / float(boss_count)
		b.global_position = Vector2(cos(ang), sin(ang)) * (SPAWN_RADIUS * 0.7)
		b.died.connect(func(_e):
			remaining -= 1
			if remaining <= 0:
				_on_boss_defeated(milestone))

func _on_boss_defeated(milestone: Dictionary) -> void:
	_boss_wave = false
	AudioManager.play_sfx("wave_clear")
	if milestone.has("checkpoint") and milestone.checkpoint > 0:
		GameState.reach_checkpoint(milestone.checkpoint)
	_breather = true
	_breather_timer = BREATHER_TIME
	hud.set_breather(true, _breather_timer)
	hud.show_banner("Milestone cleared!", Color(0.6, 1, 0.6, 1), 1.6)

func _planet_cleared() -> void:
	_run_over = true
	GameState.planet_progress[GameState.PLANET_ID].cleared = true
	hud.show_banner("LITTER PRIME CLEARED!", Color(1, 0.9, 0.3, 1), 4.0)
	GameState.deposit_run_satchel_to_vault()
	GameState.end_run(false)
	await get_tree().create_timer(3.0).timeout
	_goto_house()

# ------------------------------------------------------------- CHECKPOINT
func _trigger_checkpoint_buff(milestone: Dictionary) -> void:
	get_tree().paused = true
	GameState.reach_checkpoint(milestone.checkpoint)
	var choices: Array = GameState.offer_buff_choices(3)
	milestone_picker.present("Checkpoint reached! Choose a buff:", choices)

func _on_buff_chosen(_id: String) -> void:
	get_tree().paused = false
	_breather = true
	_breather_timer = BREATHER_TIME
	hud.set_breather(true, _breather_timer)

# ------------------------------------------------------------------- FISH
func _spawn_fish_drop(pos: Vector2, count: int, is_elite: bool) -> void:
	for i in count:
		var f = FISH_PICKUP_SCENE.instantiate()
		world.add_child(f)
		var species: String = FishDatabase.roll_species(GameState.PLANET_ID)
		var rarity: int = FishDatabase.roll_rarity(is_elite, GameState.buff_lucky_gut())
		var jitter := Vector2(randf_range(-10, 10), randf_range(-10, 10))
		f.setup(pos + jitter, species, rarity, player)

func _spawn_splat(pos: Vector2, color: String) -> void:
	var s := Sprite2D.new()
	s.texture = SPLAT_PURPLE if color == "purple" else SPLAT_GREEN
	s.global_position = pos
	s.z_index = -1
	s.modulate.a = 0.85
	world.add_child(s)
	var t := create_tween()
	t.tween_interval(1.2)
	t.tween_property(s, "modulate:a", 0.0, 0.8)
	t.tween_callback(s.queue_free)

# ------------------------------------------------------------------- DEATH
func _on_player_died() -> void:
	_run_over = true
	get_tree().paused = true
	var penalty: Dictionary = GameState.apply_death_fish_penalty()
	GameState.deposit_run_satchel_to_vault()
	GameState.end_run(true)
	death_summary.show_summary(current_wave, penalty)

func _on_retry() -> void:
	get_tree().paused = false
	_goto_arena()

# ------------------------------------------------------------------- PAUSE
func _open_pause() -> void:
	_paused = true
	get_tree().paused = true
	pause_menu.open()

func _on_resume() -> void:
	_paused = false
	get_tree().paused = false
	pause_menu.close()

func _on_quit_to_house() -> void:
	get_tree().paused = false
	if not _run_over:
		GameState.deposit_run_satchel_to_vault()
		GameState.end_run(false)
	_goto_house()

func _goto_house() -> void:
	BulletPool.clear_all_active()
	get_tree().change_scene_to_file("res://scenes/house/house_screen.tscn")

func _goto_arena() -> void:
	BulletPool.clear_all_active()
	get_tree().change_scene_to_file("res://scenes/arena/arena.tscn")
