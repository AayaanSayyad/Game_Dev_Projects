# Cataclysm Orbit — Vertical Slice Build

A working Godot 4 implementation of the design doc, built and playtested (headless,
in-engine) rather than just scaffolded. This isn't a stub — the full House ↔ Arena
loop runs start to finish: pick a cat, launch, fight through scaling waves, hit the
wave-10 checkpoint/buff choice, beat the wave-25 Trash Golem mini-boss, die or
retreat, lose/keep fish, spend fish on house upgrades, repeat.

## Play it right now (no Godot install needed)

A pre-built browser version is in `export/web/`. Browsers block WASM games from
running via a plain `file://` path, so serve the folder over local HTTP:

```
cd export/web
python3 -m http.server 8000
```

Then open `http://localhost:8000/index.html`. (Any static host works too —
itch.io, GitHub Pages, Netlify, etc. — just upload the contents of `export/web/`.)

## Open it in the editor

Install **Godot 4.3+**, then "Import" this folder's `project.godot`. Press F5 to run.
`export_presets.cfg` is already configured for a Web export if you want to rebuild it
(Project → Export). Export templates aren't bundled (they're a ~1GB Godot download) —
if you re-export, grab them from Godot's download page first.

## Controls

- **Move**: WASD · **Aim**: Mouse · **Fire**: Hold Left Click / Space
- **Dash**: Shift (i-frames, short cooldown) · **Active skill**: E · **Pause**: Esc

## What's implemented

- **House hub** (not walkable — hotspot buttons, per the doc's own scope
  recommendation #9): Launch Pad, Roster Nest, Fish Vault, Blueprint Wall, Compost Bin
- **4 of the 16 designed cats**, fully playable, each with a distinct kit:
  Stray (rapid claws), Brick (arcing splash lobs), Soot (heavy melee hammer),
  Miso (support pulse + self-heal active). Brick/Soot/Miso unlock at wave 5/15/25.
- **Amiibo system**: slot 1 open from the start, slot 2 via the Window Perch upgrade,
  passives (move speed, pierce, bonus heart, etc.) apply live in combat
- **Twin-stick combat**: momentum movement, mouse aim, dash i-frames, pooled bullets
  (rapid/piercing/lobbed-splash), melee arc queries — tuned slower than Gungeon
  per the doc's pacing table (§4-5)
- **3 enemies + 1 mini-boss**: Grub (chase), Spitter (telegraphed ranged spores),
  Mite Swarm (fast pack), Trash Golem (wave-25 set piece: telegraphed slam +
  ring-burst attacks). All enemies get the mandatory hit-flash + cartoon-splat death.
- **WaveDirector**: the doc's exact scaling formulas (spawn rate, HP/bullet-speed
  multipliers, concurrent-enemy cap), running the full 1–100 curve
- **Milestones**: wave 10 = checkpoint + pick-1-of-3 buff (5 buffs implemented:
  +1 heart, fish magnet, lucky rarity rerolls, second wind, +1 pierce); wave 25 =
  Trash Golem mini-boss; wave 75 = elite-stat modifier; wave 50/100 = placeholder
  boss encounters (see Known Simplifications)
- **Fish system**: species × rarity (not generic currency), 12-species data table
  (3 active on Planet 1), magnet pickup, exact-recipe house upgrades
- **House upgrades**: Tent → Shack → Cat House (checkpoint gating), Smoker (fish
  conversion), Fish Safe (death-loss reduction), Window Perch (2nd Amiibo slot)
- **Death flow**: lose a % of the *run* satchel (not vault), half destroyed / half
  recoverable via the Compost Bin, respawn from checkpoint
- **Full save/load** to `user://save.json` matching the doc's schema
- **Juice**: camera rotation-tween on arena entry, soft-follow camera, screen shake
  (togglable), hit-flash/squash, splat decals, fish pop/hop/bounce, synthesized SFX
  + music beds, procedurally generated placeholder art throughout

## Known simplifications (flagged in code comments too)

- **Wave 50 / 100 bosses** reuse a scaled Trash Golem as a stand-in — the doc's
  unique Orbital Compactor / Great Flea are real Phase 2/3 content, not a quick add
- **`fish_safe` upgrade recipe** substitutes `tuna_mold` for the doc's `lobster_red`
  (lobster is a Planet 3/4 fish that doesn't exist yet in this build)
- **Gear system** (weapon/armor/trinket slots, crafting, death gear-loss) is
  deliberately deferred — the doc's own Phase 1 checklist excludes it too
  ("Death → house with fish % loss (no gear yet)")
- **Compost Bin** claims are instant rather than the doc's "every 10 runs" cadence
- All art/audio is procedurally generated placeholder (see `tools/`) — readable
  and on-tone (cute cats, no gore, no red splat) but not final art

## Project layout

```
autoload/         GameState, SaveManager, FishDatabase, BulletPool, WaveDirector, AudioManager
resources/        Data tables: cats, weapons/skills, enemies, house upgrades, collision layers
scenes/entities/   Player, enemies, bullets, pickups, amiibo orbiter
scenes/arena/      The run loop controller
scenes/house/      The hub
scenes/ui/         HUD, death summary, milestone picker, pause menu
tools/             Placeholder art/audio generators (Python + Pillow/numpy) — re-run
                   after editing to regenerate consistent-style assets for new content
```

## Suggested next steps

Phase 2 items from the doc that would build naturally on this foundation: gear
slots + crafting + death gear-loss, the real wave-50/100 boss fights, planets 2-4,
the remaining 12 cats, per-cat skill trees. Happy to tackle whichever you want
prioritized first.
