# Cataclysm Orbit — Browser Edition

A full rewrite: plain HTML5 Canvas + JavaScript, zero build step, zero engine
download. Everything you see — the cat, the room, the enemies, the planets —
is drawn live in code as flat-vector "colored outline" illustration; there
are no image files to load, so there's nothing that can fail to fetch.

## Play it

Open `index.html` directly in a browser (Chrome, Firefox, Safari, Edge — no
server needed, no install, works offline). That's it.

## What changed from the first pass

You asked for a full pivot off Godot to pure browser tech, a real separate
start screen, the House hub as its own loaded-in scene, and genuinely
beautiful isometric art instead of pixel-art placeholders. All four:

- **`index.html` boots straight to a Start screen** (title, a cat watching
  the sky from a litter-planet hillside, a ringed planet, a Play button) —
  it is a distinct scene from the House, not the same screen relabeled.
- **Play → House hub**, a fully separate scene: an isometric cozy room
  (two walls, a starry window with a moon, string lights, a lamp with a
  pulsing warm glow, a plant with individually-shaded leaves, a bookshelf,
  a rug, dust motes) with your cat sitting in the middle of it, hotspot
  buttons for Launch Pad / Roster / Vault / Blueprint Wall / Compost Bin.
- **Art direction**: every character and prop is built from the same small
  vector toolkit (`js/engine/canvas-utils.js`) — bold dark-purple outlines,
  soft gradient shading, consistent warm cozy-night palette. No pixel art
  anywhere in this build.
- **Same underlying game design as before** (this part wasn't the
  complaint) — 4 playable cats, Amiibo passives, species×rarity fish,
  exact-recipe house upgrades, the doc's wave-scaling formulas, checkpoint
  + buff at wave 10, Trash Golem mini-boss at wave 25 — just re-implemented
  in JS instead of GDScript.

## How I verified it actually works

I don't have a real browser in the environment I built this in, so I
downloaded `jsdom` + `node-canvas` and ran the *actual* `index.html` script
pipeline headlessly: clicked through every House panel via real DOM events,
force-completed every milestone wave (10/25/50/75/100) to confirm the buff
picker, mini-boss defeat + checkpoint save + roster-unlock cascade, death
summary + retry, and the planet-clear hand-off all fire correctly, and
rendered real frames through `node-canvas` to check the art (that's how the
in-repo screenshots were produced). `tools/smoke-test.js` is that same test,
cleaned up and left in the project — see below.

## Project layout

```
index.html            entry point — loads everything, boots to the Start scene
css/style.css          all UI styling (panels, buttons, HUD)
js/engine/             canvas-utils (art toolkit), game-state (save/run
                       state), game (scene manager + loop), input, audio-mgr
js/data/               fish/cat/weapon/enemy/upgrade data tables
js/render/             draw-cat, draw-house, draw-enemies, draw-fx,
                       draw-space, draw-arena — all the vector art
js/scenes/             start-scene, house-scene, arena-scene
assets/audio/          synthesized SFX + music beds (reused from the v1 pass)
tools/smoke-test.js    optional headless regression test (needs `npm install`
                       inside tools/ once — see its header comment)
```

Saves go to the browser's `localStorage` — nothing to configure, persists
across sessions on the same browser/device, resets if you clear site data.

## Controls

Move **WASD** · Aim **mouse** · Fire **hold click / Space** · Dash **Shift**
· Active skill **E** · Pause **Esc**

## Scope notes (same honest accounting as before)

- Wave 50/100 bosses are a scaled-up Trash Golem stand-in, not unique fights
  — flagged in `game-data.js`'s `WaveDirector.milestoneInfo()`.
- Gear/crafting system is still deferred (matches the design doc's own
  Phase 1 scope).
- `fish_safe`'s recipe substitutes `tuna_mold` for the doc's `lobster_red`
  (lobster is Planet 3/4, doesn't exist in this Planet-1-only slice).

## Next steps

Same menu as before: real wave-50/100 bosses, gear + crafting + death gear
loss, planets 2-4, the other 12 cats. Tell me which to prioritize.
