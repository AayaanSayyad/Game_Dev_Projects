/*
 * Headless smoke test for Cataclysm Orbit.
 *
 * Loads index.html's exact script pipeline in jsdom (no real browser needed),
 * drives the game with simulated input for a while, and fails loudly on any
 * thrown error. Useful as a fast regression check after editing game code.
 *
 * Setup (one-time):
 *   cd tools && npm install jsdom canvas
 * Run:
 *   node tools/smoke-test.js
 */
const { JSDOM } = require('jsdom');
const fs = require('fs');
const path = require('path');

const GAME_DIR = path.join(__dirname, '..');
const html = fs.readFileSync(path.join(GAME_DIR, 'index.html'), 'utf8');
const dom = new JSDOM(html, { url: 'http://localhost/', runScripts: 'outside-only', resources: 'usable', pretendToBeVisual: true });
const { window } = dom;

// ---- polyfills jsdom doesn't provide out of the box ----
const store = {};
window.localStorage = {
	getItem: (k) => (k in store ? store[k] : null),
	setItem: (k, v) => { store[k] = String(v); },
	removeItem: (k) => { delete store[k]; },
};
window.requestAnimationFrame = () => 0; // we drive ticks manually below
window.performance = window.performance || { now: () => Date.now() };
window.HTMLMediaElement.prototype.play = function () { return Promise.resolve(); };
window.HTMLMediaElement.prototype.pause = function () {};

let useRealCanvas = false;
try {
	const { createCanvas } = require('canvas');
	window.HTMLCanvasElement.prototype.getContext = function (type) {
		if (!this._nodeCanvas) this._nodeCanvas = createCanvas(this.width || 1280, this.height || 720);
		if (this._nodeCanvas.width !== this.width) this._nodeCanvas.width = this.width || 1280;
		if (this._nodeCanvas.height !== this.height) this._nodeCanvas.height = this.height || 720;
		return this._nodeCanvas.getContext(type);
	};
	useRealCanvas = true;
} catch (e) {
	// no `canvas` package installed — fall back to a no-op context (logic-only test, much faster)
	function noopCtx() { const h = { get(t, p) { if (p === 'canvas') return {}; return function () {}; } }; return new Proxy({}, h); }
	window.HTMLCanvasElement.prototype.getContext = () => noopCtx();
}

let errorCount = 0;
window.addEventListener('error', (e) => { errorCount++; console.error('WINDOW ERROR:', e.error ? (e.error.stack || e.error.message) : e.message); });
process.on('unhandledRejection', (e) => { errorCount++; console.error('UNHANDLED REJECTION:', e); });
process.on('uncaughtException', (e) => { errorCount++; console.error('UNCAUGHT EXCEPTION:', e.stack || e.message); });

const scripts = [
	'js/engine/canvas-utils.js', 'js/data/fish-data.js', 'js/data/game-data.js', 'js/engine/game-state.js',
	'js/engine/input.js', 'js/engine/audio-mgr.js', 'js/engine/game.js',
	'js/render/draw-cat.js', 'js/render/draw-house.js', 'js/render/draw-enemies.js', 'js/render/draw-fx.js', 'js/render/draw-space.js', 'js/render/draw-arena.js',
	'js/scenes/start-scene.js', 'js/scenes/house-scene.js', 'js/scenes/arena-scene.js',
];
for (const s of scripts) {
	try { window.eval(fs.readFileSync(path.join(GAME_DIR, s), 'utf8')); }
	catch (e) { errorCount++; console.error(`ERROR loading ${s}:`, e.stack || e.message); }
}

const Game = window.Game, GS = window.GameState;
Game.init();
console.log('[ok] Game.init() ->', Game.currentName);

function tick(n, dt) {
	dt = dt || 0.05;
	for (let i = 0; i < n; i++) {
		Game.t += dt;
		try {
			if (Game.current.update) Game.current.update(dt, Game.t);
			if (useRealCanvas) { Game.ctx.clearRect(0, 0, Game.W, Game.H); if (Game.current.render) Game.current.render(Game.ctx, Game.t); }
		} catch (e) { errorCount++; console.error(`TICK ERROR on '${Game.currentName}':`, e.stack || e.message); return false; }
		window.Input.endFrame();
	}
	return true;
}

// ---- Start -> House ----
tick(3);
window.document.querySelector('.btn-play').dispatchEvent(new window.MouseEvent('click', { bubbles: true }));
tick(3);
console.log('[ok] Start -> House:', Game.currentName === 'house');

// ---- House panels ----
['Launch Pad', 'Roster Nest', 'Fish Vault', 'Blueprint Wall', 'Compost Bin'].forEach((label) => {
	const btn = [...window.document.querySelectorAll('.hotspot-btn')].find((b) => b.textContent === label);
	if (!btn) { errorCount++; console.error('MISSING hotspot button:', label); return; }
	btn.dispatchEvent(new window.MouseEvent('click', { bubbles: true }));
	tick(2);
	const ok = !!window.document.querySelector('.panel');
	console.log(`[${ok ? 'ok' : 'FAIL'}] panel opens: ${label}`);
	if (!ok) errorCount++;
});

// ---- Upgrade purchase ----
GS.data.vaultFish.sardine_rotten = { Common: 20 };
[...window.document.querySelectorAll('.hotspot-btn')].find((b) => b.textContent === 'Blueprint Wall').click();
tick(1);
const buyBtn = [...window.document.querySelectorAll('.btn-small')].find((b) => b.textContent === 'Buy');
if (buyBtn) { buyBtn.click(); tick(1); }
console.log('[ok] tent purchase works:', GS.hasUpgrade('tent'));

// ---- Start a run, simulate combat for a while ----
GS.startRun('stray', [null, null]);
Game.goto('arena');
tick(3);
window.Input.mouse.down = true;
let ok = true;
for (let batch = 0; batch < 60 && ok; batch++) {
	const ang = batch * 0.25;
	window.Input.mouse.x = 640 + Math.cos(ang) * 300;
	window.Input.mouse.y = 400 + Math.sin(ang) * 200;
	window.Input.keys['KeyD'] = Math.cos(ang) > 0; window.Input.keys['KeyA'] = Math.cos(ang) <= 0;
	window.Input.keys['KeyW'] = Math.sin(ang) > 0; window.Input.keys['KeyS'] = Math.sin(ang) <= 0;
	ok = tick(10);
}
console.log(`[${ok ? 'ok' : 'FAIL'}] arena combat ran ~30s without throwing (wave ${GS.run.wave}, hearts ${GS.run.heartsCurrent}/${GS.run.heartsMax})`);

console.log(`\n${errorCount === 0 ? 'PASS' : 'FAIL'} — ${errorCount} error(s).`);
process.exit(errorCount > 0 ? 1 : 0);
