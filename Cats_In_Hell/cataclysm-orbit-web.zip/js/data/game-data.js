/* GameData — cats, weapons/skills, enemies, house upgrades. Ported 1:1 from
 * the design-doc-derived data tables (same numbers/kits as before), just in
 * JS object form instead of GDScript. Movement/combat numbers are tuned for
 * a 1280x720 canvas with the arena's world coordinates in CSS pixels.
 */
(function (root) {
	'use strict';

	// ---------------------------------------------------------------- CATS
	const CATS = {
		stray: {
			id: 'stray', name: 'Stray', role: 'Balanced', unlockWave: 0,
			maxHp: 6, moveSpeed: 145, accel: 1100, friction: 1400, weight: 1.0,
			dashSpeed: 400, dashTime: 0.16, dashIframes: 0.18, dashCooldown: 1.4,
			weapon: 'scratch_claws', skill: 'fleet_paws', starterGear: 'Scratch Claws',
			amiibo: { desc: '+5% move speed', key: 'move_speed_pct', value: 0.05 },
		},
		brick: {
			id: 'brick', name: 'Brick', role: 'Ranged', unlockWave: 5,
			maxHp: 6, moveSpeed: 130, accel: 950, friction: 1300, weight: 1.1,
			dashSpeed: 380, dashTime: 0.16, dashIframes: 0.18, dashCooldown: 1.5,
			weapon: 'hairball_slingshot', skill: 'hairball_barrage', starterGear: 'Hairball Slingshot',
			amiibo: { desc: '+1 pierce on primary', key: 'pierce_add', value: 1 },
		},
		soot: {
			id: 'soot', name: 'Soot', role: 'Bruiser', unlockWave: 15,
			maxHp: 8, moveSpeed: 108, accel: 780, friction: 1150, weight: 1.6,
			dashSpeed: 340, dashTime: 0.14, dashIframes: 0.16, dashCooldown: 1.7,
			weapon: 'rusty_forge_hammer', skill: 'anvil_slam', starterGear: 'Rusty Forge Hammer',
			amiibo: { desc: '-10% gear loss (Phase 2)', key: 'gear_loss_pct', value: -0.10 },
		},
		miso: {
			id: 'miso', name: 'Miso', role: 'Support', unlockWave: 25,
			maxHp: 6, moveSpeed: 138, accel: 1000, friction: 1350, weight: 0.9,
			dashSpeed: 380, dashTime: 0.16, dashIframes: 0.18, dashCooldown: 1.4,
			weapon: 'purr_wave', skill: 'purr_charm', starterGear: 'Purr Charm',
			amiibo: { desc: '+0.5 heart start', key: 'bonus_half_hearts', value: 1 },
		},
	};

	// ------------------------------------------------------------- WEAPONS
	const WEAPONS = {
		scratch_claws: { name: 'Scratch Claws', mode: 'rapid', cooldown: 0.14, damage: 1, speed: 340, spreadDeg: 6, pierce: 0, range: 320 },
		hairball_slingshot: { name: 'Hairball Slingshot', mode: 'lob', cooldown: 0.55, damage: 2, speed: 300, spreadDeg: 3, pierce: 0, range: 340, splash: 42 },
		rusty_forge_hammer: { name: 'Rusty Forge Hammer', mode: 'melee', cooldown: 0.85, damage: 3, meleeRange: 60, knockback: 320 },
		purr_wave: { name: 'Purr Wave', mode: 'rapid', cooldown: 0.32, damage: 1, speed: 260, spreadDeg: 4, pierce: 1, range: 300 },
	};

	const SKILLS = {
		fleet_paws: { name: 'Fleet Paws', type: 'speed_burst', cooldown: 9, duration: 2, multiplier: 1.6 },
		hairball_barrage: { name: 'Hairball Barrage', type: 'burst_fire', cooldown: 11, count: 5, spreadDeg: 55, damage: 2 },
		anvil_slam: { name: 'Anvil Slam', type: 'aoe_slam', cooldown: 10, damage: 5, radius: 90, windup: 0.45, knockback: 420 },
		purr_charm: { name: 'Purr Charm', type: 'heal_pulse', cooldown: 13, healHalfHearts: 2, radius: 120 },
	};

	// ------------------------------------------------------------- ENEMIES
	const ENEMIES = {
		grub: { name: 'Grub', maxHp: 3, speed: 95, contactDamage: 1, introWave: 1, fishDrops: 1, score: 10, color: '#7fbf5a' },
		spitter: {
			name: 'Spitter', maxHp: 4, speed: 40, contactDamage: 1, introWave: 3, fishDrops: 1, score: 15, color: '#9660bd',
			telegraphTime: 0.8, bulletSpeed: 140, bulletDamage: 1, attackCooldown: 2.2, attackRange: 300,
		},
		mite: { name: 'Mite Swarm', maxHp: 1, speed: 200, contactDamage: 1, introWave: 12, fishDrops: 1, score: 5, color: '#dc5a70', packSize: 4 },
	};
	const MINIBOSS = {
		name: 'Trash Golem', maxHp: 55, speed: 62, contactDamage: 2, fishDrops: 5, score: 200, color: '#6e7864',
		slamCooldown: 3.2, slamTelegraph: 0.9, slamRadius: 95, slamDamage: 2, ringCount: 10, ringSpeed: 115,
	};

	function poolForWave(wave) {
		const out = Object.keys(ENEMIES).filter((id) => ENEMIES[id].introWave <= wave);
		return out.length ? out : ['grub'];
	}
	function rollEnemy(wave) {
		const pool = poolForWave(wave);
		const weights = pool.map((id) => 1 + Math.min(Math.max(0, wave - ENEMIES[id].introWave) / 10, 2));
		const total = weights.reduce((a, b) => a + b, 0);
		let roll = Math.random() * total, acc = 0;
		for (let i = 0; i < pool.length; i++) {
			acc += weights[i];
			if (roll <= acc) return pool[i];
		}
		return pool[0];
	}

	// -------------------------------------------------------- HOUSE UPGRADES
	const UPGRADES = {
		tent: {
			name: 'Tent', track: 'Shelter', requires: null,
			cost: [{ species: 'sardine_rotten', rarity: 'Common', amount: 5 }],
			effect: 'unlock_checkpoints', desc: 'A cardboard tent — the bare minimum. Enables checkpoint saves.',
		},
		shack: {
			name: 'Shack', track: 'Shelter', requires: 'tent',
			cost: [{ species: 'mackerel_foul', rarity: 'Uncommon', amount: 3 }, { species: 'sardine_rotten', rarity: 'Common', amount: 2 }],
			effect: 'checkpoint_10', desc: 'Checkpoint save at wave 10.',
		},
		cat_house: {
			name: 'Cat House', track: 'Shelter', requires: 'shack',
			cost: [{ species: 'tuna_mold', rarity: 'Rare', amount: 2 }, { species: 'mackerel_foul', rarity: 'Common', amount: 5 }],
			effect: 'checkpoint_50', desc: 'Checkpoint save at wave 50.',
		},
		smoker: {
			name: 'Smoker', track: 'Workshop', requires: 'tent',
			cost: [{ species: 'sardine_rotten', rarity: 'Uncommon', amount: 6 }],
			effect: 'unlock_smoker', desc: 'Convert 5 Common fish into 1 Uncommon of the same species, from the Vault.',
		},
		fish_safe: {
			name: 'Fish Safe', track: 'Workshop', requires: 'tent',
			cost: [{ species: 'tuna_mold', rarity: 'Rare', amount: 4 }],
			effect: 'fish_loss_reduction', desc: 'Death fish loss reduced from 40% to 20% of your run satchel.',
		},
		window_perch: {
			name: 'Window Perch', track: 'Colony', requires: 'tent',
			cost: [{ species: 'sardine_rotten', rarity: 'Common', amount: 8 }],
			effect: 'amiibo_slot_2', desc: 'Unlocks your second Amiibo slot.',
		},
	};
	const TRACK_ORDER = ['Shelter', 'Workshop', 'Colony'];

	// ----------------------------------------------------------- MILESTONE BUFFS
	const BUFF_POOL = {
		warm_milk: { name: 'Warm Milk', desc: '+1 heart, right now.' },
		fish_magnet: { name: 'Fish Magnet', desc: '+30% fish pickup range.' },
		lucky_gut: { name: 'Lucky Gut', desc: 'Better odds at rare fish.' },
		second_wind: { name: 'Second Wind', desc: 'Revive once at 1 heart.' },
		piercing_claws: { name: 'Piercing Claws', desc: '+1 pierce on your primary, for the run.' },
	};

	// -------------------------------------------------------- WAVE DIRECTOR
	const WaveDirector = {
		MAX_WAVE: 100,
		spawnInterval(wave) { return lerp(1.7, 0.45, clamp01(wave / 100)); },
		enemyHpMult(wave) { return 1 + wave * 0.04; },
		bulletSpeedMult(wave) { return 1 + wave * 0.003; },
		enemyCountCap(wave) { return Math.min(8 + Math.floor(wave / 5), 24); },
		isMilestone(wave) { return [10, 25, 50, 75, 100].includes(wave); },
		milestoneInfo(wave) {
			switch (wave) {
				case 10: return { type: 'checkpoint_buff', checkpoint: 10, label: 'Wave 10 — Checkpoint' };
				case 25: return { type: 'miniboss', checkpoint: 25, label: 'Wave 25 — Trash Golem' };
				case 50: return { type: 'midboss', checkpoint: 50, label: 'Wave 50 — Orbital Compactor', note: 'Placeholder: scaled Trash Golem stand-in.' };
				case 75: return { type: 'elite_wave', checkpoint: 0, label: 'Wave 75 — Elite Modifier', hpMult: 1.5, speedMult: 1.3 };
				case 100: return { type: 'planetboss', checkpoint: 0, label: 'Wave 100 — The Great Flea', note: 'Placeholder: Trash Golem pair stand-in.' };
				default: return null;
			}
		},
	};
	function lerp(a, b, t) { return a + (b - a) * t; }
	function clamp01(v) { return Math.max(0, Math.min(1, v)); }

	root.GameData = { CATS, WEAPONS, SKILLS, ENEMIES, MINIBOSS, poolForWave, rollEnemy, UPGRADES, TRACK_ORDER, BUFF_POOL, WaveDirector, lerp, clamp01 };
})(typeof window !== 'undefined' ? window : globalThis);
