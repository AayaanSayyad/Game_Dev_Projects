/* DrawArena — the floating combat platform + space backdrop. */
(function (root) {
	'use strict';
	const U = (typeof window !== 'undefined' ? window : globalThis).IsoUtils;
	const SP = (typeof window !== 'undefined' ? window : globalThis).DrawSpace;

	function drawBackdrop(ctx, w, h, stars, t) {
		SP.drawSky(ctx, w, h, '#100c22', '#382a5c');
		SP.drawStars(ctx, stars, t);
		SP.drawPlanet(ctx, w * 0.86, h * 0.92, h * 0.42, '#5a4a80', null);
	}

	// Platform in WORLD space, centered at (cx,cy) with the given radii.
	function drawPlatform(ctx, cx, cy, rx, ry) {
		ctx.save();
		ctx.beginPath();
		ctx.ellipse(cx, cy + ry * 0.12, rx * 1.02, ry * 1.05, 0, 0, Math.PI * 2);
		ctx.fillStyle = 'rgba(0,0,0,0.35)';
		ctx.fill();
		const g = ctx.createRadialGradient(cx, cy - ry * 0.5, rx * 0.15, cx, cy, rx);
		g.addColorStop(0, '#8a7ab5');
		g.addColorStop(1, '#463a68');
		ctx.beginPath();
		ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
		U.fillStroke(ctx, g, U.OUTLINE, 4);
		ctx.beginPath();
		ctx.ellipse(cx, cy, rx * 0.84, ry * 0.82, 0, 0, Math.PI * 2);
		ctx.strokeStyle = 'rgba(255,255,255,0.14)';
		ctx.lineWidth = 2;
		ctx.stroke();
		ctx.beginPath();
		ctx.ellipse(cx, cy, rx * 0.5, ry * 0.48, 0, 0, Math.PI * 2);
		ctx.strokeStyle = 'rgba(255,255,255,0.09)';
		ctx.stroke();
		ctx.restore();
	}

	root.DrawArena = { drawBackdrop, drawPlatform };
})(typeof window !== 'undefined' ? window : globalThis);
