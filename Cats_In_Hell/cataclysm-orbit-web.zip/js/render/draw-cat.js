/* DrawCat — chibi cat character illustration, flat-vector cozy style.
 * One function draws a full sitting/idle cat from a small palette so every
 * playable cat (and their Amiibo icon) can share the same rig with
 * different colors. `t` drives a gentle breathing/tail-sway idle animation.
 */
(function (root) {
	'use strict';
	const U = (typeof window !== 'undefined' ? window : globalThis).IsoUtils;

	// Named palettes for the 4 v1 cats (also used by the roster/loadout UI).
	const CAT_PALETTES = {
		stray: { body: '#e8925c', belly: '#ffe3bd', accent: '#c96b3f', eye: '#2b1d33' },
		brick: { body: '#b5624a', belly: '#e8b79a', accent: '#8a4433', eye: '#2b1d33' },
		soot: { body: '#4a4650', belly: '#8d8894', accent: '#332f3a', eye: '#e8c96a' },
		miso: { body: '#f2e2c4', belly: '#fff8e8', accent: '#e0a0b0', eye: '#2b1d33' },
	};

	function drawCat(ctx, x, y, scale, palette, t, opts) {
		opts = opts || {};
		t = t || 0;
		const breathe = Math.sin(t * 1.8) * 0.02;
		const tailSway = Math.sin(t * 1.1) * 0.35;
		const blink = ((t * 0.6) % 4) > 3.85; // occasional quick blink

		ctx.save();
		ctx.translate(x, y);
		ctx.scale(scale, scale);

		U.softShadow(ctx, 0, 6, 30, 10, 0.25);

		// ---- tail (drawn first, behind body) ----
		ctx.save();
		ctx.strokeStyle = U.OUTLINE;
		ctx.lineWidth = 15;
		ctx.lineCap = 'round';
		ctx.beginPath();
		ctx.moveTo(20, 2);
		ctx.quadraticCurveTo(40 + tailSway * 6, -6, 34 + tailSway * 10, -30 - tailSway * 4);
		ctx.stroke();
		ctx.strokeStyle = palette.accent;
		ctx.lineWidth = 11;
		ctx.beginPath();
		ctx.moveTo(20, 2);
		ctx.quadraticCurveTo(40 + tailSway * 6, -6, 34 + tailSway * 10, -30 - tailSway * 4);
		ctx.stroke();
		ctx.restore();

		// ---- body (rounded sitting silhouette) ----
		ctx.beginPath();
		ctx.moveTo(-26, 8);
		ctx.bezierCurveTo(-30, -14, -20, -30, 0, -32 * (1 + breathe));
		ctx.bezierCurveTo(20, -30, 30, -14, 26, 8);
		ctx.bezierCurveTo(26, 18, 14, 22, 0, 22);
		ctx.bezierCurveTo(-14, 22, -26, 18, -26, 8);
		ctx.closePath();
		U.fillStroke(ctx, palette.body, U.OUTLINE, 3);

		// belly patch
		ctx.beginPath();
		ctx.ellipse(0, 6, 13, 15, 0, 0, Math.PI * 2);
		U.fillStroke(ctx, palette.belly, null);

		// front paws
		[-11, 11].forEach((dx) => {
			ctx.beginPath();
			ctx.ellipse(dx, 20, 8, 6, 0, 0, Math.PI * 2);
			U.fillStroke(ctx, palette.belly, U.OUTLINE, 2.5);
		});

		// ---- head ----
		const headY = -46 * (1 + breathe * 0.4);
		ctx.save();
		ctx.translate(0, headY);

		// ears
		[-1, 1].forEach((side) => {
			ctx.beginPath();
			ctx.moveTo(side * 10, -14);
			ctx.quadraticCurveTo(side * 26, -34, side * 18, -40);
			ctx.quadraticCurveTo(side * 8, -30, side * 6, -16);
			ctx.closePath();
			U.fillStroke(ctx, palette.body, U.OUTLINE, 3);
			ctx.beginPath();
			ctx.moveTo(side * 11, -18);
			ctx.quadraticCurveTo(side * 20, -30, side * 15, -34);
			ctx.quadraticCurveTo(side * 9, -27, side * 8, -19);
			ctx.closePath();
			U.fillStroke(ctx, U.shade(palette.accent, 0.25), null);
		});

		// head base
		ctx.beginPath();
		ctx.ellipse(0, -14, 26, 23, 0, 0, Math.PI * 2);
		U.fillStroke(ctx, palette.body, U.OUTLINE, 3);

		// cheek fluff / muzzle patch
		ctx.beginPath();
		ctx.ellipse(0, -4, 16, 11, 0, 0, Math.PI * 2);
		U.fillStroke(ctx, palette.belly, null);

		// blush
		ctx.fillStyle = U.rgba('#ff9fae', 0.35);
		ctx.beginPath(); ctx.ellipse(-16, -8, 5, 3.2, 0, 0, Math.PI * 2); ctx.fill();
		ctx.beginPath(); ctx.ellipse(16, -8, 5, 3.2, 0, 0, Math.PI * 2); ctx.fill();

		// eyes
		[-1, 1].forEach((side) => {
			ctx.save();
			ctx.translate(side * 9, -16);
			if (blink) {
				ctx.strokeStyle = palette.eye;
				ctx.lineWidth = 2.4;
				ctx.lineCap = 'round';
				ctx.beginPath(); ctx.moveTo(-4, 0); ctx.quadraticCurveTo(0, 3, 4, 0); ctx.stroke();
			} else {
				ctx.beginPath();
				ctx.ellipse(0, 0, 4.4, 5.6, 0, 0, Math.PI * 2);
				ctx.fillStyle = palette.eye;
				ctx.fill();
				ctx.beginPath();
				ctx.arc(-1.4, -1.6, 1.5, 0, Math.PI * 2);
				ctx.fillStyle = 'rgba(255,255,255,0.95)';
				ctx.fill();
			}
			ctx.restore();
		});

		// nose + mouth
		ctx.beginPath();
		ctx.moveTo(-2.6, -4); ctx.lineTo(2.6, -4); ctx.lineTo(0, -1);
		ctx.closePath();
		ctx.fillStyle = U.shade(palette.accent, 0.3);
		ctx.fill();
		ctx.strokeStyle = palette.eye;
		ctx.lineWidth = 1.6;
		ctx.lineCap = 'round';
		ctx.beginPath();
		ctx.moveTo(0, -1); ctx.lineTo(0, 1);
		ctx.moveTo(0, 1); ctx.quadraticCurveTo(-3.5, 4, -6, 1.5);
		ctx.moveTo(0, 1); ctx.quadraticCurveTo(3.5, 4, 6, 1.5);
		ctx.stroke();

		// whiskers
		ctx.strokeStyle = U.rgba('#ffffff', 0.75);
		ctx.lineWidth = 1.2;
		[-1, 1].forEach((side) => {
			for (let i = 0; i < 3; i++) {
				const yy = -6 + i * 3;
				ctx.beginPath();
				ctx.moveTo(side * 12, yy);
				ctx.lineTo(side * 24, yy - 2 + i * 2);
				ctx.stroke();
			}
		});

		ctx.restore(); // head translate
		ctx.restore(); // scale/translate
	}

	// Small circular "Amiibo" bubble icon version — reused by the House roster UI.
	function drawCatAmiiboIcon(ctx, x, y, radius, palette, t) {
		ctx.save();
		const g = ctx.createRadialGradient(x, y, 1, x, y, radius);
		g.addColorStop(0, 'rgba(180,225,255,0.35)');
		g.addColorStop(1, 'rgba(180,225,255,0.08)');
		ctx.fillStyle = g;
		ctx.beginPath(); ctx.arc(x, y, radius, 0, Math.PI * 2); ctx.fill();
		ctx.strokeStyle = 'rgba(220,245,255,0.8)';
		ctx.lineWidth = 2;
		ctx.beginPath(); ctx.arc(x, y, radius, 0, Math.PI * 2); ctx.stroke();
		ctx.save();
		ctx.beginPath(); ctx.arc(x, y, radius - 2, 0, Math.PI * 2); ctx.clip();
		drawCat(ctx, x, y + radius * 0.35, (radius / 46), palette, t || 0);
		ctx.restore();
		ctx.restore();
	}

	root.DrawCat = { drawCat, drawCatAmiiboIcon, CAT_PALETTES };
})(typeof window !== 'undefined' ? window : globalThis);
