/* DrawEnemies — cute-but-readable monster illustrations, same vector style
 * as DrawCat. Each draw fn takes (ctx, x, y, scale, t, hitFlash 0..1).
 */
(function (root) {
	'use strict';
	const U = (typeof window !== 'undefined' ? window : globalThis).IsoUtils;

	function withFlash(ctx, color, flash) {
		return flash > 0 ? U.shade(color, flash * 0.85) : color;
	}

	function grub(ctx, x, y, scale, t, flash) {
		flash = flash || 0;
		ctx.save(); ctx.translate(x, y); ctx.scale(scale, scale);
		U.softShadow(ctx, 0, 18, 20, 7, 0.25);
		const bob = Math.sin(t * 5) * 2;
		const body = withFlash(ctx, '#7fbf5a', flash);
		ctx.save(); ctx.translate(0, bob);
		// segmented body (3 bumps)
		[[-14, 6, 13], [0, 2, 15], [14, 6, 13]].forEach(([dx, dy, r], i) => {
			ctx.beginPath(); ctx.ellipse(dx, dy, r, r * 0.85, 0, 0, Math.PI * 2);
			U.fillStroke(ctx, i === 1 ? body : U.shade(body, -0.08), U.OUTLINE, 2.6);
		});
		// antennae
		ctx.strokeStyle = U.OUTLINE; ctx.lineWidth = 2.2; ctx.lineCap = 'round';
		[-1, 1].forEach((s) => { ctx.beginPath(); ctx.moveTo(s * 8, -8); ctx.lineTo(s * 13, -20); ctx.stroke();
			ctx.fillStyle = U.shade(body, 0.3); ctx.beginPath(); ctx.arc(s * 13, -20, 2.4, 0, Math.PI * 2); ctx.fill(); });
		// face
		ctx.fillStyle = '#20261c';
		ctx.beginPath(); ctx.ellipse(-5, 2, 3, 3.6, 0, 0, Math.PI * 2); ctx.fill();
		ctx.beginPath(); ctx.ellipse(5, 2, 3, 3.6, 0, 0, Math.PI * 2); ctx.fill();
		ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(-6, 0.5, 1, 0, Math.PI * 2); ctx.fill();
		ctx.beginPath(); ctx.arc(4, 0.5, 1, 0, Math.PI * 2); ctx.fill();
		ctx.restore();
		ctx.restore();
	}

	function spitter(ctx, x, y, scale, t, flash) {
		flash = flash || 0;
		ctx.save(); ctx.translate(x, y); ctx.scale(scale, scale);
		U.softShadow(ctx, 0, 20, 20, 7, 0.25);
		const squish = 1 + Math.sin(t * 3) * 0.04;
		const body = withFlash(ctx, '#9660bd', flash);
		ctx.save(); ctx.scale(1, squish);
		ctx.beginPath(); ctx.ellipse(0, 0, 22, 20, 0, 0, Math.PI * 2);
		U.fillStroke(ctx, body, U.OUTLINE, 3);
		ctx.beginPath(); ctx.ellipse(0, 6, 16, 12, 0, 0, Math.PI * 2);
		U.fillStroke(ctx, U.shade(body, 0.18), null);
		// eyes
		ctx.fillStyle = '#1c1224';
		ctx.beginPath(); ctx.ellipse(-8, -3, 3.4, 4.2, 0, 0, Math.PI * 2); ctx.fill();
		ctx.beginPath(); ctx.ellipse(8, -3, 3.4, 4.2, 0, 0, Math.PI * 2); ctx.fill();
		ctx.fillStyle = '#fff';
		ctx.beginPath(); ctx.arc(-9.3, -4.6, 1.1, 0, Math.PI * 2); ctx.fill();
		ctx.beginPath(); ctx.arc(6.7, -4.6, 1.1, 0, Math.PI * 2); ctx.fill();
		// little "o" mouth (spore spitter)
		ctx.strokeStyle = U.OUTLINE; ctx.lineWidth = 2;
		ctx.beginPath(); ctx.ellipse(0, 8, 4, 5, 0, 0, Math.PI * 2); ctx.stroke();
		ctx.fillStyle = '#3a2148'; ctx.fill();
		ctx.restore();
		// nubby feet
		ctx.fillStyle = U.shade(body, -0.1);
		[-11, 11].forEach((dx) => { ctx.beginPath(); ctx.ellipse(dx, 17, 5, 3.4, 0, 0, Math.PI * 2); ctx.fill();
			ctx.strokeStyle = U.OUTLINE; ctx.lineWidth = 2; ctx.stroke(); });
		ctx.restore();
	}

	function mite(ctx, x, y, scale, t, flash) {
		flash = flash || 0;
		ctx.save(); ctx.translate(x, y); ctx.scale(scale, scale);
		U.softShadow(ctx, 0, 10, 13, 5, 0.22);
		const skitter = Math.sin(t * 14) * 1.4;
		const body = withFlash(ctx, '#dc5a70', flash);
		ctx.save(); ctx.translate(0, skitter);
		ctx.strokeStyle = U.OUTLINE; ctx.lineWidth = 1.8;
		for (let s = -1; s <= 1; s += 2) {
			for (let i = 0; i < 3; i++) {
				ctx.beginPath();
				ctx.moveTo(s * 6, -2 + i * 3);
				ctx.lineTo(s * (14 + i), -6 + i * 5);
				ctx.stroke();
			}
		}
		ctx.beginPath(); ctx.ellipse(0, 0, 12, 10, 0, 0, Math.PI * 2);
		U.fillStroke(ctx, body, U.OUTLINE, 2.4);
		ctx.fillStyle = '#20141a';
		ctx.beginPath(); ctx.arc(-3.5, -1, 2, 0, Math.PI * 2); ctx.fill();
		ctx.beginPath(); ctx.arc(3.5, -1, 2, 0, Math.PI * 2); ctx.fill();
		ctx.restore();
		ctx.restore();
	}

	function trashGolem(ctx, x, y, scale, t, flash, telegraphFrac) {
		flash = flash || 0;
		ctx.save(); ctx.translate(x, y); ctx.scale(scale, scale);
		U.softShadow(ctx, 0, 46, 46, 16, 0.3);
		if (telegraphFrac > 0) {
			ctx.strokeStyle = U.rgba('#ff6060', 0.7);
			ctx.lineWidth = 3;
			ctx.beginPath(); ctx.arc(0, 20, 30 + telegraphFrac * 110, 0, Math.PI * 2); ctx.stroke();
		}
		const bob = Math.sin(t * 1.6) * 3;
		const body = withFlash(ctx, '#6e7864', flash);
		ctx.save(); ctx.translate(0, bob);
		// body block
		ctx.beginPath();
		U.roundedRectPath(ctx, -38, -34, 76, 68, 12);
		U.fillStroke(ctx, body, U.OUTLINE, 3.4);
		// junk patches
		[[-26, -22, 20, 16, '#b5624a'], [4, -26, 24, 18, '#5f8f8a'], [-24, 4, 18, 20, '#e8c565'], [6, 6, 24, 22, '#9660bd']]
			.forEach(([dx, dy, w, h, c]) => {
				ctx.save();
				U.roundedRectPath(ctx, dx, dy, w, h, 4);
				U.fillStroke(ctx, c, U.OUTLINE, 2);
				ctx.restore();
			});
		// eyes (angry)
		ctx.fillStyle = '#ff5b5b';
		ctx.beginPath(); ctx.ellipse(-14, -8, 6, 5, -0.2, 0, Math.PI * 2); ctx.fill();
		ctx.beginPath(); ctx.ellipse(14, -8, 6, 5, 0.2, 0, Math.PI * 2); ctx.fill();
		ctx.strokeStyle = U.OUTLINE; ctx.lineWidth = 2;
		ctx.beginPath(); ctx.ellipse(-14, -8, 6, 5, -0.2, 0, Math.PI * 2); ctx.stroke();
		ctx.beginPath(); ctx.ellipse(14, -8, 6, 5, 0.2, 0, Math.PI * 2); ctx.stroke();
		ctx.restore();
		ctx.restore();
	}

	root.DrawEnemies = { grub, spitter, mite, trashGolem };
})(typeof window !== 'undefined' ? window : globalThis);
