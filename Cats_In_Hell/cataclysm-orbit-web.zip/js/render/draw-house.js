/* DrawHouse — the cozy isometric room illustration for the House hub.
 * Built entirely from IsoUtils primitives (no image assets). Layout is a
 * classic "room corner" isometric view: two back walls meeting at a back
 * vertex, floor diamond in front, furniture placed on top.
 */
(function (root) {
	'use strict';
	const U = (typeof window !== 'undefined' ? window : globalThis).IsoUtils;

	const PALETTE = {
		skyTop: '#241a3d', skyBottom: '#4a3670',
		wallLeft: '#caa591', wallRight: '#e0b98f',
		floor: '#b9825a', floorDark: '#a06f4a',
		rug: '#5f8f8a', rugAccent: '#e8c565',
		wood: '#7a5236', woodDark: '#5c3d28',
		leaf1: '#6f9c56', leaf2: '#8fbf6a', leaf3: '#4f7a40',
		pot: '#c96b4f', potDark: '#a3523a',
		lampGlow: '#ffd27a', lampShade: '#e8925c',
		star: '#fff3d0',
	};

	// Room geometry (screen space). Room "center" is the back vertex.
	function roomGeometry(cx, cyBack, floorW, floorD, wallH) {
		const N = { x: cx, y: cyBack };
		const S = { x: cx, y: cyBack + floorD };
		const E = { x: cx + floorW / 2, y: cyBack + floorD / 2 };
		const W = { x: cx - floorW / 2, y: cyBack + floorD / 2 };
		return { N, S, E, W, wallH };
	}

	function drawBackdrop(ctx, w, h) {
		const g = ctx.createLinearGradient(0, 0, 0, h);
		g.addColorStop(0, PALETTE.skyTop);
		g.addColorStop(1, PALETTE.skyBottom);
		ctx.fillStyle = g;
		ctx.fillRect(0, 0, w, h);
	}

	function drawWalls(ctx, room) {
		const { N, S, E, W, wallH } = room;
		// left wall (W -> N)
		ctx.beginPath();
		ctx.moveTo(W.x, W.y);
		ctx.lineTo(N.x, N.y);
		ctx.lineTo(N.x, N.y - wallH);
		ctx.lineTo(W.x, W.y - wallH);
		ctx.closePath();
		U.fillStroke(ctx, PALETTE.wallLeft, U.OUTLINE, 3);
		// right wall (N -> E)
		ctx.beginPath();
		ctx.moveTo(N.x, N.y);
		ctx.lineTo(E.x, E.y);
		ctx.lineTo(E.x, E.y - wallH);
		ctx.lineTo(N.x, N.y - wallH);
		ctx.closePath();
		U.fillStroke(ctx, PALETTE.wallRight, U.OUTLINE, 3);
		// baseboard trim (subtle darker strip along the floor line)
		ctx.save();
		ctx.strokeStyle = U.rgba('#000000', 0.12);
		ctx.lineWidth = 5;
		ctx.beginPath();
		ctx.moveTo(W.x, W.y); ctx.lineTo(N.x, N.y); ctx.lineTo(E.x, E.y);
		ctx.stroke();
		ctx.restore();
	}

	function drawWindow(ctx, room, t) {
		// Place the window as a sub-rectangle of the left wall's parallelogram
		// using the wall's own (u along W->N, v up the wall) basis, so it sits
		// perfectly flush/skewed with the wall face.
		const { N, W, wallH } = room;
		const ux = N.x - W.x, uy = N.y - W.y; // wall "horizontal" basis
		const vx = 0, vy = -wallH;            // wall "vertical" basis
		const base = { x: W.x, y: W.y };
		function P(u, v) { return { x: base.x + ux * u + vx * v, y: base.y + uy * u + vy * v }; }
		const u0 = 0.22, u1 = 0.56, v0 = 0.38, v1 = 0.88;
		const c00 = P(u0, v0), c10 = P(u1, v0), c11 = P(u1, v1), c01 = P(u0, v1);

		ctx.save();
		ctx.beginPath();
		ctx.moveTo(c01.x, c01.y); ctx.lineTo(c00.x, c00.y); ctx.lineTo(c10.x, c10.y); ctx.lineTo(c11.x, c11.y);
		ctx.closePath();
		ctx.save();
		ctx.clip();
		const cx = (c00.x + c11.x) / 2, cy = (c00.y + c11.y) / 2;
		const minX = Math.min(c00.x, c01.x, c10.x, c11.x) - 4;
		const maxX = Math.max(c00.x, c01.x, c10.x, c11.x) + 4;
		const minY = Math.min(c00.y, c01.y, c10.y, c11.y) - 4;
		const maxY = Math.max(c00.y, c01.y, c10.y, c11.y) + 4;
		const g = ctx.createLinearGradient(cx, minY, cx, maxY);
		g.addColorStop(0, '#1a1338');
		g.addColorStop(1, '#3d2f66');
		ctx.fillStyle = g;
		ctx.fillRect(minX, minY, maxX - minX, maxY - minY);
		const starUV = [[0.3, 0.25], [0.7, 0.4], [0.85, 0.2], [0.2, 0.62], [0.55, 0.7], [0.15, 0.85], [0.45, 0.5]];
		starUV.forEach((uv, i) => {
			const p = P(u0 + (u1 - u0) * uv[0], v0 + (v1 - v0) * (1 - uv[1]));
			const tw = 0.55 + 0.45 * Math.sin(t * 1.6 + i * 1.3);
			ctx.fillStyle = U.rgba(PALETTE.star, tw);
			ctx.beginPath(); ctx.arc(p.x, p.y, 1.7, 0, Math.PI * 2); ctx.fill();
		});
		const moonP = P(u0 + (u1 - u0) * 0.72, v0 + (v1 - v0) * 0.78);
		ctx.fillStyle = '#f6ecc9';
		ctx.beginPath(); ctx.arc(moonP.x, moonP.y, 10, 0, Math.PI * 2); ctx.fill();
		ctx.fillStyle = '#3d2f66';
		ctx.beginPath(); ctx.arc(moonP.x + 4, moonP.y - 3, 9, 0, Math.PI * 2); ctx.fill();
		ctx.restore();
		// frame
		ctx.lineWidth = 3; ctx.strokeStyle = U.OUTLINE;
		ctx.beginPath();
		ctx.moveTo(c01.x, c01.y); ctx.lineTo(c00.x, c00.y); ctx.lineTo(c10.x, c10.y); ctx.lineTo(c11.x, c11.y); ctx.closePath();
		ctx.stroke();
		// mullion cross through the middle
		const mMid1 = P((u0 + u1) / 2, v0), mMid2 = P((u0 + u1) / 2, v1);
		const mMid3 = P(u0, (v0 + v1) / 2), mMid4 = P(u1, (v0 + v1) / 2);
		ctx.lineWidth = 2.5;
		ctx.beginPath(); ctx.moveTo(mMid1.x, mMid1.y); ctx.lineTo(mMid2.x, mMid2.y); ctx.stroke();
		ctx.beginPath(); ctx.moveTo(mMid3.x, mMid3.y); ctx.lineTo(mMid4.x, mMid4.y); ctx.stroke();
		ctx.restore();
	}

	function drawFloor(ctx, room) {
		const { N, S, E, W } = room;
		ctx.beginPath();
		ctx.moveTo(N.x, N.y); ctx.lineTo(E.x, E.y); ctx.lineTo(S.x, S.y); ctx.lineTo(W.x, W.y);
		ctx.closePath();
		const g = ctx.createLinearGradient(N.x, N.y, S.x, S.y);
		g.addColorStop(0, PALETTE.floorDark);
		g.addColorStop(1, PALETTE.floor);
		U.fillStroke(ctx, g, U.OUTLINE, 3);
		// plank seams (a few lines parallel to the N-E edge)
		ctx.save();
		ctx.clip();
		ctx.strokeStyle = U.rgba('#000000', 0.08);
		ctx.lineWidth = 2;
		for (let i = -3; i <= 3; i++) {
			ctx.beginPath();
			ctx.moveTo(N.x + i * 26, N.y + i * 13 - 200);
			ctx.lineTo(N.x + i * 26 + 400, N.y + i * 13 + 200);
			ctx.stroke();
		}
		ctx.restore();
	}

	function drawRug(ctx, cx, cy) {
		U.isoDiamond(ctx, cx, cy, 150, 75, PALETTE.rug, U.OUTLINE, 3);
		U.isoDiamond(ctx, cx, cy, 110, 55, U.shade(PALETTE.rug, 0.12), U.OUTLINE, 2);
		U.isoDiamond(ctx, cx, cy, 70, 35, PALETTE.rugAccent, U.OUTLINE, 2);
	}

	function drawCrateStack(ctx, x, y) {
		U.isoCube(ctx, x, y, 46, 46, 30, PALETTE.wood);
		U.isoCube(ctx, x, y - 30, 46, 46, 26, U.shade(PALETTE.wood, -0.08));
	}

	function drawBookshelf(ctx, x, y) {
		U.isoCube(ctx, x, y, 60, 34, 56, PALETTE.wood, { left: U.shade(PALETTE.wood, -0.1), right: U.shade(PALETTE.wood, -0.32) });
		const bookColors = ['#c96b4f', '#5f8f8a', '#e8c565', '#8fbf6a', '#b5624a'];
		for (let shelf = 0; shelf < 2; shelf++) {
			let bx = x - 22;
			const by = y - 12 - shelf * 22;
			for (let i = 0; i < 5; i++) {
				const bw = 6 + (i % 3) * 2;
				const bh = 14 + (i % 2) * 4;
				ctx.save();
				ctx.translate(bx, by);
				ctx.transform(1, 0.5, 0, 1, 0, 0);
				ctx.fillStyle = bookColors[i % bookColors.length];
				ctx.strokeStyle = U.OUTLINE; ctx.lineWidth = 1.6;
				ctx.beginPath();
				ctx.rect(0, -bh, bw, bh);
				ctx.fill(); ctx.stroke();
				ctx.restore();
				bx += bw + 1.5;
			}
		}
	}

	function drawStringLights(ctx, p1, p2, t, count) {
		const sagAmt = 14;
		ctx.save();
		ctx.strokeStyle = U.rgba('#3a2c1a', 0.8);
		ctx.lineWidth = 1.6;
		ctx.beginPath();
		ctx.moveTo(p1.x, p1.y);
		ctx.quadraticCurveTo((p1.x + p2.x) / 2, Math.max(p1.y, p2.y) + sagAmt, p2.x, p2.y);
		ctx.stroke();
		for (let i = 0; i <= count; i++) {
			const u = i / count;
			const x = p1.x + (p2.x - p1.x) * u;
			const yBase = p1.y + (p2.y - p1.y) * u;
			const sag = sagAmt * 4 * u * (1 - u);
			const y = yBase + sag;
			const glow = 0.6 + 0.4 * Math.sin(t * 2 + i * 1.7);
			U.radialGlow(ctx, x, y, 9 * glow, U.rgba('#ffd27a', 0.55 * glow), U.rgba('#ffd27a', 0));
			ctx.fillStyle = ['#ffd27a', '#ff9fae', '#8fd6c9', '#ffd27a'][i % 4];
			ctx.strokeStyle = U.OUTLINE; ctx.lineWidth = 1.2;
			ctx.beginPath(); ctx.arc(x, y, 3, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
		}
		ctx.restore();
	}

	function drawCushion(ctx, x, y, color) {
		U.softShadow(ctx, x, y + 3, 26, 12, 0.2);
		U.isoDiamond(ctx, x, y, 52, 26, color, U.OUTLINE, 2.5);
		U.isoDiamond(ctx, x, y - 4, 44, 22, U.shade(color, 0.12), U.OUTLINE, 2);
	}

	function drawPlant(ctx, x, y, t) {
		U.softShadow(ctx, x, y + 4, 22, 10, 0.22);
		U.isoCube(ctx, x, y, 34, 34, 26, PALETTE.pot, { left: PALETTE.potDark, right: U.shade(PALETTE.potDark, -0.2) });
		const topY = y - 26 - 4;
		const sway = Math.sin(t * 1.2) * 3;
		const leaves = [
			{ dx: 0, dy: -6, len: 46, wid: 13, ang: -100, color: PALETTE.leaf3 },
			{ dx: 0, dy: -4, len: 42, wid: 13, ang: -70, color: PALETTE.leaf2 },
			{ dx: -2, dy: -2, len: 38, wid: 12, ang: -135, color: PALETTE.leaf1 },
			{ dx: 2, dy: -2, len: 38, wid: 12, ang: -45, color: PALETTE.leaf1 },
			{ dx: 0, dy: 0, len: 30, wid: 11, ang: -155, color: PALETTE.leaf2 },
			{ dx: 0, dy: 0, len: 30, wid: 11, ang: -25, color: PALETTE.leaf3 },
		];
		leaves.forEach((leaf, i) => {
			ctx.save();
			ctx.translate(x + leaf.dx + sway * 0.4, topY + leaf.dy);
			const wobble = Math.sin(t * 1.4 + i) * 0.04;
			ctx.rotate((leaf.ang * Math.PI) / 180 + wobble);
			// a single pointed leaf blade, drawn tip-up along local -Y axis
			ctx.beginPath();
			ctx.moveTo(0, 0);
			ctx.quadraticCurveTo(leaf.wid, -leaf.len * 0.4, 0, -leaf.len);
			ctx.quadraticCurveTo(-leaf.wid, -leaf.len * 0.4, 0, 0);
			ctx.closePath();
			U.fillStroke(ctx, leaf.color, U.OUTLINE, 2.2);
			// center vein
			ctx.strokeStyle = U.rgba('#000000', 0.18);
			ctx.lineWidth = 1.4;
			ctx.beginPath(); ctx.moveTo(0, -3); ctx.lineTo(0, -leaf.len + 4); ctx.stroke();
			ctx.restore();
		});
	}

	function drawLamp(ctx, x, topY, floorY, t) {
		// hanging pendant lamp with a warm pulsing glow
		const glow = 0.85 + 0.15 * Math.sin(t * 1.7);
		ctx.save();
		ctx.strokeStyle = U.OUTLINE; ctx.lineWidth = 2.5;
		ctx.beginPath(); ctx.moveTo(x, topY); ctx.lineTo(x, topY + 40); ctx.stroke();
		U.radialGlow(ctx, x, topY + 58, 70 * glow, U.rgba(PALETTE.lampGlow, 0.55 * glow), U.rgba(PALETTE.lampGlow, 0));
		ctx.beginPath();
		ctx.moveTo(x - 16, topY + 40);
		ctx.lineTo(x + 16, topY + 40);
		ctx.lineTo(x + 10, topY + 58);
		ctx.lineTo(x - 10, topY + 58);
		ctx.closePath();
		U.fillStroke(ctx, PALETTE.lampShade, U.OUTLINE, 2.5);
		ctx.fillStyle = U.rgba('#fff3cf', glow);
		ctx.beginPath(); ctx.arc(x, topY + 62, 6, 0, Math.PI * 2); ctx.fill();
		ctx.restore();
	}

	function drawDustMotes(ctx, cx, cy, w, h, t, count) {
		ctx.save();
		for (let i = 0; i < count; i++) {
			const seed = i * 12.9898;
			const px = cx + ((Math.sin(seed) * 0.5 + 0.5) - 0.5) * w;
			const speed = 0.15 + (i % 3) * 0.05;
			const py = cy + (((t * speed + i * 0.37) % 1) - 0.5) * h;
			const a = 0.25 + 0.2 * Math.sin(t * 2 + i);
			ctx.fillStyle = U.rgba('#ffe9b8', Math.max(0, a));
			ctx.beginPath();
			ctx.arc(px, py, 1.4, 0, Math.PI * 2);
			ctx.fill();
		}
		ctx.restore();
	}

	root.DrawHouse = { PALETTE, roomGeometry, drawBackdrop, drawWalls, drawWindow, drawFloor, drawRug, drawCrateStack, drawBookshelf, drawStringLights, drawCushion, drawPlant, drawLamp, drawDustMotes };
})(typeof window !== 'undefined' ? window : globalThis);
