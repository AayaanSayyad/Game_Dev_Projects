/* DrawFx — bullets, splats, sparks, telegraph rings. */
(function (root) {
	'use strict';
	const U = (typeof window !== 'undefined' ? window : globalThis).IsoUtils;

	function bullet(ctx, x, y, angle, kind, scale) {
		scale = scale || 1;
		ctx.save();
		ctx.translate(x, y);
		ctx.rotate(angle);
		const colors = {
			player: { fill: '#ffe38c', outline: '#c98a20' },
			enemy: { fill: '#c98cf0', outline: '#6a2f8f' },
			lob: { fill: '#ffb35a', outline: '#a05a1a' },
		}[kind] || { fill: '#fff', outline: '#333' };
		U.radialGlow(ctx, 0, 0, 12 * scale, U.rgba(colors.fill, 0.45), U.rgba(colors.fill, 0));
		ctx.beginPath();
		ctx.ellipse(0, 0, 5.5 * scale, 4 * scale, 0, 0, Math.PI * 2);
		U.fillStroke(ctx, colors.fill, colors.outline, 1.8);
		ctx.restore();
	}

	// splat decal: cartoon goo blob (green/purple only, no gore per doc tone)
	function splat(ctx, x, y, color, alpha, seed, size) {
		size = size || 24;
		ctx.save();
		ctx.globalAlpha = alpha === undefined ? 1 : alpha;
		ctx.translate(x, y);
		const rand = mulberry32(seed || 1);
		for (let i = 0; i < 6; i++) {
			const a = rand() * Math.PI * 2;
			const d = rand() * size * 0.5;
			const r = size * (0.18 + rand() * 0.22);
			ctx.beginPath();
			ctx.ellipse(Math.cos(a) * d, Math.sin(a) * d * 0.6, r, r * 0.8, a, 0, Math.PI * 2);
			ctx.fillStyle = U.rgba(color, 0.55 + rand() * 0.25);
			ctx.fill();
		}
		ctx.restore();
	}

	function mulberry32(a) {
		return function () {
			a |= 0; a = (a + 0x6D2B79F5) | 0;
			let t = Math.imul(a ^ (a >>> 15), 1 | a);
			t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
			return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
		};
	}

	function spark(ctx, x, y, color, alpha) {
		ctx.save();
		ctx.fillStyle = U.rgba(color, alpha === undefined ? 1 : alpha);
		ctx.beginPath(); ctx.arc(x, y, 3, 0, Math.PI * 2); ctx.fill();
		ctx.restore();
	}

	function telegraphRing(ctx, x, y, radius, frac, color) {
		ctx.save();
		ctx.strokeStyle = U.rgba(color || '#ff6060', 0.35 + 0.45 * frac);
		ctx.lineWidth = 2.5;
		ctx.beginPath(); ctx.arc(x, y, radius * frac, 0, Math.PI * 2); ctx.stroke();
		ctx.restore();
	}

	function hitFlashRing(ctx, x, y, radius, alpha) {
		ctx.save();
		ctx.strokeStyle = U.rgba('#ffffff', alpha);
		ctx.lineWidth = 2;
		ctx.beginPath(); ctx.arc(x, y, radius, 0, Math.PI * 2); ctx.stroke();
		ctx.restore();
	}

	root.DrawFx = { bullet, splat, spark, telegraphRing, hitFlashRing };
})(typeof window !== 'undefined' ? window : globalThis);
