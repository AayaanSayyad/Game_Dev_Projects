/* DrawSpace — starfield + planet backdrop shared by Start screen & Arena. */
(function (root) {
	'use strict';
	const U = (typeof window !== 'undefined' ? window : globalThis).IsoUtils;

	// Deterministic star field so it doesn't re-randomize every frame.
	function makeStars(count, w, h, seed) {
		let s = seed || 7;
		function rand() { s = (s * 16807) % 2147483647; return (s / 2147483647); }
		const stars = [];
		for (let i = 0; i < count; i++) {
			stars.push({ x: rand() * w, y: rand() * h * 0.75, r: 0.6 + rand() * 1.6, phase: rand() * Math.PI * 2, speed: 0.5 + rand() * 1.2 });
		}
		return stars;
	}

	function drawSky(ctx, w, h, topColor, bottomColor) {
		const g = ctx.createLinearGradient(0, 0, 0, h);
		g.addColorStop(0, topColor || '#1a1330');
		g.addColorStop(1, bottomColor || '#4a3670');
		ctx.fillStyle = g;
		ctx.fillRect(0, 0, w, h);
	}

	function drawStars(ctx, stars, t) {
		ctx.save();
		stars.forEach((s) => {
			const tw = 0.5 + 0.5 * Math.sin(t * s.speed + s.phase);
			ctx.fillStyle = `rgba(255,246,214,${(0.35 + 0.55 * tw).toFixed(2)})`;
			ctx.beginPath(); ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2); ctx.fill();
		});
		ctx.restore();
	}

	function drawPlanet(ctx, x, y, r, coreColor, ringColor) {
		ctx.save();
		// soft atmosphere glow
		U.radialGlow(ctx, x, y, r * 1.6, U.rgba(coreColor, 0.25), U.rgba(coreColor, 0));
		if (ringColor) {
			ctx.save();
			ctx.translate(x, y);
			ctx.rotate(-0.25);
			ctx.scale(1, 0.32);
			ctx.beginPath(); ctx.arc(0, 0, r * 1.7, 0, Math.PI * 2);
			ctx.strokeStyle = U.rgba(ringColor, 0.8);
			ctx.lineWidth = r * 0.16;
			ctx.stroke();
			ctx.restore();
		}
		const g = ctx.createRadialGradient(x - r * 0.35, y - r * 0.35, r * 0.1, x, y, r);
		g.addColorStop(0, U.shade(coreColor, 0.35));
		g.addColorStop(1, U.shade(coreColor, -0.25));
		ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2);
		U.fillStroke(ctx, g, U.OUTLINE, 3);
		// craters/spots
		[[-0.3, -0.1, 0.22], [0.25, 0.2, 0.16], [0.05, -0.35, 0.12]].forEach(([dx, dy, rr]) => {
			ctx.beginPath();
			ctx.arc(x + dx * r, y + dy * r, rr * r, 0, Math.PI * 2);
			ctx.fillStyle = U.rgba('#000000', 0.12);
			ctx.fill();
		});
		if (ringColor) {
			ctx.save();
			ctx.translate(x, y);
			ctx.rotate(-0.25);
			ctx.scale(1, 0.32);
			ctx.beginPath();
			ctx.arc(0, 0, r * 1.15, Math.PI * 0.05, Math.PI * 0.95);
			ctx.strokeStyle = U.rgba(ringColor, 0.9);
			ctx.lineWidth = r * 0.1;
			ctx.stroke();
			ctx.restore();
		}
		ctx.restore();
	}

	function drawShootingStar(ctx, x, y, len, angle, alpha) {
		ctx.save();
		ctx.translate(x, y);
		ctx.rotate(angle);
		const g = ctx.createLinearGradient(0, 0, -len, 0);
		g.addColorStop(0, `rgba(255,255,255,${alpha})`);
		g.addColorStop(1, 'rgba(255,255,255,0)');
		ctx.strokeStyle = g;
		ctx.lineWidth = 2;
		ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(-len, 0); ctx.stroke();
		ctx.restore();
	}

	root.DrawSpace = { makeStars, drawSky, drawStars, drawPlanet, drawShootingStar };
})(typeof window !== 'undefined' ? window : globalThis);
