/* Scene: Arena — the run loop. Combat, waves, milestones, death/checkpoint. */
(function (root) {
	'use strict';
	const Game = root.Game, GS = root.GameState, GD = root.GameData, FD = root.FishData;

	const ARENA = { cx: Game.W / 2, cy: Game.H / 2 + 40, rx: 300, ry: 148 };
	const BREATHER_TIME = 5.0;

	function clampToArena(pos) {
		const dx = (pos.x - ARENA.cx) / ARENA.rx, dy = (pos.y - ARENA.cy) / ARENA.ry;
		const d = Math.hypot(dx, dy);
		if (d > 1) {
			pos.x = ARENA.cx + (dx / d) * ARENA.rx;
			pos.y = ARENA.cy + (dy / d) * ARENA.ry;
		}
	}
	function dist(a, b) { return Math.hypot(a.x - b.x, a.y - b.y); }
	function normalize(v) { const l = Math.hypot(v.x, v.y) || 1; return { x: v.x / l, y: v.y / l }; }

	// ============================================================== PLAYER
	class Player {
		constructor(catId) {
			this.catId = catId;
			this.cat = GD.CATS[catId];
			this.weapon = GD.WEAPONS[this.cat.weapon];
			this.skill = GD.SKILLS[this.cat.skill];
			this.pos = { x: ARENA.cx, y: ARENA.cy };
			this.vel = { x: 0, y: 0 };
			this.moveSpeed = this.cat.moveSpeed * (1 + GS.amiiboPassiveValue('move_speed_pct'));
			this.facing = 1;
			this.dashing = false; this.dashT = 0; this.dashCd = 0;
			this.fireCd = 0; this.skillCd = 0; this.skillMult = 1; this.skillMultT = 0;
			this.invulnT = 0; this.alive = true;
			this.meleeSwingT = 0;
			this.bob = 0;
		}
		dashCooldownFrac() { return Math.max(0, this.dashCd / this.cat.dashCooldown); }
		skillCooldownFrac() { return Math.max(0, this.skillCd / this.skill.cooldown); }
		isInvuln() { return this.invulnT > 0; }

		update(dt) {
			if (!this.alive) return;
			this.dashCd = Math.max(0, this.dashCd - dt);
			this.skillCd = Math.max(0, this.skillCd - dt);
			this.fireCd = Math.max(0, this.fireCd - dt);
			this.invulnT = Math.max(0, this.invulnT - dt);
			if (this.skillMultT > 0) { this.skillMultT -= dt; if (this.skillMultT <= 0) this.skillMult = 1; }

			const mv = Input.moveVector();
			const aim = normalize({ x: Input.mouse.x - this.pos.x, y: Input.mouse.y - this.pos.y });
			this.aim = aim;
			if (Math.abs(aim.x) > 0.05) this.facing = aim.x < 0 ? -1 : 1;

			if (Input.anyJustPressed(['ShiftLeft', 'ShiftRight']) && this.dashCd <= 0 && !this.dashing) this.startDash(mv, aim);

			if (this.dashing) {
				this.dashT -= dt;
				if (this.dashT <= 0) this.dashing = false;
			} else {
				const target = { x: mv.x * this.moveSpeed * this.skillMult, y: mv.y * this.moveSpeed * this.skillMult };
				const accel = (mv.x || mv.y) ? this.cat.accel : this.cat.friction;
				this.vel.x = moveToward(this.vel.x, target.x, accel * dt);
				this.vel.y = moveToward(this.vel.y, target.y, accel * dt);
			}
			this.pos.x += this.vel.x * dt;
			this.pos.y += this.vel.y * dt;
			clampToArena(this.pos);
			this.bob += dt * (Math.hypot(this.vel.x, this.vel.y) > 5 ? 9 : 2.4);

			if (Input.mouse.down || Input.isDown('Space')) this.handleFire(dt, aim);
			if (Input.anyJustPressed(['KeyE']) && this.skillCd <= 0) this.useSkill(aim);
			if (this.meleeSwingT > 0) this.meleeSwingT -= dt;
		}

		startDash(mv, aim) {
			const dir = (mv.x || mv.y) ? normalize(mv) : aim;
			this.dashing = true; this.dashT = this.cat.dashTime; this.dashCd = this.cat.dashCooldown;
			this.invulnT = Math.max(this.invulnT, this.cat.dashIframes);
			this.vel = { x: dir.x * this.cat.dashSpeed, y: dir.y * this.cat.dashSpeed };
			AudioMgr.playSfx('dash', 1, 0.5);
		}

		handleFire(dt, aim) {
			if (this.fireCd > 0) return;
			this.fireCd = this.weapon.cooldown;
			switch (this.weapon.mode) {
				case 'rapid': this.fireProjectile(aim); break;
				case 'lob': this.fireLob(aim); break;
				case 'melee': this.fireMelee(); break;
			}
		}
		fireProjectile(aim) {
			const spread = (Math.random() * 2 - 1) * (this.weapon.spreadDeg * Math.PI / 180);
			const d = rotate(aim, spread);
			Bullets.push(new Bullet(this.pos.x + aim.x * 14, this.pos.y + aim.y * 14, d, this.weapon.speed,
				this.weapon.damage, true, 'player', this.weapon.pierce + GS.amiiboPassiveValue('pierce_add') + GS.buffPierceBonus(), this.weapon.range));
		}
		fireLob(aim) {
			const spread = (Math.random() * 2 - 1) * (this.weapon.spreadDeg * Math.PI / 180);
			const d = rotate(aim, spread);
			const b = new Bullet(this.pos.x + aim.x * 14, this.pos.y + aim.y * 14, d, this.weapon.speed, this.weapon.damage, true, 'lob', 0, this.weapon.range);
			b.lob = true; b.splash = this.weapon.splash;
			Bullets.push(b);
		}
		fireMelee() {
			this.meleeSwingT = 0.14;
			AudioMgr.playSfx('hit', 0.85, 0.35);
			const origin = { x: this.pos.x + this.aim.x * this.weapon.meleeRange * 0.5, y: this.pos.y + this.aim.y * this.weapon.meleeRange * 0.5 };
			Enemies.forEach((e) => {
				if (!e.alive) return;
				if (dist(origin, e.pos) <= this.weapon.meleeRange * 0.65) {
					const kdir = normalize({ x: e.pos.x - this.pos.x, y: e.pos.y - this.pos.y });
					e.takeHit(this.weapon.damage, kdir);
					e.knock(kdir, this.weapon.knockback);
				}
			});
		}
		useSkill(aim) {
			this.skillCd = this.skill.cooldown;
			AudioMgr.playSfx('skill', 1, 0.55);
			switch (this.skill.type) {
				case 'speed_burst': this.skillMult = this.skill.multiplier; this.skillMultT = this.skill.duration; break;
				case 'burst_fire': {
					const spread = this.skill.spreadDeg * Math.PI / 180;
					for (let i = 0; i < this.skill.count; i++) {
						const frac = (this.skill.count === 1) ? 0 : (i / (this.skill.count - 1)) - 0.5;
						const d = rotate(aim, frac * spread);
						const b = new Bullet(this.pos.x + aim.x * 14, this.pos.y + aim.y * 14, d, this.weapon.speed, this.skill.damage, true, 'lob', 0, this.weapon.range || 300);
						b.lob = true; b.splash = this.weapon.splash || 40;
						Bullets.push(b);
					}
					break;
				}
				case 'aoe_slam': {
					const cx = this.pos.x, cy = this.pos.y;
					Particles.push(new TelegraphFx(cx, cy, this.skill.radius, this.skill.windup, '#ffb35a'));
					setTimeout(() => {
						if (!this.alive) return;
						Enemies.forEach((e) => {
							if (!e.alive) return;
							if (dist({ x: cx, y: cy }, e.pos) <= this.skill.radius) {
								const kdir = normalize({ x: e.pos.x - cx, y: e.pos.y - cy });
								e.takeHit(this.skill.damage, kdir);
								e.knock(kdir, this.skill.knockback);
							}
						});
						AudioMgr.playSfx('hit', 0.6, 0.6);
					}, this.skill.windup * 1000);
					break;
				}
				case 'heal_pulse':
					GS.heal(this.skill.healHalfHearts);
					Particles.push(new PulseFx(this.pos.x, this.pos.y, this.skill.radius, '#ff9fae'));
					break;
			}
		}

		takeHit(halfHearts, dir) {
			if (!this.alive || this.isInvuln()) return;
			this.invulnT = 0.55;
			GS.takeDamage(halfHearts);
			this.vel.x += dir.x * 240 / this.cat.weight;
			this.vel.y += dir.y * 240 / this.cat.weight;
			AudioMgr.playSfx('player_hurt', 1, 0.5);
			ArenaScene.shake(3, 0.14);
			if (GS.run.heartsCurrent <= 0) {
				if (GS.hasBuff('second_wind') && !GS.run.secondWindUsed) {
					GS.run.secondWindUsed = true;
					GS.run.heartsCurrent = 2;
					GS.emit('heartsChanged', 2, GS.run.heartsMax);
					AudioMgr.playSfx('milestone');
					return;
				}
				this.die();
			}
		}
		die() {
			if (!this.alive) return;
			this.alive = false;
			AudioMgr.playSfx('death');
			ArenaScene.onPlayerDied();
		}
		render(ctx, t) {
			if (this.meleeSwingT > 0 && this.weapon.mode === 'melee') {
				ctx.save();
				ctx.strokeStyle = 'rgba(255,255,255,0.5)'; ctx.lineWidth = 4;
				ctx.beginPath();
				ctx.arc(this.pos.x, this.pos.y, this.weapon.meleeRange * 0.65, 0, Math.PI * 2);
				ctx.stroke();
				ctx.restore();
			}
			const palette = DrawCat.CAT_PALETTES[this.catId];
			ctx.save();
			if (this.facing < 0) { ctx.translate(this.pos.x * 2, 0); ctx.scale(-1, 1); }
			const flashA = this.invulnT > 0 ? (0.5 + 0.5 * Math.sin(t * 30)) : 0;
			ctx.globalAlpha = this.invulnT > 0 ? (0.55 + 0.35 * (1 - flashA)) : 1;
			DrawCat.drawCat(ctx, this.pos.x, this.pos.y, 1.55, palette, this.bob);
			ctx.restore();
		}
	}
	function moveToward(cur, target, maxDelta) {
		if (Math.abs(target - cur) <= maxDelta) return target;
		return cur + Math.sign(target - cur) * maxDelta;
	}
	function rotate(v, ang) { const c = Math.cos(ang), s = Math.sin(ang); return { x: v.x * c - v.y * s, y: v.x * s + v.y * c }; }

	// ============================================================= ENEMIES
	class Enemy {
		constructor(type, x, y, hpMult, speedMult, elite, bulletMult) {
			this.type = type;
			this.data = type === 'boss' ? GD.MINIBOSS : GD.ENEMIES[type];
			this.pos = { x, y };
			this.maxHp = Math.ceil(this.data.maxHp * hpMult);
			this.hp = this.maxHp;
			this.speed = this.data.speed * speedMult;
			this.elite = elite;
			this.bulletMult = bulletMult || 1;
			this.alive = true;
			this.flash = 0;
			this.knockVel = { x: 0, y: 0 };
			this.attackCd = type === 'spitter' ? Math.random() * this.data.attackCooldown : (type === 'boss' ? 1.5 : 0);
			this.telegraphing = false; this.telegraphT = 0;
			this.nextIsSlam = true;
			this.t = Math.random() * 10;
			this.scoreVal = this.data.score;
		}
		knock(dir, force) { this.knockVel.x += dir.x * force; this.knockVel.y += dir.y * force; }
		takeHit(dmg, dir) {
			if (!this.alive) return;
			this.hp -= dmg;
			this.flash = 1;
			this.knock(dir, 55);
			if (this.hp <= 0) this.die();
		}
		die() {
			if (!this.alive) return;
			this.alive = false;
			AudioMgr.playSfx('splat', 0.9 + Math.random() * 0.2, 0.5);
			ArenaScene.onEnemyDied(this);
		}
		update(dt, player) {
			if (!this.alive) return;
			this.t += dt;
			this.flash = Math.max(0, this.flash - dt * 6);
			this.knockVel.x = moveToward(this.knockVel.x, 0, 400 * dt);
			this.knockVel.y = moveToward(this.knockVel.y, 0, 400 * dt);
			let desired = { x: 0, y: 0 };
			const toPlayer = normalize({ x: player.pos.x - this.pos.x, y: player.pos.y - this.pos.y });
			const d = dist(this.pos, player.pos);

			if (this.type === 'grub' || this.type === 'mite') {
				desired = { x: toPlayer.x * this.speed, y: toPlayer.y * this.speed };
			} else if (this.type === 'spitter') {
				if (this.telegraphing) {
					this.telegraphT -= dt;
					if (this.telegraphT <= 0) this.fireSpitter(player);
				} else {
					if (d > this.data.attackRange) desired = { x: toPlayer.x * this.speed, y: toPlayer.y * this.speed };
					else if (d < this.data.attackRange * 0.5) desired = { x: -toPlayer.x * this.speed * 0.6, y: -toPlayer.y * this.speed * 0.6 };
					this.attackCd -= dt;
					if (this.attackCd <= 0 && d <= this.data.attackRange * 1.3) { this.telegraphing = true; this.telegraphT = this.data.telegraphTime; AudioMgr.playSfx('telegraph', 1, 0.25); }
				}
			} else if (this.type === 'boss') {
				if (this.telegraphing) {
					this.telegraphT -= dt;
					if (this.telegraphT <= 0) this.executeBossAttack(player);
				} else {
					if (d > 60) desired = { x: toPlayer.x * this.speed, y: toPlayer.y * this.speed };
					this.attackCd -= dt;
					if (this.attackCd <= 0) { this.telegraphing = true; this.telegraphT = this.data.slamTelegraph; AudioMgr.playSfx('telegraph', 0.7, 0.3); }
				}
			}
			this.pos.x += (desired.x + this.knockVel.x) * dt;
			this.pos.y += (desired.y + this.knockVel.y) * dt;
			clampToArena(this.pos);
			if (desired.x !== 0) this.facing = desired.x < 0 ? -1 : 1;
		}
		fireSpitter(player) {
			this.telegraphing = false;
			this.attackCd = this.data.attackCooldown;
			const dir = normalize({ x: player.pos.x - this.pos.x, y: player.pos.y - this.pos.y });
			Bullets.push(new Bullet(this.pos.x, this.pos.y, dir, this.data.bulletSpeed * this.bulletMult, this.data.bulletDamage, false, 'enemy', 0, 500));
		}
		executeBossAttack(player) {
			this.telegraphing = false;
			this.attackCd = this.data.slamCooldown;
			if (this.nextIsSlam) {
				if (dist(this.pos, player.pos) <= this.data.slamRadius) {
					const dir = normalize({ x: player.pos.x - this.pos.x, y: player.pos.y - this.pos.y });
					player.takeHit(this.data.slamDamage, dir);
				}
				AudioMgr.playSfx('hit', 0.6, 0.5);
			} else {
				for (let i = 0; i < this.data.ringCount; i++) {
					const ang = (Math.PI * 2 * i) / this.data.ringCount;
					const dir = { x: Math.cos(ang), y: Math.sin(ang) };
					Bullets.push(new Bullet(this.pos.x, this.pos.y, dir, this.data.ringSpeed * this.bulletMult, 1, false, 'enemy', 0, 480));
				}
			}
			this.nextIsSlam = !this.nextIsSlam;
		}
		render(ctx, t) {
			const scale = this.type === 'boss' ? 1.3 : 1.6;
			const telegraphFrac = this.telegraphing ? 1 - Math.max(0, this.telegraphT) / (this.type === 'boss' ? this.data.slamTelegraph : this.data.telegraphTime) : 0;
			if (this.type === 'spitter' && this.telegraphing) DrawFx.telegraphRing(ctx, this.pos.x, this.pos.y, 26, telegraphFrac, '#ff6060');
			switch (this.type) {
				case 'grub': DrawEnemies.grub(ctx, this.pos.x, this.pos.y, scale, this.t, this.flash); break;
				case 'spitter': DrawEnemies.spitter(ctx, this.pos.x, this.pos.y, scale, this.t, this.flash); break;
				case 'mite': DrawEnemies.mite(ctx, this.pos.x, this.pos.y, scale * 1.1, this.t, this.flash); break;
				case 'boss': DrawEnemies.trashGolem(ctx, this.pos.x, this.pos.y, scale, this.t, this.flash, this.nextIsSlam ? telegraphFrac : 0); break;
			}
			// hp bar for boss
			if (this.type === 'boss') {
				const w = 90;
				ctx.save();
				ctx.translate(this.pos.x - w / 2, this.pos.y - 66);
				ctx.fillStyle = 'rgba(0,0,0,0.5)'; ctx.fillRect(0, 0, w, 7);
				ctx.fillStyle = '#dc5a70'; ctx.fillRect(0, 0, w * Math.max(0, this.hp / this.maxHp), 7);
				ctx.strokeStyle = IsoUtils.OUTLINE; ctx.lineWidth = 1.5; ctx.strokeRect(0, 0, w, 7);
				ctx.restore();
			}
		}
	}

	// ============================================================== BULLET
	class Bullet {
		constructor(x, y, dir, speed, damage, fromPlayer, kind, pierce, range) {
			this.pos = { x, y }; this.dir = dir; this.speed = speed; this.damage = damage;
			this.fromPlayer = fromPlayer; this.kind = kind; this.pierce = pierce || 0;
			this.range = range || 300; this.traveled = 0; this.dead = false; this.lob = false; this.splash = 0;
			this.angle = Math.atan2(dir.y, dir.x);
		}
		update(dt) {
			const move = { x: this.dir.x * this.speed * dt, y: this.dir.y * this.speed * dt };
			this.pos.x += move.x; this.pos.y += move.y;
			this.traveled += Math.hypot(move.x, move.y);
			if (this.traveled >= this.range) {
				if (this.lob) this.detonate();
				this.dead = true;
				return;
			}
			if (!this.lob) {
				const targets = this.fromPlayer ? Enemies : [Player_ref];
				for (const target of targets) {
					if (!target || !target.alive) continue;
					const r = target === Player_ref ? 15 : (target.type === 'boss' ? 34 : (target.type === 'mite' ? 10 : 16));
					if (dist(this.pos, target.pos) <= r) {
						if (target === Player_ref) target.takeHit(this.damage, this.dir);
						else { target.takeHit(this.damage, this.dir); AudioMgr.playSfx('hit', 0.9 + Math.random() * 0.2, 0.3); }
						if (this.pierce > 0) this.pierce--; else this.dead = true;
						break;
					}
				}
			}
		}
		detonate() {
			const targets = this.fromPlayer ? Enemies : [Player_ref];
			targets.forEach((target) => {
				if (!target || !target.alive) return;
				if (dist(this.pos, target.pos) <= this.splash) {
					if (target === Player_ref) target.takeHit(this.damage, { x: 0, y: 0 });
					else target.takeHit(this.damage, { x: 0, y: 0 });
				}
			});
			AudioMgr.playSfx('hit', 0.75, 0.3);
			Particles.push(new SparkBurst(this.pos.x, this.pos.y, this.fromPlayer ? '#ffb35a' : '#c98cf0'));
		}
		render(ctx) {
			const scale = this.lob ? 1 + Math.sin(Math.min(1, this.traveled / this.range) * Math.PI) * 0.6 : 1;
			DrawFx.bullet(ctx, this.pos.x, this.pos.y, this.angle, this.kind, scale);
		}
	}

	// ------------------------------------------------------------ FX HELPERS
	class SparkBurst {
		constructor(x, y, color) { this.x = x; this.y = y; this.color = color; this.t = 0; this.dead = false; this.parts = Array.from({ length: 8 }, (_, i) => ({ a: (Math.PI * 2 * i) / 8, r: 0 })); }
		update(dt) { this.t += dt; this.parts.forEach((p) => (p.r += dt * 90)); if (this.t > 0.35) this.dead = true; }
		render(ctx) { const a = 1 - this.t / 0.35; this.parts.forEach((p) => DrawFx.spark(ctx, this.x + Math.cos(p.a) * p.r, this.y + Math.sin(p.a) * p.r, this.color, a)); }
	}
	class TelegraphFx {
		constructor(x, y, radius, duration, color) { this.x = x; this.y = y; this.radius = radius; this.duration = duration; this.t = 0; this.color = color; this.dead = false; }
		update(dt) { this.t += dt; if (this.t >= this.duration) this.dead = true; }
		render(ctx) { DrawFx.telegraphRing(ctx, this.x, this.y, this.radius, this.t / this.duration, this.color); }
	}
	class PulseFx {
		constructor(x, y, radius, color) { this.x = x; this.y = y; this.radius = radius; this.t = 0; this.color = color; this.dead = false; }
		update(dt) { this.t += dt * 3; if (this.t >= 1) this.dead = true; }
		render(ctx) { ctx.save(); ctx.globalAlpha = 1 - this.t; ctx.strokeStyle = this.color; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(this.x, this.y, this.radius * this.t, 0, Math.PI * 2); ctx.stroke(); ctx.restore(); }
	}
	class Splat {
		constructor(x, y, color) { this.x = x; this.y = y; this.color = color; this.seed = Math.floor(Math.random() * 9999); this.t = 0; this.dead = false; }
		update(dt) { this.t += dt; if (this.t > 3) this.dead = true; }
		render(ctx) { DrawFx.splat(ctx, this.x, this.y, this.color, Math.max(0, 1 - this.t / 3) * 0.8, this.seed, 26); }
	}
	class FishPickup {
		constructor(x, y, species, rarity) {
			this.pos = { x, y }; this.species = species; this.rarity = rarity; this.collected = false;
			this.bornT = 0; this.hopDone = false;
		}
		update(dt, player) {
			this.bornT += dt;
			const magnetR = 90 * (1 + GS.amiiboPassiveValue('pickup_radius_pct') + GS.buffPickupRangeBonus());
			const d = dist(this.pos, player.pos);
			if (d <= magnetR) {
				const speed = GD.lerp(90, 340, 1 - Math.min(1, d / magnetR));
				const dir = normalize({ x: player.pos.x - this.pos.x, y: player.pos.y - this.pos.y });
				this.pos.x += dir.x * speed * dt; this.pos.y += dir.y * speed * dt;
			}
			if (dist(this.pos, player.pos) <= 16) this.collect();
		}
		collect() {
			if (this.collected) return;
			this.collected = true;
			GS.addRunFish(this.species, this.rarity, 1);
			const sfx = this.rarity === 'Uncommon' ? 'pickup_uncommon' : (FD.rarityRank(this.rarity) >= 2 ? 'pickup_rare' : 'pickup_common');
			AudioMgr.playSfx(sfx, 1 + Math.random() * 0.1, 0.4);
		}
		render(ctx, t) {
			const bob = Math.sin(this.bornT * 6) * 2 - (this.bornT < 0.25 ? (0.25 - this.bornT) * 40 : 0);
			ctx.save();
			ctx.translate(this.pos.x, this.pos.y + bob);
			const color = FD.RARITY_COLOR[this.rarity];
			IsoUtils.radialGlow(ctx, 0, 0, 16, IsoUtils.rgba(color, 0.35), IsoUtils.rgba(color, 0));
			ctx.beginPath();
			ctx.moveTo(-7, 0); ctx.lineTo(3, -6); ctx.lineTo(8, 0); ctx.lineTo(3, 6); ctx.closePath();
			IsoUtils.fillStroke(ctx, color, IsoUtils.OUTLINE, 1.8);
			ctx.beginPath(); ctx.arc(4, -1.5, 1.3, 0, Math.PI * 2); ctx.fillStyle = '#20141a'; ctx.fill();
			ctx.restore();
		}
	}
	class AmiiboOrbiter {
		constructor(catId, offset) { this.catId = catId; this.offset = offset; this.t = 0; }
		update(dt) { this.t += dt * 1.4; }
		render(ctx, player) {
			const ang = this.t + this.offset;
			const x = player.pos.x + Math.cos(ang) * 34;
			const y = player.pos.y + Math.sin(ang) * 17 - 26;
			DrawCat.drawCatAmiiboIcon(ctx, x, y, 15, DrawCat.CAT_PALETTES[this.catId], this.t);
		}
	}

	// ============================================================ SCENE STATE
	let Enemies = [], Bullets = [], Pickups = [], Particles = [], Amiibos = [];
	let Player_ref = null;
	let stars = null;
	let camera = { x: 0, y: 0, shakeT: 0, shakeAmt: 0, rotation: 0 };
	let currentWave = 1;
	let waveActive = false, bossWave = false, breather = false, breatherT = 0;
	let quota = 0, spawnedThisWave = 0, spawnTimer = 0;
	let eliteHpMult = 1, eliteSpeedMult = 1;
	let runOver = false;
	let hudEls = {};

	function alliveEnemyCount() { return Enemies.filter((e) => e.alive).length; }

	function spawnPlayer() {
		Player_ref = new Player(GS.run.catId);
		Amiibos = GS.run.amiiboIds.map((id, i) => (id ? new AmiiboOrbiter(id, i * Math.PI) : null)).filter(Boolean);
	}

	function spawnOneEnemy() {
		const id = GD.rollEnemy(currentWave);
		const data = GD.ENEMIES[id];
		const count = data.packSize || 1;
		for (let i = 0; i < count; i++) spawnEnemyInstance(id);
		spawnedThisWave += count;
	}
	function spawnEnemyInstance(id) {
		const hpMult = GD.WaveDirector.enemyHpMult(currentWave) * eliteHpMult;
		const bulletMult = GD.WaveDirector.bulletSpeedMult(currentWave);
		const isElite = eliteHpMult > 1;
		const ang = Math.random() * Math.PI * 2;
		const x = ARENA.cx + Math.cos(ang) * ARENA.rx * 0.98;
		const y = ARENA.cy + Math.sin(ang) * ARENA.ry * 0.98;
		Enemies.push(new Enemy(id, x, y, hpMult, eliteSpeedMult, isElite, bulletMult));
	}

	function startWave(wave) {
		GS.run.wave = wave;
		currentWave = wave;
		updateWaveLabel();
		const milestone = GD.WaveDirector.milestoneInfo(wave);
		eliteHpMult = 1; eliteSpeedMult = 1;

		if (milestone && ['miniboss', 'midboss', 'planetboss'].includes(milestone.type)) {
			startBossWave(wave, milestone);
			return;
		}
		if (milestone && milestone.type === 'elite_wave') {
			eliteHpMult = milestone.hpMult; eliteSpeedMult = milestone.speedMult;
			showBanner(milestone.label, '#ff8f8f');
		}
		bossWave = false; waveActive = true;
		quota = GD.WaveDirector.enemyCountCap(wave) + 2;
		spawnedThisWave = 0; spawnTimer = 0.2;
	}

	function startBossWave(wave, milestone) {
		bossWave = true; waveActive = false;
		showBanner(milestone.label, '#ffb35a');
		AudioMgr.playSfx('milestone');
		const hpMult = GD.WaveDirector.enemyHpMult(wave);
		const bulletMult = GD.WaveDirector.bulletSpeedMult(wave);
		const bossCount = milestone.type === 'planetboss' ? 2 : 1;
		let remaining = bossCount;
		for (let i = 0; i < bossCount; i++) {
			const ang = (Math.PI * 2 * i) / bossCount;
			const e = new Enemy('boss', ARENA.cx + Math.cos(ang) * 60, ARENA.cy + Math.sin(ang) * 60, hpMult * (1 + 0.3 * i), 1, false, bulletMult);
			e._onDeathExtra = () => { remaining--; if (remaining <= 0) onBossDefeated(milestone); };
			Enemies.push(e);
		}
	}

	function onBossDefeated(milestone) {
		bossWave = false;
		AudioMgr.playSfx('wave_clear');
		if (milestone.checkpoint > 0) GS.reachCheckpoint(milestone.checkpoint);
		breather = true; breatherT = BREATHER_TIME;
		showBanner('Milestone cleared!', '#9ef29e', 1.6);
	}

	function onEnemyDied(enemy) {
		spawnFishDrop(enemy.pos, enemy.data.fishDrops, enemy.elite);
		Particles.push(new Splat(enemy.pos.x, enemy.pos.y, enemy.type === 'spitter' || enemy.type === 'mite' ? '#9660bd' : '#7fbf5a'));
		if (enemy._onDeathExtra) enemy._onDeathExtra();
	}

	function spawnFishDrop(pos, count, isElite) {
		for (let i = 0; i < count; i++) {
			const species = FD.rollSpecies(GS.PLANET_ID);
			const rarity = FD.rollRarity(isElite, GS.buffLuckyGut());
			Pickups.push(new FishPickup(pos.x + (Math.random() * 20 - 10), pos.y + (Math.random() * 20 - 10), species, rarity));
		}
	}

	function onWaveCleared() {
		waveActive = false;
		AudioMgr.playSfx('wave_clear');
		const milestone = GD.WaveDirector.milestoneInfo(currentWave);
		if (milestone && milestone.type === 'checkpoint_buff') { triggerCheckpointBuff(milestone); return; }
		breather = true; breatherT = BREATHER_TIME;
	}

	function triggerCheckpointBuff(milestone) {
		GS.reachCheckpoint(milestone.checkpoint);
		showMilestonePicker();
	}

	function advanceWave() {
		breather = false;
		currentWave += 1;
		if (currentWave > GD.WaveDirector.MAX_WAVE) { planetCleared(); return; }
		startWave(currentWave);
	}

	function planetCleared() {
		runOver = true;
		GS.data.planetProgress[GS.PLANET_ID].cleared = true;
		showBanner('LITTER PRIME CLEARED!', '#ffe38c', 4);
		GS.depositRunSatchelToVault();
		GS.endRun(false);
		setTimeout(() => Game.goto('house'), 3200);
	}

	function onPlayerDied() {
		runOver = true;
		const penalty = GS.applyDeathFishPenalty();
		GS.depositRunSatchelToVault();
		GS.endRun(true);
		showDeathSummary(currentWave, penalty);
	}

	// ---------------------------------------------------------------- HUD/UI
	function buildUI() {
		const wrap = Game.el('div', 'arena-ui');
		const hud = Game.el('div', 'hud', wrap);
		hudEls.hearts = Game.el('div', 'hud-hearts', hud);
		hudEls.wave = Game.el('div', 'hud-wave', hud);
		hudEls.satchel = Game.el('div', 'hud-satchel', hud);
		const bars = Game.el('div', 'hud-bars', wrap);
		hudEls.dashBar = Game.el('div', 'hud-bar dash', bars); hudEls.dashBar.innerHTML = '<div class="fill"></div>';
		hudEls.skillBar = Game.el('div', 'hud-bar skill', bars); hudEls.skillBar.innerHTML = '<div class="fill"></div>';
		hudEls.breather = Game.el('div', 'hud-breather', wrap);
		hudEls.banner = Game.el('div', 'hud-banner', wrap);
		hudEls.overlayRoot = wrap;
		GS.on('heartsChanged', renderHearts);
		renderHearts(GS.run.heartsCurrent, GS.run.heartsMax);
	}
	function renderHearts(cur, max) {
		hudEls.hearts.innerHTML = '';
		for (let i = 0; i < Math.ceil(max / 2); i++) {
			const remain = cur - i * 2;
			const span = document.createElement('span');
			span.className = 'heart ' + (remain >= 2 ? 'full' : remain === 1 ? 'half' : 'empty');
			span.textContent = '♥';
			hudEls.hearts.appendChild(span);
		}
	}
	function updateWaveLabel() { hudEls.wave.textContent = `Wave ${currentWave} / 100`; }
	function refreshSatchelHud() {
		const parts = [];
		Object.keys(GS.run.satchel).forEach((sp) => {
			let n = 0; Object.values(GS.run.satchel[sp]).forEach((v) => (n += v));
			if (n > 0) parts.push(`${FD.SPECIES[sp].name} x${n}`);
		});
		hudEls.satchel.textContent = parts.join('   ');
	}
	function showBanner(text, color, duration) {
		hudEls.banner.textContent = text;
		hudEls.banner.style.color = color || '#ffe38c';
		hudEls.banner.classList.remove('show'); void hudEls.banner.offsetWidth; hudEls.banner.classList.add('show');
		hudEls.banner.style.animationDuration = (duration || 2.2) + 's';
	}

	function showMilestonePicker() {
		Game.uiLayer.querySelectorAll('.overlay-panel').forEach((e) => e.remove());
		const dim = Game.el('div', 'overlay-dim overlay-panel');
		const panel = Game.el('div', 'panel', dim);
		Game.el('div', 'panel-title', panel).textContent = 'Checkpoint reached! Choose a buff:';
		const choices = GS.offerBuffChoices(3);
		choices.forEach((id) => {
			const b = GD.BUFF_POOL[id];
			const btn = Game.el('button', 'btn btn-buff', panel);
			btn.innerHTML = `<b>${b.name}</b><br><span>${b.desc}</span>`;
			btn.onclick = () => {
				AudioMgr.playSfx('ui_confirm');
				GS.applyBuff(id);
				dim.remove();
				breather = true; breatherT = BREATHER_TIME;
			};
		});
	}

	function showDeathSummary(wave, penalty) {
		Game.uiLayer.querySelectorAll('.overlay-panel').forEach((e) => e.remove());
		const dim = Game.el('div', 'overlay-dim overlay-panel');
		const panel = Game.el('div', 'panel', dim);
		Game.el('div', 'panel-title', panel).textContent = `You died on Wave ${wave}`;
		const sum = (d) => { let t = 0; Object.values(d).forEach((sp) => Object.values(sp).forEach((n) => (t += n))); return t; };
		const info = Game.el('div', 'panel-body', panel);
		info.innerHTML = `Lost ${Math.round(penalty.lossPct * 100)}% of your run satchel.<br>${sum(penalty.destroyed)} fish gone for good, ${sum(penalty.composted)} recoverable from the Compost Bin.<br>Kept ${penalty.keptTotal} fish for the vault.`;
		const row = Game.el('div', 'panel-buttons', panel);
		const retryBtn = Game.el('button', 'btn btn-primary', row);
		retryBtn.textContent = 'Retry from Checkpoint';
		retryBtn.onclick = () => { AudioMgr.playSfx('ui_confirm'); Game.goto('arena'); };
		const homeBtn = Game.el('button', 'btn', row);
		homeBtn.textContent = 'Return Home';
		homeBtn.onclick = () => { AudioMgr.playSfx('ui_confirm'); Game.goto('house'); };
	}

	function showPause() {
		Game.uiLayer.querySelectorAll('.overlay-panel').forEach((e) => e.remove());
		const dim = Game.el('div', 'overlay-dim overlay-panel');
		const panel = Game.el('div', 'panel', dim);
		Game.el('div', 'panel-title', panel).textContent = 'Paused';
		const resumeBtn = Game.el('button', 'btn btn-primary', panel);
		resumeBtn.textContent = 'Resume';
		resumeBtn.onclick = () => { dim.remove(); paused = false; };
		const label = Game.el('label', 'shake-toggle', panel);
		const cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = GS.data.settings.screenShake;
		cb.onchange = () => { GS.data.settings.screenShake = cb.checked; };
		label.appendChild(cb); label.appendChild(document.createTextNode(' Screen shake'));
		const quitBtn = Game.el('button', 'btn', panel);
		quitBtn.textContent = 'Quit to House';
		quitBtn.onclick = () => {
			if (!runOver) { GS.depositRunSatchelToVault(); GS.endRun(false); }
			Game.goto('house');
		};
	}

	let paused = false;

	// ================================================================ SCENE
	const ArenaScene = {
		shake(amount, duration) {
			if (!GS.data.settings.screenShake) return;
			camera.shakeT = Math.max(camera.shakeT, duration);
			camera.shakeAmt = Math.max(camera.shakeAmt, amount);
		},
		onEnemyDied, onPlayerDied,

		enter() {
			Enemies = []; Bullets = []; Pickups = []; Particles = []; Amiibos = [];
			runOver = false; paused = false;
			camera = { x: ARENA.cx, y: ARENA.cy, shakeT: 0, shakeAmt: 0, rotation: -9 * Math.PI / 180 };
			stars = DrawSpace.makeStars(60, Game.W, Game.H, 33);
			spawnPlayer();
			buildUI();
			updateWaveLabel();
			currentWave = GS.run.wave;
			AudioMgr.playMusic('combat');
			startWave(currentWave);
			// camera rotation tween entering arena
			const startRot = -9 * Math.PI / 180, endRot = 0;
			camera.rotation = startRot;
			const t0 = performance.now();
			const anim = () => {
				const p = Math.min(1, (performance.now() - t0) / 1500);
				camera.rotation = startRot + (endRot - startRot) * easeOutSine(p);
				if (p < 1 && Game.currentName === 'arena') requestAnimationFrame(anim);
			};
			requestAnimationFrame(anim);
		},

		update(dt, t) {
			if (Input.anyJustPressed(['Escape'])) {
				if (!paused && !runOver) { paused = true; showPause(); }
			}
			if (paused || runOver) return;

			Player_ref.update(dt);
			Enemies.forEach((e) => e.update(dt, Player_ref));
			Enemies = Enemies.filter((e) => e.alive);
			Bullets.forEach((b) => b.update(dt));
			Bullets = Bullets.filter((b) => !b.dead);
			Pickups.forEach((p) => p.update(dt, Player_ref));
			Pickups = Pickups.filter((p) => !p.collected);
			Particles.forEach((p) => p.update(dt));
			Particles = Particles.filter((p) => !p.dead);
			Amiibos.forEach((a) => a.update(dt));

			// camera follow
			const diff = { x: Player_ref.pos.x - camera.x, y: Player_ref.pos.y - camera.y };
			if (Math.hypot(diff.x, diff.y) > 2) { camera.x += diff.x * Math.min(1, dt * 4); camera.y += diff.y * Math.min(1, dt * 4); }
			if (camera.shakeT > 0) camera.shakeT -= dt; else camera.shakeAmt = 0;

			refreshSatchelHud();
			hudEls.dashBar.querySelector('.fill').style.width = `${(1 - Player_ref.dashCooldownFrac()) * 100}%`;
			hudEls.skillBar.querySelector('.fill').style.width = `${(1 - Player_ref.skillCooldownFrac()) * 100}%`;

			if (bossWave) { /* boss handles itself via update loop above */ }
			else if (waveActive) {
				spawnTimer -= dt;
				const cap = GD.WaveDirector.enemyCountCap(currentWave);
				if (spawnTimer <= 0 && spawnedThisWave < quota && alliveEnemyCount() < cap) {
					spawnOneEnemy();
					spawnTimer = GD.WaveDirector.spawnInterval(currentWave);
				}
				if (spawnedThisWave >= quota && alliveEnemyCount() === 0) onWaveCleared();
			} else if (breather) {
				breatherT -= dt;
				hudEls.breather.style.display = 'block';
				hudEls.breather.textContent = `Wave clear! Next wave in ${Math.ceil(breatherT)}...`;
				if (breatherT <= 0) { hudEls.breather.style.display = 'none'; advanceWave(); }
			}
		},

		render(ctx, t) {
			ctx.save();
			const shakeX = camera.shakeT > 0 ? (Math.random() * 2 - 1) * camera.shakeAmt : 0;
			const shakeY = camera.shakeT > 0 ? (Math.random() * 2 - 1) * camera.shakeAmt : 0;

			DrawArena.drawBackdrop(ctx, Game.W, Game.H, stars, t);

			ctx.save();
			ctx.translate(Game.W / 2 + shakeX, Game.H / 2 + shakeY);
			ctx.rotate(camera.rotation);
			ctx.translate(-Game.W / 2, -Game.H / 2);

			DrawArena.drawPlatform(ctx, ARENA.cx, ARENA.cy, ARENA.rx, ARENA.ry);

			Particles.filter((p) => p instanceof Splat).forEach((p) => p.render(ctx, t));
			Pickups.forEach((p) => p.render(ctx, t));

			const drawables = [Player_ref, ...Enemies].sort((a, b) => a.pos.y - b.pos.y);
			drawables.forEach((d) => d.render(ctx, t));
			Amiibos.forEach((a) => a.render(ctx, Player_ref));
			Bullets.forEach((b) => b.render(ctx));
			Particles.filter((p) => !(p instanceof Splat)).forEach((p) => p.render(ctx, t));

			ctx.restore();
			IsoUtils.vignette(ctx, Game.W, Game.H, 0.38);
			ctx.restore();
		},

		exit() {
			GS.listeners.heartsChanged = [];
		},
	};

	function easeOutSine(x) { return Math.sin((x * Math.PI) / 2); }

	Game.registerScene('arena', ArenaScene);
})(typeof window !== 'undefined' ? window : globalThis);
