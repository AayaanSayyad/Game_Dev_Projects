/* Scene: Start — title screen, separate from the House hub. */
(function (root) {
	'use strict';
	const Game = root.Game;

	let stars = null;

	const StartScene = {
		enter() {
			stars = DrawSpace.makeStars(110, Game.W, Game.H, 11);

			const wrap = Game.el('div', 'start-ui');
			const title = Game.el('div', 'game-title', wrap);
			title.innerHTML = 'Cataclysm<span>Orbit</span>';
			const sub = Game.el('div', 'game-subtitle', wrap);
			sub.textContent = 'a cozy bullet-hell on the outer rim';

			const playBtn = Game.el('button', 'btn btn-primary btn-play', wrap);
			playBtn.textContent = 'Play';
			playBtn.onclick = () => {
				AudioMgr.playSfx('ui_confirm', 1, 0.7);
				Game.goto('house');
			};

			const footer = Game.el('div', 'start-footer', wrap);
			const bestWave = GameState.data.planetProgress[GameState.PLANET_ID].bestWave;
			footer.textContent = bestWave > 0 ? `Best wave reached: ${bestWave} / 100` : 'A vertical-slice build — Litter Prime, waves 1–100';
		},
		update(dt, t) {},
		render(ctx, t) {
			DrawSpace.drawSky(ctx, Game.W, Game.H, '#140f28', '#4a3670');
			DrawSpace.drawStars(ctx, stars, t);
			DrawSpace.drawPlanet(ctx, Game.W * 0.74, Game.H * 0.22, 90, '#7a5ba6', '#e8c565');
			DrawSpace.drawPlanet(ctx, Game.W * 0.17, Game.H * 0.15, 28, '#c96b4f', null);

			// foreground litter-planet horizon
			ctx.fillStyle = '#241a3d';
			ctx.beginPath();
			ctx.moveTo(0, Game.H);
			ctx.lineTo(0, Game.H * 0.72);
			ctx.bezierCurveTo(Game.W * 0.16, Game.H * 0.64, Game.W * 0.25, Game.H * 0.78, Game.W * 0.39, Game.H * 0.69);
			ctx.bezierCurveTo(Game.W * 0.53, Game.H * 0.61, Game.W * 0.61, Game.H * 0.72, Game.W * 0.77, Game.H * 0.67);
			ctx.bezierCurveTo(Game.W * 0.88, Game.H * 0.63, Game.W * 0.94, Game.H * 0.69, Game.W, Game.H * 0.65);
			ctx.lineTo(Game.W, Game.H);
			ctx.closePath();
			ctx.fill();
			ctx.strokeStyle = '#1a1330'; ctx.lineWidth = 3; ctx.stroke();

			ctx.fillStyle = '#1c1533';
			[[0.12, 0.70, 30, 18], [0.34, 0.675, 22, 26], [0.67, 0.655, 26, 20], [0.85, 0.64, 20, 24]].forEach(([fx, fy, w, h]) => {
				ctx.fillRect(Game.W * fx - w / 2, Game.H * fy - h, w, h);
			});

			DrawCat.drawCat(ctx, Game.W / 2 + 30, Game.H * 0.755, 2.4, DrawCat.CAT_PALETTES.stray, t);
			IsoUtils.vignette(ctx, Game.W, Game.H, 0.3);
		},
		exit() {},
	};

	Game.registerScene('start', StartScene);
})(typeof window !== 'undefined' ? window : globalThis);
