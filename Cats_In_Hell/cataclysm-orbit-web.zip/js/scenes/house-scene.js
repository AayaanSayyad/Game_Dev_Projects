/* Scene: House — the hub. Loaded from the Start screen; not walkable (per
 * design doc recommendation #9) — hotspot buttons open panels instead.
 */
(function (root) {
	'use strict';
	const Game = root.Game, GS = root.GameState, GD = root.GameData, FD = root.FishData;

	let room = null;
	let selectedCat = 'stray';
	let selectedAmiibo = [null, null];
	let panelOverlay = null, noticeEl = null;

	function refreshTopInfo() {
		document.getElementById('exp-label').textContent = `EXP: ${GS.data.accountExp}`;
		document.getElementById('wave-label').textContent = `Best Wave: ${GS.data.planetProgress[GS.PLANET_ID].bestWave} / 100`;
		let total = 0;
		Object.values(GS.data.vaultFish).forEach((sp) => Object.values(sp).forEach((n) => (total += n)));
		document.getElementById('vault-label').textContent = `Vault Fish: ${total}`;
	}

	function showNotice(text) {
		noticeEl.textContent = text;
		noticeEl.classList.remove('show');
		void noticeEl.offsetWidth; // restart animation
		noticeEl.classList.add('show');
	}

	function announceUnlocks() {
		if (!GS.data.lastUnlocked.length) return;
		const names = GS.data.lastUnlocked.map((id) => GD.CATS[id].name);
		showNotice(`New cat recruited: ${names.join(', ')}!`);
		GS.data.lastUnlocked = [];
		GS.save();
	}

	function closeAll() { panelOverlay.classList.remove('open'); panelOverlay.innerHTML = ''; }

	function openPanel(title, buildFn) {
		AudioMgr.playSfx('ui_move', 1, 0.5);
		panelOverlay.innerHTML = '';
		panelOverlay.classList.add('open');
		const panel = Game.el('div', 'panel', panelOverlay);
		const h = Game.el('div', 'panel-title', panel);
		h.textContent = title;
		const body = Game.el('div', 'panel-body', panel);
		buildFn(body);
		const closeBtn = Game.el('button', 'btn btn-close', panel);
		closeBtn.textContent = 'Close';
		closeBtn.onclick = closeAll;
	}

	// ------------------------------------------------------------ LAUNCH PAD
	function openLoadout() {
		if (!GS.data.rosterUnlocked.includes(selectedCat)) selectedCat = GS.data.rosterUnlocked[0];
		selectedAmiibo = selectedAmiibo.map((id) => (id === selectedCat || (id && !GS.data.rosterUnlocked.includes(id)) ? null : id));
		openPanel('Launch Pad — choose your cat', (body) => {
			const catRow = Game.el('div', 'cat-select-row', body);
			renderCatSelect(catRow);
			const amiiboLabel = Game.el('div', 'panel-subhead', body);
			amiiboLabel.textContent = 'Amiibo slots (shrunk passives):';
			const amiiboRow = Game.el('div', 'cat-select-row', body);
			renderAmiiboSelect(amiiboRow);
			const cpLabel = Game.el('div', 'checkpoint-label', body);
			updateCheckpointLabel(cpLabel);
			const startBtn = Game.el('button', 'btn btn-primary', body);
			startBtn.textContent = 'Start Run';
			startBtn.onclick = () => {
				AudioMgr.playSfx('ui_confirm');
				GS.startRun(selectedCat, selectedAmiibo);
				Game.goto('arena');
			};
		});
	}

	function catCard(id, unlocked, selected, onClick) {
		const cat = GD.CATS[id];
		const card = document.createElement('button');
		card.className = 'cat-card' + (selected ? ' selected' : '') + (unlocked ? '' : ' locked');
		card.disabled = !unlocked;
		const cv = document.createElement('canvas');
		cv.width = 96; cv.height = 96;
		const cctx = cv.getContext('2d');
		if (unlocked) DrawCat.drawCat(cctx, 48, 76, 0.85, DrawCat.CAT_PALETTES[id], Game.t || 0);
		card.appendChild(cv);
		const label = document.createElement('div');
		label.textContent = unlocked ? cat.name : `${cat.name} (wave ${cat.unlockWave})`;
		card.appendChild(label);
		if (unlocked) card.onclick = onClick;
		return card;
	}

	function renderCatSelect(container) {
		container.innerHTML = '';
		Object.keys(GD.CATS).forEach((id) => {
			const unlocked = GS.data.rosterUnlocked.includes(id);
			container.appendChild(catCard(id, unlocked, id === selectedCat, () => {
				selectedCat = id;
				const idx = selectedAmiibo.indexOf(id);
				if (idx !== -1) selectedAmiibo[idx] = null;
				AudioMgr.playSfx('ui_move', 1, 0.4);
				renderCatSelect(container);
				const amiiboRow = container.parentElement.querySelectorAll('.cat-select-row')[1];
				if (amiiboRow) renderAmiiboSelect(amiiboRow);
				const cpLabel = container.parentElement.querySelector('.checkpoint-label');
				if (cpLabel) updateCheckpointLabel(cpLabel);
			}));
		});
	}

	function renderAmiiboSelect(container) {
		container.innerHTML = '';
		const cap = GS.amiiboSlotCap();
		Object.keys(GD.CATS).forEach((id) => {
			if (id === selectedCat) return;
			const unlocked = GS.data.rosterUnlocked.includes(id);
			const selected = selectedAmiibo.includes(id);
			const card = catCard(id, unlocked, selected, () => {
				const idx = selectedAmiibo.indexOf(id);
				if (idx !== -1) { selectedAmiibo[idx] = null; }
				else {
					const empty = selectedAmiibo.findIndex((v, i) => v === null && i < cap);
					if (empty === -1) { showNotice(`No free Amiibo slot (cap ${cap}).`); return; }
					selectedAmiibo[empty] = id;
				}
				AudioMgr.playSfx('ui_move', 1, 0.4);
				renderAmiiboSelect(container);
			});
			if (unlocked) {
				const desc = document.createElement('div');
				desc.className = 'amiibo-desc';
				desc.textContent = GD.CATS[id].amiibo.desc;
				card.appendChild(desc);
			}
			container.appendChild(card);
		});
	}

	function updateCheckpointLabel(el) {
		const cp = GS.checkpointWaveForPlanet();
		el.textContent = `Launching into Litter Prime at wave ${cp} (checkpoint).`;
		if (!GS.hasUpgrade('tent')) el.textContent += ' Build a Tent at the Blueprint Wall to enable checkpoints.';
	}

	// ------------------------------------------------------------------ ROSTER
	function openRoster() {
		openPanel('Roster Nest', (body) => {
			const list = Game.el('div', 'roster-list', body);
			Object.keys(GD.CATS).forEach((id) => {
				const cat = GD.CATS[id];
				const unlocked = GS.data.rosterUnlocked.includes(id);
				const row = Game.el('div', 'roster-row' + (unlocked ? '' : ' locked'), list);
				const cv = document.createElement('canvas'); cv.width = 64; cv.height = 64;
				if (unlocked) DrawCat.drawCat(cv.getContext('2d'), 32, 52, 0.55, DrawCat.CAT_PALETTES[id], Game.t || 0);
				row.appendChild(cv);
				const info = document.createElement('div');
				info.className = 'roster-info';
				info.innerHTML = unlocked
					? `<b>${cat.name}</b> (${cat.role}) — ${cat.starterGear}<br>HP ${cat.maxHp / 2} · Amiibo: ${cat.amiibo.desc}`
					: `<b>${cat.name}</b> — locked, unlocks at best wave ${cat.unlockWave}`;
				row.appendChild(info);
			});
		});
	}

	// ------------------------------------------------------------------- VAULT
	function openVault() {
		openPanel('Fish Vault', (body) => {
			const list = Game.el('div', 'vault-list', body);
			FD.activeSpeciesForPlanet(GS.PLANET_ID).forEach((species) => {
				const row = Game.el('div', 'vault-row', list);
				const name = document.createElement('span'); name.className = 'vault-species'; name.textContent = FD.SPECIES[species].name;
				row.appendChild(name);
				['Common', 'Uncommon', 'Rare'].forEach((r) => {
					const c = document.createElement('span');
					c.className = 'vault-count';
					c.style.color = FD.RARITY_COLOR[r];
					c.textContent = `${r}: ${GS.vaultCount(species, r)}`;
					row.appendChild(c);
				});
				if (GS.hasUpgrade('smoker')) {
					const btn = document.createElement('button');
					btn.className = 'btn btn-small';
					btn.textContent = 'Smoke 5→1';
					btn.disabled = GS.vaultCount(species, 'Common') < 5;
					btn.onclick = () => { if (GS.smokeConvert(species)) { AudioMgr.playSfx('purchase'); openVault(); } };
					row.appendChild(btn);
				}
			});
			const expRow = Game.el('div', 'vault-exp-row', body);
			const expLabel = document.createElement('span');
			expLabel.textContent = `Account EXP: ${GS.data.accountExp}`;
			expRow.appendChild(expLabel);
			const convertBtn = document.createElement('button');
			convertBtn.className = 'btn';
			convertBtn.textContent = 'Convert All to EXP';
			convertBtn.onclick = () => {
				const gained = GS.convertVaultToExp();
				if (gained > 0) { AudioMgr.playSfx('purchase'); showNotice(`Converted vault fish into ${gained} EXP.`); }
				refreshTopInfo();
				openVault();
			};
			expRow.appendChild(convertBtn);
		});
	}

	// --------------------------------------------------------------- BLUEPRINT
	function openBlueprint() {
		openPanel('Blueprint Wall', (body) => {
			const list = Game.el('div', 'blueprint-list', body);
			GD.TRACK_ORDER.forEach((track) => {
				const head = Game.el('div', 'panel-subhead', list);
				head.textContent = `— ${track} —`;
				Object.keys(GD.UPGRADES).forEach((id) => {
					const u = GD.UPGRADES[id];
					if (u.track !== track) return;
					const row = Game.el('div', 'upgrade-row', list);
					const top = Game.el('div', 'upgrade-top', row);
					const name = document.createElement('span'); name.className = 'upgrade-name'; name.textContent = u.name;
					top.appendChild(name);
					const cost = document.createElement('span'); cost.className = 'upgrade-cost';
					cost.textContent = u.cost.map((l) => `${l.amount}x ${l.rarity} ${FD.SPECIES[l.species].name}`).join(', ');
					top.appendChild(cost);
					const btn = document.createElement('button'); btn.className = 'btn btn-small';
					if (GS.hasUpgrade(id)) { btn.textContent = 'Owned'; btn.disabled = true; }
					else if (u.requires && !GS.hasUpgrade(u.requires)) { btn.textContent = `Needs ${GD.UPGRADES[u.requires].name}`; btn.disabled = true; }
					else {
						btn.textContent = 'Buy';
						btn.disabled = !GS.canAfford(id);
						btn.onclick = () => {
							if (GS.purchaseUpgrade(id)) {
								AudioMgr.playSfx('purchase');
								showNotice(`Built: ${u.name}`);
								refreshTopInfo();
								openBlueprint();
							}
						};
					}
					top.appendChild(btn);
					row.appendChild(top);
					const desc = Game.el('div', 'upgrade-desc', row);
					desc.textContent = u.desc;
				});
			});
		});
	}

	// ----------------------------------------------------------------- COMPOST
	function openCompost() {
		openPanel('Compost Bin', (body) => {
			const total = GS.compostPoolTotal();
			const label = Game.el('div', 'compost-label', body);
			label.textContent = `Recoverable fish in the Compost Bin: ${total}`;
			const btn = Game.el('button', 'btn btn-primary', body);
			btn.textContent = 'Claim';
			btn.disabled = total <= 0;
			btn.onclick = () => { GS.claimCompostPool(); AudioMgr.playSfx('purchase'); refreshTopInfo(); openCompost(); };
		});
	}

	// --------------------------------------------------------------------- SCENE
	const HouseScene = {
		enter() {
			room = DrawHouse.roomGeometry(Game.W / 2, 360, 900, 320, 340);

			const wrap = Game.el('div', 'house-ui');
			const topInfo = Game.el('div', 'top-info', wrap);
			topInfo.innerHTML = '<span id="exp-label"></span><span id="wave-label"></span><span id="vault-label"></span>';
			noticeEl = Game.el('div', 'notice-label', wrap);

			const hotspots = Game.el('div', 'hotspot-bar', wrap);
			[['Launch Pad', openLoadout], ['Roster Nest', openRoster], ['Fish Vault', openVault],
			['Blueprint Wall', openBlueprint], ['Compost Bin', openCompost]].forEach(([label, fn]) => {
				const btn = document.createElement('button');
				btn.className = 'btn hotspot-btn';
				btn.textContent = label;
				btn.onclick = fn;
				hotspots.appendChild(btn);
			});

			panelOverlay = Game.el('div', 'panel-overlay', wrap);

			refreshTopInfo();
			announceUnlocks();
			AudioMgr.playMusic('house');
		},
		update(dt, t) { Game.t = t; },
		render(ctx, t) {
			DrawHouse.drawBackdrop(ctx, Game.W, Game.H);
			DrawHouse.drawWalls(ctx, room);
			DrawHouse.drawWindow(ctx, room, t);
			DrawHouse.drawStringLights(ctx, { x: room.W.x, y: room.W.y - room.wallH }, { x: room.N.x, y: room.N.y - room.wallH }, t, 5);
			DrawHouse.drawStringLights(ctx, { x: room.N.x, y: room.N.y - room.wallH }, { x: room.E.x, y: room.E.y - room.wallH }, t, 5);
			DrawHouse.drawBookshelf(ctx, room.E.x - 90, room.E.y - 50);
			DrawHouse.drawFloor(ctx, room);
			DrawHouse.drawRug(ctx, Game.W / 2 - 15, 625);
			DrawHouse.drawPlant(ctx, Game.W / 2 - 350, 545, t);
			DrawHouse.drawCushion(ctx, Game.W / 2 + 300, 585, '#e0a0b0');
			DrawHouse.drawCrateStack(ctx, Game.W / 2 + 250, 630);
			DrawHouse.drawLamp(ctx, Game.W / 2 + 90, room.N.y - room.wallH, 0, t);
			DrawHouse.drawDustMotes(ctx, Game.W / 2, 380, 700, 350, t, 30);
			const catId = GS.data.rosterUnlocked[0] || 'stray';
			DrawCat.drawCat(ctx, Game.W / 2 - 20, 618, 2.9, DrawCat.CAT_PALETTES[selectedCat] || DrawCat.CAT_PALETTES[catId], t);
			IsoUtils.vignette(ctx, Game.W, Game.H, 0.35);
		},
		exit() {},
	};

	Game.registerScene('house', HouseScene);
})(typeof window !== 'undefined' ? window : globalThis);
