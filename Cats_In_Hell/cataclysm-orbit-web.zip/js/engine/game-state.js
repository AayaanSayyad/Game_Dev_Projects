/* GameState — persistent + run-time game state, saved to localStorage. */
(function (root) {
	'use strict';
	const FD = root.FishData, GD = root.GameData;
	const PLANET_ID = 'litter_prime';
	const SAVE_KEY = 'cataclysm_orbit_save_v1';

	function freshState() {
		const vault = {}; const compost = {};
		Object.keys(FD.SPECIES).forEach((id) => { vault[id] = {}; compost[id] = {}; });
		return {
			vaultFish: vault,
			accountExp: 0,
			houseUpgrades: [],
			rosterUnlocked: ['stray'],
			planetProgress: { litter_prime: { bestWave: 0, checkpoint: 0, cleared: false } },
			settings: { screenShake: true, musicOn: true, sfxOn: true },
			compostPool: compost,
			lastUnlocked: [],
		};
	}

	const S = {
		PLANET_ID,
		data: freshState(),
		// ---- run (transient) ----
		run: {
			active: false, satchel: {}, catId: 'stray', amiiboIds: [null, null],
			wave: 1, startWave: 1, heartsCurrent: 6, heartsMax: 6,
			activeBuffs: [], secondWindUsed: false,
		},
		listeners: {},

		on(evt, fn) { (this.listeners[evt] = this.listeners[evt] || []).push(fn); },
		emit(evt, ...args) { (this.listeners[evt] || []).forEach((fn) => fn(...args)); },

		load() {
			try {
				const raw = localStorage.getItem(SAVE_KEY);
				if (raw) {
					const parsed = JSON.parse(raw);
					this.data = Object.assign(freshState(), parsed);
					// merge nested defaults in case of schema growth
					this.data.settings = Object.assign(freshState().settings, parsed.settings || {});
				}
			} catch (e) { console.warn('GameState.load failed', e); }
		},
		save() {
			try { localStorage.setItem(SAVE_KEY, JSON.stringify(this.data)); } catch (e) { console.warn('GameState.save failed', e); }
		},

		// ------------------------------------------------------- VAULT / FISH
		addRunFish(species, rarity, amount) {
			amount = amount || 1;
			const s = (this.run.satchel[species] = this.run.satchel[species] || {});
			s[rarity] = (s[rarity] || 0) + amount;
		},
		runSatchelTotal() {
			let t = 0;
			Object.values(this.run.satchel).forEach((sp) => Object.values(sp).forEach((n) => (t += n)));
			return t;
		},
		depositRunSatchelToVault() {
			Object.keys(this.run.satchel).forEach((species) => {
				Object.keys(this.run.satchel[species]).forEach((r) => {
					const n = this.run.satchel[species][r];
					if (n <= 0) return;
					this.data.vaultFish[species] = this.data.vaultFish[species] || {};
					this.data.vaultFish[species][r] = (this.data.vaultFish[species][r] || 0) + n;
				});
			});
			this.run.satchel = {};
			this.emit('fishDeposited');
			this.save();
		},
		applyDeathFishPenalty() {
			let lossPct = this.hasUpgrade('fish_safe') ? 0.20 : 0.40;
			const kept = {}, destroyed = {}, composted = {};
			Object.keys(this.run.satchel).forEach((species) => {
				kept[species] = {};
				Object.keys(this.run.satchel[species]).forEach((r) => {
					const n = this.run.satchel[species][r];
					const lost = Math.floor(n * lossPct);
					const keep = n - lost;
					const destroyedN = Math.ceil(lost / 2);
					const compostedN = lost - destroyedN;
					kept[species][r] = keep;
					if (destroyedN > 0) { destroyed[species] = destroyed[species] || {}; destroyed[species][r] = destroyedN; }
					if (compostedN > 0) {
						composted[species] = composted[species] || {}; composted[species][r] = compostedN;
						this.data.compostPool[species] = this.data.compostPool[species] || {};
						this.data.compostPool[species][r] = (this.data.compostPool[species][r] || 0) + compostedN;
					}
				});
			});
			this.run.satchel = kept;
			return { lossPct, destroyed, composted, keptTotal: this.runSatchelTotal() };
		},
		compostPoolTotal() {
			let t = 0;
			Object.values(this.data.compostPool).forEach((sp) => Object.values(sp).forEach((n) => (t += n)));
			return t;
		},
		claimCompostPool() {
			Object.keys(this.data.compostPool).forEach((species) => {
				Object.keys(this.data.compostPool[species]).forEach((r) => {
					const n = this.data.compostPool[species][r];
					if (n <= 0) return;
					this.data.vaultFish[species] = this.data.vaultFish[species] || {};
					this.data.vaultFish[species][r] = (this.data.vaultFish[species][r] || 0) + n;
					this.data.compostPool[species][r] = 0;
				});
			});
			this.emit('fishDeposited');
			this.save();
		},
		vaultCount(species, rarity) { return (this.data.vaultFish[species] || {})[rarity] || 0; },
		convertVaultToExp() {
			let gained = 0;
			Object.keys(this.data.vaultFish).forEach((species) => {
				Object.keys(this.data.vaultFish[species]).forEach((r) => {
					const n = this.data.vaultFish[species][r];
					if (n <= 0) return;
					gained += Math.round(n * FD.SPECIES[species].baseExp * FD.rarityMult(r));
					this.data.vaultFish[species][r] = 0;
				});
			});
			this.data.accountExp += gained;
			this.save();
			return gained;
		},
		smokeConvert(species) {
			if (this.vaultCount(species, 'Common') < 5) return false;
			this.data.vaultFish[species].Common -= 5;
			this.data.vaultFish[species].Uncommon = (this.data.vaultFish[species].Uncommon || 0) + 1;
			this.save();
			return true;
		},

		// -------------------------------------------------------- UPGRADES
		hasUpgrade(id) { return this.data.houseUpgrades.includes(id); },
		canAfford(id) {
			const u = GD.UPGRADES[id];
			if (!u || this.hasUpgrade(id)) return false;
			if (u.requires && !this.hasUpgrade(u.requires)) return false;
			return u.cost.every((line) => this.vaultCount(line.species, line.rarity) >= line.amount);
		},
		purchaseUpgrade(id) {
			if (!this.canAfford(id)) return false;
			const u = GD.UPGRADES[id];
			u.cost.forEach((line) => { this.data.vaultFish[line.species][line.rarity] -= line.amount; });
			this.data.houseUpgrades.push(id);
			this.emit('upgradePurchased', id);
			this.save();
			return true;
		},
		checkpointWaveForPlanet() {
			if (!this.hasUpgrade('tent')) return 1;
			let cp = 1;
			if (this.hasUpgrade('shack')) cp = 10;
			if (this.hasUpgrade('cat_house')) cp = 50;
			return Math.max(cp, this.data.planetProgress[PLANET_ID].checkpoint || 1);
		},
		amiiboSlotCap() { return this.hasUpgrade('window_perch') ? 2 : 1; },

		// ---------------------------------------------------------- ROSTER
		checkRosterUnlocks(bestWave) {
			const newly = [];
			Object.keys(GD.CATS).forEach((id) => {
				if (bestWave >= GD.CATS[id].unlockWave && !this.data.rosterUnlocked.includes(id)) {
					this.data.rosterUnlocked.push(id);
					newly.push(id);
				}
			});
			if (newly.length) { this.data.lastUnlocked.push(...newly); this.save(); }
			return newly;
		},

		// --------------------------------------------------------------- RUN
		startRun(catId, amiiboIds) {
			this.run.catId = catId;
			this.run.amiiboIds = amiiboIds.slice();
			this.run.satchel = {};
			this.run.activeBuffs = [];
			this.run.secondWindUsed = false;
			const cat = GD.CATS[catId];
			let maxHp = cat.maxHp;
			this.run.amiiboIds.forEach((id) => {
				if (id && GD.CATS[id].amiibo.key === 'bonus_half_hearts') maxHp += GD.CATS[id].amiibo.value;
			});
			this.run.heartsMax = maxHp;
			this.run.heartsCurrent = maxHp;
			this.run.startWave = this.checkpointWaveForPlanet();
			this.run.wave = this.run.startWave;
			this.run.active = true;
		},
		endRun(died) {
			this.run.active = false;
			const pp = this.data.planetProgress[PLANET_ID];
			if (this.run.wave > pp.bestWave) pp.bestWave = this.run.wave;
			this.checkRosterUnlocks(pp.bestWave);
			this.save();
		},
		reachCheckpoint(wave) {
			const pp = this.data.planetProgress[PLANET_ID];
			if (wave > pp.checkpoint) pp.checkpoint = wave;
			if (wave > pp.bestWave) pp.bestWave = wave;
			this.checkRosterUnlocks(pp.bestWave);
			this.save();
		},
		amiiboPassiveValue(key) {
			let total = 0;
			this.run.amiiboIds.forEach((id) => {
				if (id && GD.CATS[id].amiibo.key === key) total += GD.CATS[id].amiibo.value;
			});
			return total;
		},
		takeDamage(halfHearts) {
			this.run.heartsCurrent = Math.max(0, this.run.heartsCurrent - halfHearts);
			this.emit('heartsChanged', this.run.heartsCurrent, this.run.heartsMax);
		},
		heal(halfHearts) {
			this.run.heartsCurrent = Math.min(this.run.heartsMax, this.run.heartsCurrent + halfHearts);
			this.emit('heartsChanged', this.run.heartsCurrent, this.run.heartsMax);
		},

		// --------------------------------------------------------------- BUFFS
		hasBuff(id) { return this.run.activeBuffs.includes(id); },
		offerBuffChoices(count) {
			const pool = Object.keys(GD.BUFF_POOL).filter((id) => !this.run.activeBuffs.includes(id));
			for (let i = pool.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1));[pool[i], pool[j]] = [pool[j], pool[i]]; }
			return pool.slice(0, count || 3);
		},
		applyBuff(id) {
			if (this.run.activeBuffs.includes(id)) return;
			this.run.activeBuffs.push(id);
			if (id === 'warm_milk') {
				this.run.heartsMax += 2;
				this.run.heartsCurrent = Math.min(this.run.heartsMax, this.run.heartsCurrent + 2);
				this.emit('heartsChanged', this.run.heartsCurrent, this.run.heartsMax);
			}
		},
		buffPickupRangeBonus() { return this.hasBuff('fish_magnet') ? 0.30 : 0; },
		buffPierceBonus() { return this.hasBuff('piercing_claws') ? 1 : 0; },
		buffLuckyGut() { return this.hasBuff('lucky_gut'); },
	};

	root.GameState = S;
})(typeof window !== 'undefined' ? window : globalThis);
