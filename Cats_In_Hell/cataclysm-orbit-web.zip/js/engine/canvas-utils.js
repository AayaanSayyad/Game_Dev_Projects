/* IsoUtils — shared vector-art drawing primitives.
 * Everything in this file is a pure function of (ctx, ...params) so it can
 * be exercised headlessly in Node (via the `canvas` package) for visual
 * iteration, and works unmodified in a real browser <canvas>.
 *
 * Art direction: flat-illustration / cozy-lofi isometric. Every shape gets
 * a bold, warm-dark outline; faces are lit with a consistent top-left key
 * light (top face brightest, left face mid, right face darkest).
 */
(function (root) {
	'use strict';

	const OUTLINE = '#2b1d33';

	// ---- color helpers -----------------------------------------------
	function hexToRgb(hex) {
		hex = hex.replace('#', '');
		if (hex.length === 3) hex = hex.split('').map((c) => c + c).join('');
		const num = parseInt(hex, 16);
		return { r: (num >> 16) & 255, g: (num >> 8) & 255, b: num & 255 };
	}
	function rgbToHex(r, g, b) {
		const c = (v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0');
		return '#' + c(r) + c(g) + c(b);
	}
	// percent: -1..1, negative darkens, positive lightens
	function shade(hex, percent) {
		const { r, g, b } = hexToRgb(hex);
		if (percent >= 0) {
			return rgbToHex(r + (255 - r) * percent, g + (255 - g) * percent, b + (255 - b) * percent);
		}
		const p = 1 + percent;
		return rgbToHex(r * p, g * p, b * p);
	}
	function rgba(hex, a) {
		const { r, g, b } = hexToRgb(hex);
		return `rgba(${r},${g},${b},${a})`;
	}

	// ---- generic path fill+stroke helper ------------------------------
	function fillStroke(ctx, fillColor, outline, lineWidth) {
		ctx.fillStyle = fillColor;
		ctx.fill();
		if (outline !== null && outline !== undefined) {
			ctx.strokeStyle = outline;
			ctx.lineWidth = lineWidth || 2.5;
			ctx.lineJoin = 'round';
			ctx.stroke();
		}
	}

	// ---- flat iso diamond (floor tile / rug) --------------------------
	// (x,y) = center of the diamond. w/d = full width/depth in px (2:1 ratio typical).
	function isoDiamond(ctx, x, y, w, d, fillColor, outline, lineWidth) {
		ctx.beginPath();
		ctx.moveTo(x, y - d / 2);
		ctx.lineTo(x + w / 2, y);
		ctx.lineTo(x, y + d / 2);
		ctx.lineTo(x - w / 2, y);
		ctx.closePath();
		fillStroke(ctx, fillColor, outline === undefined ? OUTLINE : outline, lineWidth);
	}

	// ---- iso cuboid (the core "furniture block" primitive) -----------
	// (x,y) = screen position of the SOUTH vertex of the top face (the
	// nearest point of the top diamond to the viewer, i.e. where the box
	// "starts" at floor level before it rises). w/d = top-face full
	// width/depth in px, h = vertical height in px.
	function isoCube(ctx, x, y, w, d, h, baseColor, opts) {
		opts = opts || {};
		const outline = opts.outline === undefined ? OUTLINE : opts.outline;
		const lw = opts.lineWidth || 2.5;
		const topColor = opts.top || shade(baseColor, 0.18);
		const leftColor = opts.left || shade(baseColor, -0.08);
		const rightColor = opts.right || shade(baseColor, -0.30);

		const N = { x: x, y: y - d };
		const E = { x: x + w / 2, y: y - d / 2 };
		const S = { x: x, y: y };
		const W = { x: x - w / 2, y: y - d / 2 };

		// left face (S,W,W+h,S+h)
		ctx.beginPath();
		ctx.moveTo(W.x, W.y);
		ctx.lineTo(S.x, S.y);
		ctx.lineTo(S.x, S.y + h);
		ctx.lineTo(W.x, W.y + h);
		ctx.closePath();
		fillStroke(ctx, leftColor, outline, lw);

		// right face (S,E,E+h,S+h)
		ctx.beginPath();
		ctx.moveTo(S.x, S.y);
		ctx.lineTo(E.x, E.y);
		ctx.lineTo(E.x, E.y + h);
		ctx.lineTo(S.x, S.y + h);
		ctx.closePath();
		fillStroke(ctx, rightColor, outline, lw);

		// top face (N,E,S,W)
		ctx.beginPath();
		ctx.moveTo(N.x, N.y);
		ctx.lineTo(E.x, E.y);
		ctx.lineTo(S.x, S.y);
		ctx.lineTo(W.x, W.y);
		ctx.closePath();
		fillStroke(ctx, topColor, outline, lw);

		return { N, E, S, W };
	}

	// ---- soft drop shadow ellipse (grounds floating/character sprites) --
	function softShadow(ctx, x, y, rx, ry, alpha) {
		ctx.save();
		ctx.beginPath();
		ctx.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2);
		ctx.fillStyle = `rgba(20,10,25,${alpha === undefined ? 0.28 : alpha})`;
		ctx.fill();
		ctx.restore();
	}

	// ---- soft radial glow (lamps, windows, magic) ---------------------
	function radialGlow(ctx, x, y, radius, innerColor, outerAlphaColor) {
		const g = ctx.createRadialGradient(x, y, 0, x, y, radius);
		g.addColorStop(0, innerColor);
		g.addColorStop(1, outerAlphaColor || 'rgba(0,0,0,0)');
		ctx.save();
		ctx.fillStyle = g;
		ctx.beginPath();
		ctx.arc(x, y, radius, 0, Math.PI * 2);
		ctx.fill();
		ctx.restore();
	}

	// ---- rounded rect (UI panels, cards) -------------------------------
	function roundedRectPath(ctx, x, y, w, h, r) {
		if (typeof r === 'number') r = { tl: r, tr: r, br: r, bl: r };
		ctx.beginPath();
		ctx.moveTo(x + r.tl, y);
		ctx.lineTo(x + w - r.tr, y);
		ctx.arcTo(x + w, y, x + w, y + r.tr, r.tr);
		ctx.lineTo(x + w, y + h - r.br);
		ctx.arcTo(x + w, y + h, x + w - r.br, y + h, r.br);
		ctx.lineTo(x + r.bl, y + h);
		ctx.arcTo(x, y + h, x, y + h - r.bl, r.bl);
		ctx.lineTo(x, y + r.tl);
		ctx.arcTo(x, y, x + r.tl, y, r.tl);
		ctx.closePath();
	}

	// ---- generic blob (organic leaf/cloud/cat-body shapes) via bezier --
	// pts: array of {x,y} control anchor points forming a closed loose loop.
	function blob(ctx, cx, cy, points) {
		ctx.beginPath();
		const pts = points.map((p) => ({ x: cx + p.x, y: cy + p.y }));
		ctx.moveTo((pts[0].x + pts[pts.length - 1].x) / 2, (pts[0].y + pts[pts.length - 1].y) / 2);
		for (let i = 0; i < pts.length; i++) {
			const p0 = pts[i];
			const p1 = pts[(i + 1) % pts.length];
			const mx = (p0.x + p1.x) / 2;
			const my = (p0.y + p1.y) / 2;
			ctx.quadraticCurveTo(p0.x, p0.y, mx, my);
		}
		ctx.closePath();
	}

	// ---- vignette (subtle atmospheric frame darkening) -----------------
	function vignette(ctx, w, h, strength) {
		const g = ctx.createRadialGradient(w / 2, h * 0.55, h * 0.25, w / 2, h * 0.55, h * 0.75);
		g.addColorStop(0, 'rgba(0,0,0,0)');
		g.addColorStop(1, `rgba(10,5,20,${strength === undefined ? 0.35 : strength})`);
		ctx.save();
		ctx.fillStyle = g;
		ctx.fillRect(0, 0, w, h);
		ctx.restore();
	}

	root.IsoUtils = {
		OUTLINE, shade, rgba, hexToRgb, rgbToHex,
		fillStroke, isoDiamond, isoCube, softShadow, radialGlow,
		roundedRectPath, blob, vignette,
	};
})(typeof window !== 'undefined' ? window : globalThis);
