/* Game — scene manager + main requestAnimationFrame loop. */
(function (root) {
	'use strict';

	const Game = {
		canvas: null, ctx: null, W: 1280, H: 720,
		scenes: {},
		current: null,
		currentName: null,
		lastTime: 0,
		t: 0,
		uiLayer: null,

		registerScene(name, scene) { this.scenes[name] = scene; },

		init() {
			this.canvas = document.getElementById('game-canvas');
			this.canvas.width = this.W;
			this.canvas.height = this.H;
			this.ctx = this.canvas.getContext('2d');
			this.uiLayer = document.getElementById('ui-layer');
			this.resize();
			window.addEventListener('resize', () => this.resize());
			Input.bind(this.canvas);
			AudioMgr.init();
			GameState.load();
			this.goto('start');
			requestAnimationFrame((ts) => this.loop(ts));
		},

		resize() {
			const viewport = document.getElementById('viewport');
			const targetAspect = this.W / this.H;
			const winW = window.innerWidth, winH = window.innerHeight;
			let w = winW, h = winW / targetAspect;
			if (h > winH) { h = winH; w = winH * targetAspect; }
			viewport.style.width = Math.floor(w) + 'px';
			viewport.style.height = Math.floor(h) + 'px';
		},

		goto(name, ...args) {
			if (this.current && this.current.exit) this.current.exit();
			this.uiLayer.innerHTML = '';
			this.currentName = name;
			this.current = this.scenes[name];
			if (this.current && this.current.enter) this.current.enter(...args);
		},

		loop(now) {
			const dt = Math.min(0.05, (now - this.lastTime) / 1000 || 0);
			this.lastTime = now;
			this.t += dt;
			if (this.current && this.current.update) this.current.update(dt, this.t);
			this.ctx.clearRect(0, 0, this.W, this.H);
			if (this.current && this.current.render) this.current.render(this.ctx, this.t);
			Input.endFrame();
			requestAnimationFrame((ts) => this.loop(ts));
		},

		// helper for scenes: create a DOM element inside the UI layer
		el(tag, className, parent) {
			const e = document.createElement(tag);
			if (className) e.className = className;
			(parent || this.uiLayer).appendChild(e);
			return e;
		},
	};

	root.Game = Game;
})(typeof window !== 'undefined' ? window : globalThis);
