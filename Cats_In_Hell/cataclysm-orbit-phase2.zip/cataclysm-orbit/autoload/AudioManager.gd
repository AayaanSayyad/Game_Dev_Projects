extends Node

var muted := false

func play_sfx(_id: String) -> void:
    # Audio hooks are centralized here so real WAV/OGG assets can be added later
    # without changing gameplay scripts.
    pass
