extends Node

const MAX_BULLETS := 120
var active: Array[Node] = []

func _process(_delta: float) -> void:
    active=active.filter(func(b): return is_instance_valid(b) and b.active)

func register_bullet(bullet: Node) -> void:
    if bullet not in active:
        active.append(bullet)

func unregister_bullet(bullet: Node) -> void:
    active.erase(bullet)

func can_spawn() -> bool:
    active=active.filter(func(b): return is_instance_valid(b) and b.active)
    return active.size() < MAX_BULLETS

func clear_all() -> void:
    for bullet in active.duplicate():
        if is_instance_valid(bullet): bullet.deactivate()
    active.clear()
