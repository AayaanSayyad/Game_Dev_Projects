extends Node

const RARITIES := ["Common", "Uncommon", "Rare", "Epic", "Legendary"]
const RARITY_MULT := {"Common":1.0, "Uncommon":1.8, "Rare":3.5, "Epic":7.0, "Legendary":15.0}
const SPECIES := {
    "sardine_rotten": {"name":"Sardine", "base_exp":5, "planets":["litter_prime"]},
    "mackerel_foul": {"name":"Mackerel", "base_exp":8, "planets":["litter_prime"]},
    "tuna_mold": {"name":"Tuna", "base_exp":12, "planets":["litter_prime"]},
    "salmon_sour": {"name":"Salmon", "base_exp":18, "planets":["litter_prime"]},
    "herring_haunt": {"name":"Herring", "base_exp":21, "planets":["litter_prime"]},
    "squid_inked": {"name":"Squid", "base_exp":28, "planets":["litter_prime"]}
}

func get_species_ids() -> Array:
    return SPECIES.keys()

func get_species_name(id: String) -> String:
    return str(SPECIES.get(id, {"name":id}).get("name", id))

func empty_bag() -> Dictionary:
    var bag := {}
    for id in SPECIES.keys():
        bag[id] = {}
        for rarity in RARITIES:
            bag[id][rarity] = 0
    return bag

func rarity_roll(elite: bool = false, luck: float = 0.0) -> String:
    var weights := {"Common":70.0, "Uncommon":22.0, "Rare":6.0, "Epic":1.8, "Legendary":0.2}
    if elite:
        weights = {"Common":40.0, "Uncommon":35.0, "Rare":18.0, "Epic":5.0, "Legendary":2.0}
    weights["Rare"] += luck * 100.0 * 0.50
    weights["Epic"] += luck * 100.0 * 0.25
    weights["Legendary"] += luck * 100.0 * 0.05
    var total := 0.0
    for v in weights.values(): total += float(v)
    var roll := randf() * total
    var cumulative := 0.0
    for rarity in RARITIES:
        cumulative += float(weights[rarity])
        if roll <= cumulative:
            return rarity
    return "Common"

func species_roll(wave: int = 1) -> String:
    var pool := ["sardine_rotten", "sardine_rotten", "mackerel_foul", "tuna_mold"]
    if wave >= 20: pool.append("salmon_sour")
    if wave >= 35: pool.append("herring_haunt")
    if wave >= 60: pool.append("squid_inked")
    return str(pool[randi_range(0, pool.size() - 1)])

func fish_exp(species_id: String, rarity: String) -> int:
    var base := float(SPECIES.get(species_id, {"base_exp":5}).get("base_exp",5))
    return int(round(base * float(RARITY_MULT.get(rarity,1.0))))
