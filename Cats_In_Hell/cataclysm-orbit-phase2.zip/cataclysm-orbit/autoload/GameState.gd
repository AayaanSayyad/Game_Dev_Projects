extends Node

signal state_changed

const SAVE_VERSION := 2

var vault_fish: Dictionary = {}
var account_exp := 0
var house_upgrades: Array[String] = []
var roster_unlocked: Array[String] = ["stray"]
var gear_owned: Array = []
var equipped: Dictionary = {}
var best_wave := 0
var checkpoint_wave := 0
var planet_cleared := false
var settings := {"screen_shake":true, "aim_mode":"mouse"}
var resume_buffs: Array[String] = []
var resume_fish: Dictionary = {}
var resume_available := false
var run_fish: Dictionary = {}
var run_buffs: Array[String] = []
var active_cat_id := "stray"
var amiibo_slots: Array[String] = ["", ""]
var current_wave := 1
var current_planet := "litter_prime"
var last_run_result: Dictionary = {}
var run_uses_checkpoint := false

func _ready() -> void:
    vault_fish = FishDatabase.empty_bag()
    call_deferred("_finish_ready")

func _finish_ready() -> void:
    SaveManager.load_state()
    ensure_cat_gear()
    state_changed.emit()

func ensure_cat_gear() -> void:
    for cat_id in roster_unlocked:
        var starter := GearDatabase.starter_for_cat(cat_id)
        if not equipped.has(cat_id):
            if not owns_gear(starter): gear_owned.append(starter)
            equipped[cat_id] = {"weapon":starter, "armor":"", "trinket":""}

func _ensure_fish(species: String) -> void:
    if not vault_fish.has(species):
        vault_fish[species] = {}
    for rarity in FishDatabase.RARITIES:
        if not vault_fish[species].has(rarity):
            vault_fish[species][rarity] = 0

func reset_run() -> void:
    run_fish = FishDatabase.empty_bag()
    run_buffs = []

func add_run_fish(species: String, rarity: String, amount: int = 1) -> void:
    if not run_fish.has(species): run_fish[species] = {}
    if not run_fish[species].has(rarity): run_fish[species][rarity] = 0
    run_fish[species][rarity] += amount
    state_changed.emit()

func run_fish_total() -> int:
    var total := 0
    for species in run_fish.values():
        for count in species.values(): total += int(count)
    return total

func add_vault_fish(species: String, rarity: String, amount: int = 1) -> void:
    _ensure_fish(species)
    vault_fish[species][rarity] += amount

func _clone_bag(source: Dictionary) -> Dictionary:
    var out := {}
    for species in source.keys():
        out[species] = {}
        for rarity in source[species].keys(): out[species][rarity] = int(source[species][rarity])
    return out

func _keep_run_fraction(fraction: float) -> Dictionary:
    var total := run_fish_total()
    var target := int(floor(float(total) * fraction))
    var kept := 0
    var kept_bag := FishDatabase.empty_bag()
    for species in run_fish.keys():
        for rarity in run_fish[species].keys():
            var available := int(run_fish[species][rarity])
            var take := min(available, max(0, target - kept))
            if take > 0:
                kept_bag[species][rarity] = take
                kept += take
    return {"bag":kept_bag, "kept":kept, "lost":total-kept}

func deposit_run_fish(loss_fraction: float = 0.0) -> Dictionary:
    var result := _keep_run_fraction(1.0 - loss_fraction)
    for species in result.bag.keys():
        for rarity in result.bag[species].keys():
            var take := int(result.bag[species][rarity])
            if take > 0:
                add_vault_fish(species, rarity, take)
                account_exp += FishDatabase.fish_exp(species, rarity) * take
    run_fish = FishDatabase.empty_bag()
    run_buffs = []
    return result

func die_and_return_home() -> Dictionary:
    var total := run_fish_total()
    var total_loss_fraction:=0.32 if has_house_upgrade("fish_safe") else 0.40
    var recoverable_fraction:=0.20 if has_house_upgrade("compost") else 0.0
    var destroyed_fraction:=total_loss_fraction-recoverable_fraction
    if destroyed_fraction<0.0: destroyed_fraction=0.0
    var destroyed_target:=int(floor(float(total)*destroyed_fraction))
    var recoverable_target:=int(floor(float(total)*recoverable_fraction))
    var kept_target:=total-destroyed_target-recoverable_target
    var ordered: Array = []
    for species in run_fish.keys():
        for rarity in run_fish[species].keys():
            var amount := int(run_fish[species][rarity])
            if amount > 0: ordered.append({"species":species, "rarity":rarity, "amount":amount})
    var keep_count := 0
    var recover_count := 0
    var recovered_bag := FishDatabase.empty_bag()
    for entry in ordered:
        var take_keep := min(int(entry["amount"]), max(0, kept_target - keep_count))
        if take_keep > 0:
            add_vault_fish(entry["species"], entry["rarity"], take_keep)
            account_exp += FishDatabase.fish_exp(entry["species"], entry["rarity"]) * take_keep
            keep_count += take_keep
            entry["amount"] -= take_keep
        var take_recover := min(int(entry["amount"]), max(0, recoverable_target - recover_count))
        if take_recover > 0:
            recovered_bag[entry["species"]][entry["rarity"]] += take_recover
            add_vault_fish(entry["species"],entry["rarity"],take_recover)
            account_exp += FishDatabase.fish_exp(entry["species"],entry["rarity"]) * take_recover
            recover_count += take_recover
            entry["amount"] -= take_recover
    run_fish = FishDatabase.empty_bag()
    if run_uses_checkpoint:
        resume_available=false
        resume_fish=FishDatabase.empty_bag()
    var gear_result := lose_equipped_gear(active_cat_id)
    current_wave = checkpoint_wave + 1 if checkpoint_wave > 0 else 1
    run_buffs = resume_buffs.duplicate()
    resume_available=false
    resume_fish=FishDatabase.empty_bag()
    last_run_result = {
        "fish_total":total,
        "fish_kept":keep_count,
        "fish_recovered":recover_count,
        "fish_destroyed":total-keep_count-recover_count,
        "recovered_bag":recovered_bag,
        "gear_lost":gear_result
    }
    SaveManager.save_state()
    state_changed.emit()
    return last_run_result

func add_buff(buff_id: String) -> void:
    if buff_id not in run_buffs: run_buffs.append(buff_id)

func has_buff(buff_id: String) -> bool:
    return buff_id in run_buffs

func checkpoint_reached(wave: int) -> void:
    if wave == 10 or wave == 50:
        checkpoint_wave = max(checkpoint_wave, wave)
        resume_buffs = run_buffs.duplicate()
        resume_fish = _clone_bag(run_fish)
        resume_available=true
        best_wave = max(best_wave, wave)
        SaveManager.save_state()
        state_changed.emit()

func start_run(start_wave: int = 1, use_checkpoint_state: bool = false) -> void:
    run_fish=FishDatabase.empty_bag()
    if start_wave>1:
        run_buffs=resume_buffs.duplicate()
        if use_checkpoint_state and resume_available:
            run_fish=_clone_bag(resume_fish)
    else:
        run_buffs=[]
    current_wave=max(1,start_wave)
    run_uses_checkpoint=use_checkpoint_state and start_wave>1 and resume_available
    ensure_cat_gear()

func owns_gear(id: String) -> bool:
    return id in gear_owned

func get_equipped(cat_id: String) -> Dictionary:
    if not equipped.has(cat_id): equipped[cat_id] = {"weapon":GearDatabase.starter_for_cat(cat_id),"armor":"","trinket":""}
    return equipped[cat_id]

func equip(cat_id: String, slot: String, gear_id: String) -> bool:
    if not owns_gear(gear_id): return false
    var data := GearDatabase.get(gear_id)
    if str(data.get("slot","")) != slot: return false
    var loadout := get_equipped(cat_id)
    loadout[slot] = gear_id
    equipped[cat_id] = loadout
    SaveManager.save_state()
    return true

func can_afford(cost: Dictionary) -> bool:
    for species in cost.keys():
        _ensure_fish(species)
        for rarity in cost[species].keys():
            if int(vault_fish[species].get(rarity,0)) < int(cost[species][rarity]): return false
    return true

func pay_cost(cost: Dictionary) -> void:
    for species in cost.keys():
        _ensure_fish(species)
        for rarity in cost[species].keys(): vault_fish[species][rarity] -= int(cost[species][rarity])

func has_house_upgrade(id: String) -> bool:
    return id in house_upgrades

func purchase_upgrade(id: String) -> bool:
    if has_house_upgrade(id): return false
    var upgrade := HouseUpgradeDatabase.get_upgrade(id)
    if upgrade.is_empty() or not can_afford(upgrade.get("cost",{})): return false
    for requirement in upgrade.get("requires",[]):
        if not has_house_upgrade(requirement): return false
    pay_cost(upgrade.cost)
    house_upgrades.append(id)
    SaveManager.save_state()
    state_changed.emit()
    return true

func unlock_cat(id: String) -> bool:
    if id in roster_unlocked: return false
    roster_unlocked.append(id)
    ensure_cat_gear()
    SaveManager.save_state()
    state_changed.emit()
    return true

func lose_equipped_gear(cat_id: String) -> Array:
    var lost: Array = []
    var insurance := 0.10 if has_house_upgrade("insurance") else 0.0
    var soot_amiibo := "soot" in amiibo_slots
    if soot_amiibo: insurance += 0.10
    var cat_loadout: Array = [cat_id]
    for equipped_cat_id in cat_loadout:
        var loadout := equipped.get(equipped_cat_id,{"weapon":"","armor":"","trinket":""})
        for slot in ["weapon","armor","trinket"]:
            var gear_id := str(loadout.get(slot,""))
            if gear_id == "": continue
            var data := GearDatabase.get(gear_id)
            var chance := 0.15 + (0.05 if str(data.get("rarity","Common")) == "Epic" else 0.0)
            chance = max(0.0, chance - insurance)
            if randf() < chance:
                lost.append(gear_id)
                gear_owned.erase(gear_id)
                loadout[slot] = ""
        equipped[equipped_cat_id] = loadout
    ensure_cat_gear()
    return lost
