extends Node

const WAVE_MAX := 100

func spawn_rate(wave: int) -> float:
    return lerp(2.5, 0.6, float(wave) / 100.0)

func enemy_hp_mult(wave: int) -> float:
    return 1.0 + wave * 0.04

func bullet_speed_mult(wave: int) -> float:
    return 1.0 + wave * 0.003

func enemy_count_cap(wave: int) -> int:
    return min(8 + floori(float(wave) / 5.0), 24)

func spawn_budget(wave: int) -> int:
    if wave in [25, 50, 100]:
        return 0
    return 4 + floori(float(wave) * 0.55) + floori(float(wave) / 12.0)

func pick_enemy(wave: int) -> String:
    var roll := randf()
    if wave < 12:
        return "grub" if roll < 0.72 else "spitter"
    if wave < 22:
        if roll < 0.55: return "grub"
        if roll < 0.80: return "spitter"
        return "mite"
    if wave < 35:
        if roll < 0.38: return "grub"
        if roll < 0.62: return "spitter"
        if roll < 0.82: return "mite"
        return "turret"
    if wave < 48:
        if roll < 0.30: return "grub"
        if roll < 0.52: return "spitter"
        if roll < 0.68: return "mite"
        if roll < 0.84: return "turret"
        return "slug"
    if wave < 65:
        if roll < 0.24: return "grub"
        if roll < 0.43: return "spitter"
        if roll < 0.56: return "mite"
        if roll < 0.70: return "turret"
        if roll < 0.84: return "slug"
        return "hopper"
    if wave < 80:
        if roll < 0.20: return "grub"
        if roll < 0.37: return "spitter"
        if roll < 0.50: return "mite"
        if roll < 0.62: return "turret"
        if roll < 0.74: return "slug"
        if roll < 0.89: return "hopper"
        return "fish_thief"
    if roll < 0.16: return "grub"
    if roll < 0.30: return "spitter"
    if roll < 0.43: return "mite"
    if roll < 0.55: return "turret"
    if roll < 0.68: return "slug"
    if roll < 0.84: return "hopper"
    return "fish_thief"

func boss_for_wave(wave: int) -> String:
    if wave == 25: return "trash_golem"
    if wave == 50: return "orbital_compactor"
    if wave == 100: return "great_flea"
    return ""

func is_set_piece(wave: int) -> bool:
    return wave % 10 == 0
