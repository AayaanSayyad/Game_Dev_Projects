extends Node

const CATS := {
    "stray": {
        "name": "Stray", "role": "Balanced", "starter": "scratch_claws",
        "hp": 5, "speed": 82.0, "accel": 430.0, "friction": 290.0,
        "fire_rate": 0.20, "damage": 1, "bullet_speed": 138.0,
        "skill": "claw_burst", "amiibo": "+5% move speed", "color": "#d9d4c7"
    },
    "brick": {
        "name": "Brick", "role": "Ranged", "starter": "hairball_slingshot",
        "hp": 4, "speed": 76.0, "accel": 390.0, "friction": 270.0,
        "fire_rate": 0.44, "damage": 2, "bullet_speed": 116.0,
        "skill": "splatter_lob", "amiibo": "+1 pierce on primary", "color": "#b98d6a"
    },
    "soot": {
        "name": "Soot", "role": "Bruiser", "starter": "forge_hammer",
        "hp": 7, "speed": 63.0, "accel": 350.0, "friction": 230.0,
        "fire_rate": 0.52, "damage": 3, "bullet_speed": 82.0,
        "skill": "anvil_dash", "amiibo": "−10% gear loss", "color": "#3d3a46"
    },
    "miso": {
        "name": "Miso", "role": "Support", "starter": "purr_charm",
        "hp": 5, "speed": 80.0, "accel": 410.0, "friction": 280.0,
        "fire_rate": 0.27, "damage": 1, "bullet_speed": 126.0,
        "skill": "healing_purr", "amiibo": "+0.5 heart start", "color": "#f0c9a6"
    }
}

func get_cat(id: String) -> Dictionary:
    return CATS.get(id, CATS["stray"])

func get_ids() -> Array:
    return CATS.keys()

func get_name(id: String) -> String:
    return str(get_cat(id).get("name", id))
