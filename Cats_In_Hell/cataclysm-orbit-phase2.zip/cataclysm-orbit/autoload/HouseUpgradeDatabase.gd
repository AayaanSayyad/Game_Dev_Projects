extends Node

const UPGRADES := {
    "tent":{"name":"Tent","track":"Shelter","cost":{"sardine_rotten":{"Common":5}},"effect":"Unlock save"},
    "shack":{"requires":["tent"],"name":"Shack","track":"Shelter","cost":{"mackerel_foul":{"Uncommon":3},"sardine_rotten":{"Common":2}},"effect":"Checkpoint at wave 10"},
    "cat_house":{"requires":["shack"],"name":"Cat House","track":"Shelter","cost":{"tuna_mold":{"Rare":2},"mackerel_foul":{"Common":5}},"effect":"Checkpoint at wave 50"},
    "observatory":{"requires":["cat_house"],"name":"Observatory","track":"Shelter","cost":{"salmon_sour":{"Rare":3}},"effect":"Planet map view"},
    "forge":{"name":"Scratching Post Forge","track":"Workshop","cost":{"mackerel_foul":{"Common":4},"herring_haunt":{"Uncommon":1}},"effect":"Craft tier-1 gear"},
    "smoker":{"requires":["forge"],"name":"Smoker","track":"Workshop","cost":{"sardine_rotten":{"Uncommon":6}},"effect":"5 Common → 1 Uncommon"},
    "insurance":{"requires":["forge"],"name":"Insurance Collar Rack","track":"Workshop","cost":{"crab_old":{"Rare":1}},"effect":"−10% gear loss"},
    "fish_safe":{"requires":["insurance"],"name":"Fish Safe","track":"Workshop","cost":{"lobster_red":{"Epic":2}},"effect":"−20% fish loss"},
    "compost":{"name":"Compost Bin","track":"Workshop","cost":{"sardine_rotten":{"Rare":2},"mackerel_foul":{"Uncommon":2}},"effect":"Recover 20% of run fish on death"},
    "window_perch":{"requires":["tent"],"name":"Window Perch","track":"Colony","cost":{"sardine_rotten":{"Common":8}},"effect":"Unlock Amiibo slot 2"},
    "rescue_beacon":{"requires":["cat_house"],"name":"Rescue Beacon","track":"Colony","cost":{"tuna_mold":{"Rare":3}},"effect":"Recruit tier-2 cats"},
    "nap_room":{"requires":["tent"],"name":"Nap Room","track":"Colony","cost":{"salmon_sour":{"Uncommon":4}},"effect":"+1 starting heart waves 1–20"},
    "memorial":{"requires":["cat_house"],"name":"Memorial Shelf","track":"Colony","cost":{"tuna_mold":{"Epic":1}},"effect":"Recover 1 lost gear / 10 runs"}
}

func get_upgrade(id: String) -> Dictionary:
    return UPGRADES.get(id,{})

func ids() -> Array:
    return UPGRADES.keys()
