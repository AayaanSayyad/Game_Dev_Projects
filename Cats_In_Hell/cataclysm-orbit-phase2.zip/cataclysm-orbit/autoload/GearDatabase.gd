extends Node

const GEAR := {
    "scratch_claws": {"name":"Scratch Claws", "slot":"weapon", "rarity":"Common", "cat":"stray", "cost":{}},
    "hairball_slingshot": {"name":"Hairball Slingshot", "slot":"weapon", "rarity":"Common", "cat":"brick", "cost":{}},
    "forge_hammer": {"name":"Rusty Forge Hammer", "slot":"weapon", "rarity":"Common", "cat":"soot", "cost":{}},
    "purr_charm": {"name":"Purr Charm", "slot":"weapon", "rarity":"Common", "cat":"miso", "cost":{}},
    "cardboard_armor": {"name":"Cardboard Armor", "slot":"armor", "rarity":"Common", "hp":1, "cost":{"sardine_rotten":{"Common":4}}},
    "scrap_plate": {"name":"Scrap Plate", "slot":"armor", "rarity":"Uncommon", "hp":2, "damage_reduction":0.08, "cost":{"mackerel_foul":{"Common":5,"Uncommon":1}}},
    "fish_bell": {"name":"Fish Bell", "slot":"trinket", "rarity":"Common", "pickup":0.25, "cost":{"sardine_rotten":{"Uncommon":3}}},
    "lucky_bone": {"name":"Lucky Bone", "slot":"trinket", "rarity":"Rare", "rarity_luck":0.06, "cost":{"mackerel_foul":{"Uncommon":3,"Rare":1}}},
    "orbit_gear": {"name":"Orbit Gear", "slot":"trinket", "rarity":"Rare", "bullet_slow":0.08, "cost":{"sardine_rotten":{"Rare":2},"mackerel_foul":{"Uncommon":2}}}
}

func get(id: String) -> Dictionary:
    return GEAR.get(id, {})

func get_ids() -> Array:
    return GEAR.keys()

func starter_for_cat(cat_id: String) -> String:
    return str(CatDatabase.get_cat(cat_id).get("starter", "scratch_claws"))
