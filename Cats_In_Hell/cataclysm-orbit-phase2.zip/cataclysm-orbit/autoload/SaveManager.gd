extends Node

const SAVE_PATH := "user://save.json"

func save_state() -> void:
    var data := {
        "version":GameState.SAVE_VERSION,
        "vault_fish":GameState.vault_fish,
        "account_exp":GameState.account_exp,
        "house_upgrades":GameState.house_upgrades,
        "roster_unlocked":GameState.roster_unlocked,
        "gear_owned":GameState.gear_owned,
        "equipped":GameState.equipped,
        "planet_progress":{"litter_prime":{"best_wave":GameState.best_wave,"checkpoint":GameState.checkpoint_wave,"cleared":GameState.planet_cleared}},
        "resume_buffs":GameState.resume_buffs,
        "resume_fish":GameState.resume_fish,
        "resume_available":GameState.resume_available,
        "amiibo_slots":GameState.amiibo_slots,
        "settings":GameState.settings
    }
    var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if file:
        file.store_string(JSON.stringify(data))
        file.close()

func load_state() -> void:
    if not FileAccess.file_exists(SAVE_PATH): return
    var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
    if file == null: return
    var parsed = JSON.parse_string(file.get_as_text())
    file.close()
    if typeof(parsed) != TYPE_DICTIONARY: return
    GameState.vault_fish = parsed.get("vault_fish", GameState.vault_fish)
    GameState.account_exp = int(parsed.get("account_exp",0))
    GameState.house_upgrades = parsed.get("house_upgrades",[])
    GameState.roster_unlocked = parsed.get("roster_unlocked",["stray"])
    GameState.gear_owned = parsed.get("gear_owned",[])
    GameState.equipped = parsed.get("equipped",{})
    var progress: Dictionary = parsed.get("planet_progress",{}).get("litter_prime",{})
    GameState.best_wave = int(progress.get("best_wave",0))
    GameState.checkpoint_wave = int(progress.get("checkpoint",0))
    GameState.planet_cleared = bool(progress.get("cleared",false))
    GameState.resume_buffs = parsed.get("resume_buffs",[])
    GameState.resume_fish = parsed.get("resume_fish",GameState.resume_fish)
    GameState.resume_available = bool(parsed.get("resume_available",false))
    GameState.amiibo_slots = parsed.get("amiibo_slots",["",""])
    GameState.settings = parsed.get("settings",GameState.settings)
