extends Node2D

var house: HouseScreen
var arena: Arena

func _ready() -> void:
    randomize()
    await get_tree().process_frame
    show_house()

func show_house() -> void:
    get_tree().paused = false
    if is_instance_valid(arena):
        arena.queue_free()
        arena = null
    house = HouseScreen.new()
    add_child(house)
    house.launch_requested.connect(start_run_from_checkpoint)
    house.new_run_requested.connect(start_new_run)

func start_run_from_checkpoint() -> void:
    _start_run(true, GameState.checkpoint_wave + 1 if GameState.checkpoint_wave > 0 else 1)

func start_new_run() -> void:
    _start_run(false, 1)

func _start_run(use_checkpoint_state: bool, start_wave: int) -> void:
    BulletPool.clear_all()
    if is_instance_valid(house):
        house.queue_free()
        house = null
    GameState.start_run(start_wave, use_checkpoint_state)
    arena = Arena.new()
    add_child(arena)
    arena.run_over.connect(_on_run_over)
    arena.run_won.connect(_on_run_won)

func _on_run_over() -> void:
    if is_instance_valid(arena):
        BulletPool.clear_all()
        arena.queue_free()
        arena = null
    show_house()

func _on_run_won() -> void:
    if is_instance_valid(arena):
        BulletPool.clear_all()
        arena.queue_free()
        arena = null
    show_house()
