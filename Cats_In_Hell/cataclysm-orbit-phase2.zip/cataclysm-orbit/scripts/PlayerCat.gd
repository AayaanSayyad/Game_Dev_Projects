class_name PlayerCat
extends Node2D

signal died

var cat_id := "stray"
var cat_data: Dictionary = {}
var max_hp := 5
var hp := 5
var max_speed := 82.0
var acceleration := 430.0
var friction := 290.0
var velocity := Vector2.ZERO
var aim := Vector2.RIGHT
var fire_timer := 0.0
var dash_timer := 0.0
var skill_timer := 0.0
var hurt_timer := 0.0
var hurt_flash := 0.0
var invuln := false
var arena: Node
var aim_position := Vector2.ZERO
var dead := false
var damage_mult := 1.0
var pickup_mult := 1.0
var rarity_luck := 0.0
var damage_reduction := 0.0
var pierce_bonus := 0
var bullet_slow := 0.0

func setup(p_arena: Node, p_cat_id: String) -> void:
    arena = p_arena
    cat_id = p_cat_id
    cat_data = CatDatabase.get_cat(cat_id)
    max_hp = int(cat_data.get("hp",5))
    max_speed = float(cat_data.get("speed",82.0))
    acceleration = float(cat_data.get("accel",430.0))
    friction = float(cat_data.get("friction",290.0))
    hp = max_hp
    _apply_gear()
    hp=max_hp
    if GameState.has_buff("Fish Magnet"): pickup_mult += 0.30
    if GameState.has_buff("Lucky Gut"): rarity_luck += 0.05
    if GameState.has_buff("Slow Orbit"): bullet_slow += 0.10
    if GameState.has_buff("Piercing Claws"): pierce_bonus += 1
    if GameState.has_house_upgrade("nap_room") and GameState.current_wave <= 20:
        hp = min(max_hp, hp + 1)
    global_position = arena.arena_center
    queue_redraw()

func _apply_gear() -> void:
    var loadout := GameState.get_equipped(cat_id)
    for slot in ["weapon","armor","trinket"]:
        var id := str(loadout.get(slot,""))
        if id == "": continue
        var data := GearDatabase.get(id)
        max_hp += int(data.get("hp",0))
        damage_reduction += float(data.get("damage_reduction",0.0))
        pickup_mult += float(data.get("pickup",0.0))
        rarity_luck += float(data.get("rarity_luck",0.0))
        bullet_slow += float(data.get("bullet_slow",0.0))

func _physics_process(delta: float) -> void:
    if dead: return
    var input_vec := Vector2.ZERO
    if Input.is_physical_key_pressed(KEY_A): input_vec.x -= 1.0
    if Input.is_physical_key_pressed(KEY_D): input_vec.x += 1.0
    if Input.is_physical_key_pressed(KEY_W): input_vec.y -= 1.0
    if Input.is_physical_key_pressed(KEY_S): input_vec.y += 1.0
    input_vec=input_vec.normalized()
    var target_velocity := input_vec * max_speed * (1.05 if cat_id == "stray" and "stray" in GameState.amiibo_slots else 1.0)
    var accel := acceleration if input_vec.length() > 0.0 else friction
    velocity = velocity.move_toward(target_velocity, accel * delta)
    global_position += velocity * delta
    global_position.x = clamp(global_position.x, arena.bounds.position.x + 12.0, arena.bounds.end.x - 12.0)
    global_position.y = clamp(global_position.y, arena.bounds.position.y + 12.0, arena.bounds.end.y - 12.0)

    aim_position = arena.get_global_mouse_position()
    var aim_vector := aim_position - global_position
    if aim_vector.length() > 0.1: aim = aim_vector.normalized()

    fire_timer -= delta
    dash_timer -= delta
    skill_timer -= delta
    hurt_timer = max(0.0, hurt_timer - delta)
    hurt_flash = max(0.0, hurt_flash - delta)

    if Input.is_physical_key_pressed(KEY_SHIFT) and dash_timer <= 0.0: dash()
    if Input.is_physical_key_pressed(KEY_E) and skill_timer <= 0.0: active_skill()
    if (Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT) or Input.is_physical_key_pressed(KEY_SPACE)) and fire_timer <= 0.0:
        fire_primary()
    if not invuln and hurt_timer <= 0.0: check_enemy_contacts()
    queue_redraw()

func fire_primary() -> void:
    var rate := float(cat_data.get("fire_rate",0.20))
    fire_timer = rate
    if cat_id == "brick":
        var base := aim
        for spread in [-0.10,0.0,0.10]:
            arena.spawn_player_bullet(global_position + base * 9.0, base.rotated(spread) * 104.0, float(cat_data.get("damage",1)) * damage_mult, Color("#d9a46f"), 3.0, pierce_bonus)
    elif cat_id == "soot":
        for i in range(3):
            var dir := aim.rotated((float(i)-1.0)*0.16)
            arena.spawn_player_bullet(global_position + dir*8.0, dir*80.0, float(cat_data.get("damage",1))*damage_mult, Color("#e48b4f"), 4.0, 0)
    elif cat_id == "miso":
        arena.spawn_player_bullet(global_position + aim*9.0, aim*126.0, float(cat_data.get("damage",1))*damage_mult, Color("#9ee7d6"), 2.5, pierce_bonus)
    else:
        for spread in [-0.035,0.035]:
            var dir := aim.rotated(spread)
            arena.spawn_player_bullet(global_position + dir*10.0, dir*float(cat_data.get("bullet_speed",138.0)), int(cat_data.get("damage",1))*damage_mult, Color("#f2d75f"), 2.5, pierce_bonus)
    AudioManager.play_sfx("primary")

func dash() -> void:
    var dir := velocity.normalized()
    if dir.length() < 0.1: dir = aim
    dash_timer = 1.4 if cat_id != "soot" else 1.65
    invuln = true
    var distance := 48.0 if cat_id != "soot" else 58.0
    var tween := create_tween()
    tween.tween_property(self,"global_position",global_position + dir*distance,0.18).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
    tween.tween_callback(func(): invuln = false)
    if cat_id == "soot":
        arena.damage_enemies_in_radius(global_position, 18.0, 3)
    AudioManager.play_sfx("dash")

func active_skill() -> void:
    invuln = true
    if cat_id == "miso":
        hp = min(max_hp, hp + 2)
        arena.damage_enemies_in_radius(global_position, 28.0, 2)
        skill_timer = 7.0
    elif cat_id == "brick":
        skill_timer = 6.0
        for i in range(12):
            var dir := Vector2.RIGHT.rotated(TAU*float(i)/12.0)
            arena.spawn_player_bullet(global_position + dir*8.0, dir*78.0, 2, Color("#d9a46f"), 3.5, 1)
    elif cat_id == "soot":
        skill_timer = 7.0
        arena.damage_enemies_in_radius(global_position, 34.0, 5)
        velocity += aim*75.0
    else:
        skill_timer = 5.0
        for i in range(10):
            var dir := Vector2.RIGHT.rotated(TAU*float(i)/10.0)
            arena.spawn_player_bullet(global_position + dir*8.0, dir*110.0, 2, Color("#9ee7d6"), 3.0, 0)
    var timer := get_tree().create_timer(0.22)
    timer.timeout.connect(func(): invuln = false)
    AudioManager.play_sfx("active_skill")

func take_damage(amount: int) -> void:
    if dead or invuln or hurt_timer > 0.0: return
    hurt_timer = 0.45
    hurt_flash = 0.18
    var final_damage := max(1, int(ceil(float(amount) * (1.0-damage_reduction))))
    hp -= final_damage
    AudioManager.play_sfx("player_hurt")
    if hp <= 0:
        if GameState.has_buff("Second Wind"):
            GameState.run_buffs.erase("Second Wind")
            hp=1
            hurt_timer=0.8
            AudioManager.play_sfx("second_wind")
        else:
            die()
    queue_redraw()

func check_enemy_contacts() -> void:
    for enemy in arena.enemies:
        if is_instance_valid(enemy) and enemy.active and global_position.distance_to(enemy.global_position) < 14.0:
            take_damage(1)
            break

func die() -> void:
    if dead: return
    dead = true
    velocity = Vector2.ZERO
    AudioManager.play_sfx("player_splat")
    died.emit()

func _draw() -> void:
    PixelArt.draw_cat(self,Vector2.ZERO,1.0,hurt_flash>0.0,1.0 if aim.x>=0 else -1.0,cat_id)
