class_name HouseScreen
extends Node2D

signal launch_requested
signal new_run_requested

var ui:CanvasLayer
var panel:PanelContainer
var content:VBoxContainer
var info:Label
var mode:="main"

func _ready() -> void:
    _build_ui()
    queue_redraw()

func _build_ui() -> void:
    ui=CanvasLayer.new(); add_child(ui)
    var title:=Label.new(); title.position=Vector2(18,12); title.text="CATACLYSM ORBIT"; title.add_theme_font_size_override("font_size",18); title.add_theme_color_override("font_color",Color("#f2d75f")); ui.add_child(title)
    var subtitle:=Label.new(); subtitle.position=Vector2(20,38); subtitle.text="HOUSE  •  LITTER PRIME"; subtitle.add_theme_font_size_override("font_size",9); subtitle.add_theme_color_override("font_color",Color("#b8b1c8")); ui.add_child(subtitle)
    panel=PanelContainer.new(); panel.position=Vector2(292,10); panel.size=Vector2(178,249)
    var style:=StyleBoxFlat.new(); style.bg_color=Color("#25212e"); style.border_color=Color("#5c526d"); style.set_border_width_all(2); panel.add_theme_stylebox_override("panel",style); ui.add_child(panel)
    content=VBoxContainer.new(); content.add_theme_constant_override("separation",5); panel.add_child(content)
    _show_main()

func _clear() -> void:
    for child in content.get_children(): child.queue_free()

func _heading(text:String) -> void:
    var h:=Label.new(); h.text=text; h.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; h.add_theme_font_size_override("font_size",11); h.add_theme_color_override("font_color",Color("#f0e9d8")); content.add_child(h)

func _button(text:String,callback:Callable) -> void:
    var b:=Button.new(); b.text=text; b.custom_minimum_size=Vector2(150,25); b.pressed.connect(callback); content.add_child(b)

func _show_main() -> void:
    mode="main"; _clear(); _heading("HOUSE CONSOLE")
    _button("LAUNCH PAD",_show_loadout)
    _button("ROSTER NEST",func():_show_roster())
    _button("GEAR RACK",func():_show_gear())
    _button("FISH VAULT",func():_show_vault())
    _button("BLUEPRINT WALL",func():_show_upgrades())
    info=Label.new(); info.custom_minimum_size=Vector2(150,70); info.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; info.add_theme_font_size_override("font_size",9); info.add_theme_color_override("font_color",Color("#cfc7da")); content.add_child(info)
    _refresh_main()

func _refresh_main() -> void:
    if not is_instance_valid(info): return
    var cp:=GameState.checkpoint_wave if GameState.checkpoint_wave>0 else 0
    info.text="Active cat: %s\nCheckpoint: %s\nBest: WAVE %d\nEXP: %d\nAmiibo: %s / %s" % [CatDatabase.get_name(GameState.active_cat_id),"WAVE %d"%cp if cp>0 else "none",GameState.best_wave,GameState.account_exp,GameState.amiibo_slots[0] if GameState.amiibo_slots[0]!="" else "empty",GameState.amiibo_slots[1] if GameState.amiibo_slots[1]!="" else "empty"]
    if not GameState.last_run_result.is_empty(): info.text += "\nLast run: %d kept / %d destroyed" % [GameState.last_run_result.get("fish_kept",0),GameState.last_run_result.get("fish_destroyed",0)]

func _show_loadout() -> void:
    _clear(); _heading("PRE-RUN LOADOUT")
    var cat:=Label.new(); cat.text="PLAYING AS: %s" % CatDatabase.get_name(GameState.active_cat_id); cat.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; content.add_child(cat)
    _button("CHANGE CAT",func():_show_roster(true))
    _button("Amiibo: %s" % (CatDatabase.get_name(GameState.amiibo_slots[0]) if GameState.amiibo_slots[0]!="" else "EMPTY"),func():_show_amiibo(0))
    _button("Amiibo 2: %s" % (CatDatabase.get_name(GameState.amiibo_slots[1]) if GameState.amiibo_slots[1]!="" else "LOCKED"),func():_show_amiibo(1))
    var checkpoint_wave:=GameState.checkpoint_wave+1 if GameState.checkpoint_wave>0 else 1
    var resume_label:="RESUME SAVE • WAVE %d" % checkpoint_wave if GameState.resume_available and GameState.checkpoint_wave>0 else ("START CHECKPOINT • WAVE %d" % checkpoint_wave if GameState.checkpoint_wave>0 else "LAUNCH • WAVE 1")
    _button(resume_label,func():launch_requested.emit())
    _button("NEW RUN • WAVE 1",func():new_run_requested.emit())
    _button("BACK",_show_main)

func _show_roster(change_playable:=false) -> void:
    _clear(); _heading("ROSTER NEST")
    var note:=Label.new(); note.text="Playable cat. Select one."; note.add_theme_font_size_override("font_size",9); content.add_child(note)
    for id in CatDatabase.get_ids():
        var unlocked:=id in GameState.roster_unlocked
        var b:=Button.new(); b.text=("✓ " if GameState.active_cat_id==id else "")+CatDatabase.get_name(id)+" • "+str(CatDatabase.get_cat(id).get("role",""))
        b.disabled=not unlocked
        b.pressed.connect(func(): _select_playable(id,change_playable))
        content.add_child(b)
    if not change_playable: _button("Amiibo SLOT 1",func():_show_amiibo(0)); _button("Amiibo SLOT 2",func():_show_amiibo(1))
    _button("BACK",_show_main)

func _select_playable(id:String, return_to_loadout:bool=false) -> void:
    GameState.active_cat_id=id
    for i in range(GameState.amiibo_slots.size()):
        if GameState.amiibo_slots[i]==id: GameState.amiibo_slots[i]=""
    SaveManager.save_state()
    _show_loadout() if return_to_loadout else _show_roster()

func _select_amiibo(slot:int,id:String) -> void:
    for i in range(GameState.amiibo_slots.size()):
        if i!=slot and GameState.amiibo_slots[i]==id: GameState.amiibo_slots[i]=""
    GameState.amiibo_slots[slot]=id
    SaveManager.save_state()
    _show_loadout()

func _show_amiibo(slot:int) -> void:
    _clear(); _heading("AMIIBO SLOT %d" % (slot+1))
    if slot==1 and not GameState.has_house_upgrade("window_perch"):
        var l:=Label.new(); l.text="LOCKED\nBuild Window Perch."; l.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; content.add_child(l); _button("BACK",_show_loadout); return
    for id in GameState.roster_unlocked:
        if id==GameState.active_cat_id: continue
        var b:=Button.new(); b.text=CatDatabase.get_name(id)+" • "+str(CatDatabase.get_cat(id).get("amiibo","")); b.pressed.connect(func(): _select_amiibo(slot,id)); content.add_child(b)
    if GameState.amiibo_slots[slot]!="": _button("CLEAR SLOT",func():GameState.amiibo_slots[slot]="";SaveManager.save_state();_show_loadout())
    _button("BACK",_show_loadout)

func _show_vault() -> void:
    _clear(); _heading("FISH VAULT")
    var box:=Label.new(); box.add_theme_font_size_override("font_size",8)
    var text:=""
    for species in FishDatabase.get_species_ids():
        var counts:=GameState.vault_fish.get(species,{})
        text += "%s\n C:%d U:%d R:%d E:%d L:%d\n" % [FishDatabase.get_species_name(species),counts.get("Common",0),counts.get("Uncommon",0),counts.get("Rare",0),counts.get("Epic",0),counts.get("Legendary",0)]
    box.text=text; box.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; content.add_child(box); _button("BACK",_show_main)

func _show_upgrades() -> void:
    _clear(); _heading("BLUEPRINT WALL")
    for id in HouseUpgradeDatabase.ids():
        var up:=HouseUpgradeDatabase.get_upgrade(id)
        var bought:=GameState.has_house_upgrade(id)
        if id in ["tent","shack","forge","smoker","insurance","compost","window_perch","nap_room"] or bought:
            var prereq_ok:=true
            for req in up.get("requires",[]):
                if not GameState.has_house_upgrade(req): prereq_ok=false
            var upgrade_id:=id
            var b:=Button.new()
            b.text=("✓ " if bought else "BUY ")+str(up.get("name",id))
            b.tooltip_text=str(up.get("effect",""))+"\nCost: "+_format_cost(up.get("cost",{}))+("\nRequires: "+", ".join(up.get("requires",[])) if not prereq_ok else "")
            b.disabled=bought or not prereq_ok or not GameState.can_afford(up.get("cost",{}))
            b.pressed.connect(func(): GameState.purchase_upgrade(upgrade_id); _show_upgrades())
            content.add_child(b)
    _button("BACK",_show_main)

func _show_gear() -> void:
    _clear(); _heading("GEAR RACK")
    var loadout:=GameState.get_equipped(GameState.active_cat_id)
    var l:=Label.new(); l.text="%s\nWeapon: %s\nArmor: %s\nTrinket: %s" % [CatDatabase.get_name(GameState.active_cat_id),_gear_name(str(loadout.get("weapon",""))),_gear_name(str(loadout.get("armor",""))),_gear_name(str(loadout.get("trinket","")))]; l.add_theme_font_size_override("font_size",9); content.add_child(l)
    for id in GearDatabase.get_ids():
        var data:=GearDatabase.get(id)
        var slot:=str(data.get("slot","trinket"))
        var craft_locked:=not GameState.has_house_upgrade("forge") and not data.get("cost",{}).is_empty()
        if slot=="weapon" and data.get("cat","")!=GameState.active_cat_id: continue
        if GameState.owns_gear(id):
            var equipped_loadout:=GameState.get_equipped(GameState.active_cat_id)
            if str(equipped_loadout.get(slot,""))!=id:
                var equip_button:=Button.new(); equip_button.text="EQUIP "+str(data.get("name",id)); equip_button.pressed.connect(func(): GameState.equip(GameState.active_cat_id,slot,id); SaveManager.save_state(); _show_gear()); content.add_child(equip_button)
            continue
        var craft_id:=id
        var craft_data:=data
        var b:=Button.new(); b.text="CRAFT "+str(craft_data.get("name",craft_id)); b.disabled=craft_locked or not GameState.can_afford(craft_data.get("cost",{})); b.tooltip_text=("Build the Forge first.\n" if craft_locked else "")+"Cost: "+_format_cost(craft_data.get("cost",{})); b.pressed.connect(func(): GameState.pay_cost(craft_data.get("cost",{})); GameState.gear_owned.append(craft_id); GameState.equip(GameState.active_cat_id,str(craft_data.get("slot","trinket")),craft_id); SaveManager.save_state(); _show_gear()); content.add_child(b)
    _button("BACK",_show_main)

func _gear_name(id:String) -> String:
    if id=="": return "Empty"
    return str(GearDatabase.get(id).get("name",id))

func _format_cost(cost:Dictionary) -> String:
    if cost.is_empty(): return "FREE"
    var parts:Array=[]
    for species in cost.keys():
        for rarity in cost[species].keys(): parts.append("%d %s %s" % [int(cost[species][rarity]),FishDatabase.get_species_name(species),rarity[0]])
    return ", ".join(parts)

func _draw() -> void:
    draw_rect(Rect2(0,0,480,270),Color("#11111b"))
    var stars:=[Vector2(28,68),Vector2(76,56),Vector2(135,88),Vector2(205,62),Vector2(258,98),Vector2(35,200),Vector2(233,216),Vector2(272,181),Vector2(160,50),Vector2(105,220)]
    for star in stars: draw_rect(Rect2(star,Vector2(2,2)),Color("#d5cee2"))
    var center:=Vector2(150,153)
    draw_circle(center+Vector2(0,18),92,Color("#0b0a11"))
    draw_colored_polygon(PackedVector2Array([center+Vector2(-72,10),center+Vector2(0,-42),center+Vector2(72,10),center+Vector2(0,62)]),Color("#5d5774"))
    draw_rect(Rect2(center+Vector2(-38,-20),Vector2(76,54)),Color("#b58c66"))
    draw_colored_polygon(PackedVector2Array([center+Vector2(-48,-20),center+Vector2(0,-54),center+Vector2(48,-20)]),Color("#7a5d68"))
    draw_rect(Rect2(center+Vector2(-12,2),Vector2(24,32)),Color("#493f4f"))
    draw_rect(Rect2(center+Vector2(-31,-10),Vector2(14,13)),Color("#9ee7d6"))
    draw_rect(Rect2(center+Vector2(17,-10),Vector2(14,13)),Color("#9ee7d6"))
    draw_circle(center+Vector2(0,66),20,Color("#7d6a9c")); draw_arc(center+Vector2(0,66),20,0,TAU,16,Color("#f2d75f"),2)
    PixelArt.draw_cat(self,center+Vector2(0,28),0.85,false,1.0,GameState.active_cat_id)
    draw_string(ThemeDB.fallback_font,center+Vector2(-52,-66),"HOUSE",HORIZONTAL_ALIGNMENT_LEFT,-1,12,Color("#f0e9d8"))
    draw_string(ThemeDB.fallback_font,center+Vector2(-40,92),"LAUNCH",HORIZONTAL_ALIGNMENT_LEFT,-1,9,Color("#f2d75f"))
