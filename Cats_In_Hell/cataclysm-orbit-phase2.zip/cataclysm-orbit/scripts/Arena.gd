class_name Arena
extends Node2D

signal run_over
signal run_won

var arena_center := Vector2(240,150)
var bounds := Rect2(34,38,412,198)
var player: PlayerCat
var enemies: Array = []
var pickups: Array = []
var current_wave := 1
var wave_state := "spawning"
var spawn_remaining := 0
var spawn_timer := 0.0
var intermission_timer := 5.0
var wave_elapsed := 0.0
var reward_pending := false
var extract_timer := 0.0
var paused := false
var camera: Camera2D
var hud: CanvasLayer
var wave_label: Label
var hearts_label: Label
var dash_label: Label
var skill_label: Label
var fish_label: Label
var status_label: Label
var boss_bar: ProgressBar
var reward_panel: PanelContainer
var boss_name := ""
var shake_time := 0.0
var pause_panel:PanelContainer
var death_panel:PanelContainer

func _ready() -> void:
    process_mode=Node.PROCESS_MODE_ALWAYS
    _build_background()
    _build_camera()
    _build_hud()
    player=PlayerCat.new()
    player.name=GameState.active_cat_id
    add_child(player)
    player.setup(self,GameState.active_cat_id)
    player.died.connect(_on_player_died)
    _spawn_amiibo()
    start_wave(GameState.current_wave)

func _build_camera() -> void:
    camera=Camera2D.new()
    camera.position=arena_center
    camera.position_smoothing_enabled=true
    camera.position_smoothing_speed=5.5
    camera.rotation=deg_to_rad(9.0)
    add_child(camera)
    camera.make_current()
    var tween:=create_tween()
    tween.tween_property(camera,"rotation",0.0,1.5).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)

func _build_background() -> void:
    queue_redraw()

func _label(pos:Vector2,text:String,font_size:int) -> Label:
    var label:=Label.new()
    label.position=pos
    label.text=text
    label.add_theme_font_size_override("font_size",font_size)
    label.add_theme_color_override("font_color",Color("#f0e9d8"))
    return label

func _build_hud() -> void:
    hud=CanvasLayer.new(); add_child(hud)
    var top:=ColorRect.new(); top.position=Vector2(6,6); top.size=Vector2(468,30); top.color=Color("#25212e"); hud.add_child(top)
    wave_label=_label(Vector2(12,9),"WAVE 001 / 100",12)
    hearts_label=_label(Vector2(110,9),"♥♥♥♥♥",12)
    dash_label=_label(Vector2(218,9),"DASH READY",10)
    skill_label=_label(Vector2(314,9),"E: READY",10)
    fish_label=_label(Vector2(14,246),"RUN FISH 0",10)
    status_label=_label(Vector2(146,246),"",10)
    for label in [wave_label,hearts_label,dash_label,skill_label,fish_label,status_label]: hud.add_child(label)
    boss_bar=ProgressBar.new()
    boss_bar.position=Vector2(90,42); boss_bar.size=Vector2(300,9); boss_bar.visible=false; boss_bar.max_value=1.0; hud.add_child(boss_bar)

func _unhandled_input(event:InputEvent) -> void:
    if event is InputEventKey and event.keycode==KEY_ESCAPE and event.pressed and not event.echo:
        if paused: _resume_pause()
        elif not reward_pending: _toggle_pause()

func _process(delta:float) -> void:
    if paused: return
    if shake_time>0.0: shake_time-=delta
    if wave_state=="spawning": _process_spawning(delta)
    elif wave_state=="combat": _process_combat(delta)
    elif wave_state=="breather": _process_breather(delta)
    _update_pickup_magnet()
    _update_hud()
    enemies=enemies.filter(func(e): return is_instance_valid(e) and e.active)
    pickups=pickups.filter(func(p): return is_instance_valid(p) and not p.collected)
    queue_redraw()

func start_wave(wave:int) -> void:
    current_wave=clampi(wave,1,WaveDirector.WAVE_MAX)
    GameState.current_wave=current_wave
    wave_elapsed=0.0
    reward_pending=false
    extract_timer=0.0
    boss_bar.visible=false
    boss_name=""
    for enemy in enemies:
        if is_instance_valid(enemy): enemy.queue_free()
    enemies=[]
    if current_wave in [25,50,100]:
        wave_state="combat"
        status_label.text="BOSS INCOMING"
        spawn_boss(WaveDirector.boss_for_wave(current_wave))
    else:
        wave_state="spawning"
        spawn_remaining=min(WaveDirector.spawn_budget(current_wave),24)
        spawn_timer=0.0
        status_label.text="INCOMING"

func _process_spawning(delta:float) -> void:
    spawn_timer-=delta
    if spawn_remaining>0 and spawn_timer<=0.0 and enemies.size()<WaveDirector.enemy_count_cap(current_wave):
        var elite:=current_wave==75 or (current_wave%10==0 and randf()<0.35)
        var kind: String="elite_grub" if elite else WaveDirector.pick_enemy(current_wave)
        spawn_enemy(kind,elite)
        spawn_remaining-=1
        spawn_timer=WaveDirector.spawn_rate(current_wave)
    if spawn_remaining<=0: wave_state="combat"; status_label.text="CLEAR THE WAVE"

func _process_combat(_delta:float) -> void:
    enemies=enemies.filter(func(e): return is_instance_valid(e) and e.active)
    if enemies.is_empty(): begin_breather()
    else:
        for enemy in enemies:
            if is_instance_valid(enemy) and enemy.boss:
                boss_bar.visible=true
                boss_bar.value=enemy.hp/max(enemy.max_hp,1.0)
                boss_name=enemy.enemy_type.replace("_"," ").to_upper()
                return
        boss_bar.visible=false

func begin_breather() -> void:
    if wave_state=="breather": return
    wave_state="breather"
    intermission_timer=5.0
    status_label.text="WAVE CLEAR  5.0"
    for pickup in pickups:
        if is_instance_valid(pickup): pickup.attract(player)
    if current_wave==10:
        GameState.checkpoint_reached(10)
        if GameState.amiibo_slots[0]=="": GameState.amiibo_slots[0]=GameState.active_cat_id if GameState.active_cat_id!="" else "stray"
        show_reward_picker(["Warm Milk","Fish Magnet","Slow Orbit"])
    elif current_wave==25:
        if not GameState.roster_unlocked.has("brick"): GameState.unlock_cat("brick")
    elif current_wave==50:
        if not GameState.roster_unlocked.has("soot"): GameState.unlock_cat("soot")
        if not GameState.roster_unlocked.has("miso"): GameState.unlock_cat("miso")
        GameState.checkpoint_reached(50)
        show_reward_picker(["Second Wind","Lucky Gut","Piercing Claws"])
    elif current_wave==100:
        _finish_run()

func _process_breather(delta:float) -> void:
    if reward_pending: return
    intermission_timer-=delta
    if current_wave in [30,50,80] and Input.is_physical_key_pressed(KEY_F):
        extract_timer+=delta
    else:
        extract_timer=max(0.0,extract_timer-delta*2.0)
    if current_wave in [30,50,80] and extract_timer>0.0 and extract_timer<3.0:
        status_label.text="EXTRACTING %.1fs / 3.0  (F)" % extract_timer
    else:
        status_label.text="WAVE CLEAR  %.1f" % max(intermission_timer,0.0)
    if extract_timer>=3.0:
        _extract_run(); return
    if intermission_timer<=0.0:
        if current_wave>=WaveDirector.WAVE_MAX: _finish_run()
        else: start_wave(current_wave+1)

func spawn_enemy(enemy_type:String,elite:bool=false) -> void:
    var enemy:=OrbitEnemy.new(); add_child(enemy)
    var angle:=randf_range(0.0,TAU)
    var edge:=Vector2(cos(angle)*0.5+0.5,sin(angle)*0.5+0.5)
    var pos:=Vector2(bounds.position.x+edge.x*bounds.size.x,bounds.position.y+edge.y*bounds.size.y)
    if pos.distance_to(player.global_position)<95.0: pos=arena_center+(pos-arena_center).normalized()*120.0
    enemy.global_position=pos
    enemy.setup(enemy_type,player,self,WaveDirector.enemy_hp_mult(current_wave),elite)
    enemy.defeated.connect(_on_enemy_defeated)
    enemies.append(enemy)

func spawn_boss(boss_type:String) -> void:
    var enemy:=OrbitEnemy.new(); add_child(enemy); enemy.global_position=arena_center+Vector2(0,-52)
    enemy.setup(boss_type,player,self,1.0,false)
    enemy.defeated.connect(_on_enemy_defeated)
    enemies.append(enemy)
    boss_bar.visible=true
    status_label.text=boss_type.replace("_"," ").to_upper()
    shake_screen(0.25)

func _on_enemy_defeated(_enemy:Node2D) -> void:
    if is_instance_valid(_enemy) and _enemy.boss: shake_screen(0.35)

func spawn_fish_drop(pos:Vector2,elite:bool=false) -> void:
    var fish:=FishPickup.new(); add_child(fish)
    var luck:float=player.rarity_luck
    fish.setup(FishDatabase.species_roll(current_wave),FishDatabase.rarity_roll(elite,luck),pos)
    pickups.append(fish)

func spawn_boss_fish(pos:Vector2) -> void:
    for i in range(10):
        var fish:=FishPickup.new(); add_child(fish)
        var offset:=Vector2.RIGHT.rotated(TAU*float(i)/10.0)*randf_range(10.0,28.0)
        var rarity:="Rare"
        if i>=7: rarity="Epic"
        fish.setup(FishDatabase.species_roll(current_wave),rarity,pos+offset)
        pickups.append(fish)

func spawn_enemy_bullet(pos:Vector2,velocity:Vector2,damage:int,color:=Color("#b46ac7"),radius:=3.0) -> void:
    if not BulletPool.can_spawn(): return
    var bullet:=_get_or_create_bullet()
    var slow:float=player.bullet_slow
    bullet.activate(pos,velocity*(1.0-slow),float(damage),false,color,radius,0)
    bullet.arena=self

func spawn_player_bullet(pos:Vector2,velocity:Vector2,damage:float,color:Color,radius:float,pierce:int=0) -> void:
    if not BulletPool.can_spawn(): return
    var bullet:=_get_or_create_bullet()
    bullet.activate(pos,velocity,damage,true,color,radius,pierce)
    bullet.arena=self

func _get_or_create_bullet() -> OrbitBullet:
    for child in get_children():
        if child is OrbitBullet and not child.active: return child
    var bullet:=OrbitBullet.new(); add_child(bullet); return bullet

func bullet_tick(bullet:OrbitBullet) -> void:
    if bullet.friendly:
        for enemy in enemies:
            if not is_instance_valid(enemy) or not enemy.active: continue
            var key:=enemy.get_instance_id()
            if bullet.hit_targets.has(key): continue
            var hit_radius:=20.0 if enemy.boss else (15.0 if enemy.enemy_type in ["turret","slug","hopper"] else 12.0)
            if bullet.global_position.distance_to(enemy.global_position)<hit_radius:
                bullet.hit_targets[key]=true
                enemy.take_damage(bullet.damage,bullet.velocity.normalized()*12.0)
                if bullet.pierce_left>0:
                    bullet.pierce_left-=1
                else:
                    bullet.deactivate()
                return
    else:
        if bullet.global_position.distance_to(player.global_position)<9.0:
            player.take_damage(int(bullet.damage)); bullet.deactivate()

func damage_enemies_in_radius(pos:Vector2,radius:float,damage:float) -> void:
    if radius<=0.0: return
    for enemy in enemies:
        if is_instance_valid(enemy) and enemy.active and pos.distance_to(enemy.global_position)<=radius:
            enemy.take_damage(damage,(enemy.global_position-pos).normalized()*14.0)

func flash_boss_phase(phase:int) -> void:
    status_label.text="THE GREAT FLEA • PHASE %d" % phase
    shake_screen(0.45)

func status_note(text:String) -> void:
    status_label.text=text

func _on_player_died() -> void:
    set_process(false); set_physics_process(false)
    var result:=GameState.die_and_return_home()
    _show_death_summary(result)
    await get_tree().create_timer(1.8).timeout
    get_tree().paused=false
    run_over.emit()

func _toggle_pause() -> void:
    paused=true
    get_tree().paused=true
    pause_panel=PanelContainer.new()
    pause_panel.process_mode=Node.PROCESS_MODE_ALWAYS
    pause_panel.position=Vector2(88,68); pause_panel.size=Vector2(304,125)
    var style:=StyleBoxFlat.new(); style.bg_color=Color("#25212e"); style.border_color=Color("#e7c85a"); style.set_border_width_all(2); pause_panel.add_theme_stylebox_override("panel",style)
    hud.add_child(pause_panel)
    var box:=VBoxContainer.new(); pause_panel.add_child(box)
    var title:=Label.new(); title.text="PAUSED"; title.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; title.add_theme_font_size_override("font_size",16); box.add_child(title)
    var text:=Label.new(); text.text="Esc resumes • progress is safe at checkpoints"; text.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; text.add_theme_font_size_override("font_size",9); box.add_child(text)
    var resume:=Button.new(); resume.text="RESUME"; resume.pressed.connect(_resume_pause); box.add_child(resume)

func _resume_pause() -> void:
    if is_instance_valid(pause_panel): pause_panel.queue_free()
    get_tree().paused=false
    paused=false

func _show_death_summary(result:Dictionary) -> void:
    get_tree().paused=false
    death_panel=PanelContainer.new(); death_panel.process_mode=Node.PROCESS_MODE_ALWAYS
    death_panel.position=Vector2(64,58); death_panel.size=Vector2(352,154)
    var style:=StyleBoxFlat.new(); style.bg_color=Color("#302a3b"); style.border_color=Color("#d36b70"); style.set_border_width_all(2); death_panel.add_theme_stylebox_override("panel",style); hud.add_child(death_panel)
    var box:=VBoxContainer.new(); box.add_theme_constant_override("separation",5); death_panel.add_child(box)
    var title:=Label.new(); title.text="CATACLYSM CLAIMED YOU"; title.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; title.add_theme_font_size_override("font_size",14); title.add_theme_color_override("font_color",Color("#f2d75f")); box.add_child(title)
    var body:=Label.new(); body.text="Fish carried: %d\nSecured: %d   Recovered: %d   Destroyed: %d\nGear lost: %s\nResume: wave %d" % [result.get("fish_total",0),result.get("fish_kept",0),result.get("fish_recovered",0),result.get("fish_destroyed",0),_gear_loss_names(result.get("gear_lost",[])),GameState.current_wave]; body.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; body.add_theme_font_size_override("font_size",10); box.add_child(body)

func _gear_loss_names(items:Array) -> String:
    if items.is_empty(): return "none"
    var names:Array=[]
    for id in items: names.append(str(GearDatabase.get(id).get("name",id)))
    return ", ".join(names)

func _finish_run() -> void:
    GameState.best_wave=max(GameState.best_wave,current_wave)
    GameState.planet_cleared=current_wave>=100
    GameState.deposit_run_fish(0.0)
    SaveManager.save_state()
    run_won.emit()

func _extract_run() -> void:
    GameState.deposit_run_fish(0.30)
    SaveManager.save_state()
    run_over.emit()

func show_reward_picker(choices:Array) -> void:
    reward_pending=true
    reward_panel=PanelContainer.new()
    reward_panel.position=Vector2(52,60); reward_panel.size=Vector2(376,150)
    var style:=StyleBoxFlat.new(); style.bg_color=Color("#302a3b"); style.border_color=Color("#e7c85a"); style.set_border_width_all(2)
    reward_panel.add_theme_stylebox_override("panel",style); hud.add_child(reward_panel)
    var box:=VBoxContainer.new(); box.add_theme_constant_override("separation",6); reward_panel.add_child(box)
    var title:=Label.new(); title.text="WAVE %d REWARD • CHOOSE ONE" % current_wave; title.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; title.add_theme_font_size_override("font_size",13); title.add_theme_color_override("font_color",Color("#f2d75f")); box.add_child(title)
    var descriptions:Dictionary={"Warm Milk":"+1 heart this run","Fish Magnet":"+30% pickup range this run","Slow Orbit":"Enemy bullets −10%","Second Wind":"Revive once at 1 heart","Lucky Gut":"+5% rarity luck","Piercing Claws":"+1 bullet pierce this run"}
    for choice in choices:
        var button:=Button.new(); button.text="%s   %s" % [choice,descriptions.get(choice,"")]; button.custom_minimum_size=Vector2(340,27); button.pressed.connect(func(): _choose_reward(choice)); box.add_child(button)

func _choose_reward(choice:String) -> void:
    GameState.add_buff(choice)
    if choice=="Warm Milk": player.hp=min(player.max_hp,player.hp+1); player.max_hp+=1
    elif choice=="Fish Magnet": player.pickup_mult+=0.30
    elif choice=="Piercing Claws": player.pierce_bonus+=1
    if is_instance_valid(reward_panel): reward_panel.queue_free()
    reward_pending=false
    intermission_timer=5.0
    GameState.resume_buffs=GameState.run_buffs.duplicate()
    SaveManager.save_state()

func _spawn_amiibo() -> void:
    var offset_slot:=0
    for cat_id in GameState.amiibo_slots:
        if cat_id=="" or cat_id==GameState.active_cat_id: continue
        var amiibo:=OrbitAmiibo.new(); add_child(amiibo); amiibo.setup(cat_id,player,offset_slot); offset_slot+=1
        _apply_amiibo_passive(cat_id)

func _apply_amiibo_passive(cat_id:String) -> void:
    if cat_id=="brick": player.pierce_bonus+=1
    elif cat_id=="miso": player.max_hp+=1; player.hp+=1

func _update_pickup_magnet() -> void:
    if not is_instance_valid(player): return
    var radius:float=48.0*player.pickup_mult
    for pickup in pickups:
        if is_instance_valid(pickup) and not pickup.collected and pickup.global_position.distance_to(player.global_position)<=radius:
            pickup.attract(player)

func _update_hud() -> void:
    wave_label.text="WAVE %03d / 100" % current_wave
    hearts_label.text="♥".repeat(max(player.hp,0))+"♡".repeat(max(player.max_hp-player.hp,0))
    dash_label.text="DASH %s" % ("READY" if player.dash_timer<=0.0 else "%.1f" % player.dash_timer)
    skill_label.text="E: %s" % ("READY" if player.skill_timer<=0.0 else "%.1f" % player.skill_timer)
    fish_label.text="RUN FISH %d" % GameState.run_fish_total()
    if boss_name!="": status_label.text=boss_name

func shake_screen(duration:float) -> void:
    if not GameState.settings.get("screen_shake",true): return
    shake_time=max(shake_time,duration)
    camera.offset=Vector2(randf_range(-2.0,2.0),randf_range(-2.0,2.0))
    var tween:=create_tween(); tween.tween_property(camera,"offset",Vector2.ZERO,duration).set_trans(Tween.TRANS_SINE)

func _draw() -> void:
    draw_rect(Rect2(0,0,480,270),Color("#0e0c15"))
    var center:=arena_center
    # isometric combat disk
    draw_colored_polygon(PackedVector2Array([center+Vector2(-190,0),center+Vector2(0,-68),center+Vector2(190,0),center+Vector2(0,68)]),Color("#3f3a50"))
    draw_colored_polygon(PackedVector2Array([center+Vector2(-176,0),center+Vector2(0,-58),center+Vector2(176,0),center+Vector2(0,58)]),Color("#5b536c"))
    draw_polyline(PackedVector2Array([center+Vector2(-190,0),center+Vector2(0,-68),center+Vector2(190,0),center+Vector2(0,68),center+Vector2(-190,0)]),Color("#8a7896"),2.0)
    # crater marks and edge lights
    for p in [center+Vector2(-120,-18),center+Vector2(82,12),center+Vector2(-20,32),center+Vector2(135,-30)]:
        draw_circle(p,5,Color("#49425a")); draw_circle(p+Vector2(1,-1),2,Color("#676078"))
    for p in [center+Vector2(-165,0),center+Vector2(165,0),center+Vector2(0,-57),center+Vector2(0,57)]: draw_circle(p,2.5,Color("#f2d75f"))
