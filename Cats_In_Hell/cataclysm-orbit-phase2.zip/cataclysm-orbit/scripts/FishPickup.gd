class_name FishPickup
extends Node2D

var species_id := "sardine_rotten"
var rarity := "Common"
var life := 0.0
var bob := 0.0
var collected := false
var target: Node2D

func setup(p_species: String,p_rarity: String,p_pos: Vector2) -> void:
    species_id=p_species
    rarity=p_rarity
    global_position=p_pos
    life=18.0
    bob=randf()*TAU
    queue_redraw()

func attract(p_target: Node2D) -> void:
    target=p_target

func _process(delta: float) -> void:
    if collected: return
    life -= delta
    bob += delta*4.0
    if life <= 0.0:
        queue_free(); return
    if is_instance_valid(target):
        var dir := target.global_position-global_position
        if dir.length() < 70.0:
            global_position += dir.normalized() * (100.0 + (70.0-dir.length())*3.0) * delta
        if dir.length() < 11.0:
            collect()
    queue_redraw()

func collect() -> void:
    if collected: return
    collected=true
    GameState.add_run_fish(species_id,rarity,1)
    AudioManager.play_sfx("fish_pickup")
    queue_free()

func _draw() -> void:
    PixelArt.draw_fish(self,Vector2(0,sin(bob)*1.5),rarity)
