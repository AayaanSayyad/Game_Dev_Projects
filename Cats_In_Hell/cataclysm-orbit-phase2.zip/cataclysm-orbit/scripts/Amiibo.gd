class_name OrbitAmiibo
extends Node2D

var cat_id := "stray"
var slot_index := 0
var player: Node2D
var angle := 0.0
var radius := 24.0
var speed := 1.2

func setup(p_cat_id: String, p_player: Node2D, p_slot: int) -> void:
    cat_id = p_cat_id
    player = p_player
    slot_index = p_slot
    angle = float(p_slot) * PI
    queue_redraw()

func _process(delta: float) -> void:
    if not is_instance_valid(player): return
    angle += speed * delta
    global_position = player.global_position + Vector2.RIGHT.rotated(angle) * radius
    queue_redraw()

func _draw() -> void:
    PixelArt.draw_cat(self, Vector2.ZERO, 0.42, false, 1.0)
    draw_circle(Vector2.ZERO, 8.0, Color(0,0,0,0.08))
    draw_arc(Vector2.ZERO, 8.5, 0.0, TAU, 16, Color("#f2d75f"), 1.0)
