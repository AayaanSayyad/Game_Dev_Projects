class_name OrbitEnemy
extends Node2D

signal defeated(enemy: Node2D)

var enemy_type := "grub"
var hp := 3.0
var max_hp := 3.0
var speed := 22.0
var damage := 1
var shoot_timer := 1.3
var hit_flash := 0.0
var knockback := Vector2.ZERO
var attack_cooldown := 1.0
var player: Node2D
var arena: Node
var death_timer := 0.0
var active := true
var elite := false
var boss := false
var phase := 1
var age := 0.0
var orbit_sign := 1.0
var stolen := false

func setup(p_type: String,p_player: Node2D,p_arena: Node,p_hp_mult: float=1.0,p_elite: bool=false) -> void:
    enemy_type=p_type
    player=p_player
    arena=p_arena
    elite=p_elite
    boss=enemy_type in ["trash_golem","orbital_compactor","great_flea"]
    _configure(p_hp_mult)
    active=true
    visible=true
    death_timer=0.0
    modulate.a=1.0
    queue_redraw()

func _configure(hp_mult: float) -> void:
    var wave := int(arena.current_wave)
    if enemy_type in ["grub","elite_grub"]:
        max_hp=4.0*hp_mult*(2.2 if elite else 1.0); speed=22.0+wave*0.25; attack_cooldown=0.8
    elif enemy_type == "spitter":
        max_hp=7.0*hp_mult; speed=10.0+wave*0.12; attack_cooldown=max(0.95,1.8-wave*0.005)
    elif enemy_type == "mite":
        max_hp=1.6*hp_mult; speed=47.0+wave*0.25; attack_cooldown=1.0
    elif enemy_type == "turret":
        max_hp=11.0*hp_mult; speed=0.0; attack_cooldown=max(1.2,2.2-wave*0.006)
    elif enemy_type == "slug":
        max_hp=15.0*hp_mult; speed=8.0+wave*0.07; attack_cooldown=2.0
    elif enemy_type == "hopper":
        max_hp=10.0*hp_mult; speed=18.0+wave*0.15; attack_cooldown=2.8
    elif enemy_type == "fish_thief":
        max_hp=8.0*hp_mult; speed=28.0+wave*0.18; attack_cooldown=1.6
    elif enemy_type == "trash_golem":
        max_hp=155.0*hp_mult; speed=9.5; attack_cooldown=2.2
    elif enemy_type == "orbital_compactor":
        max_hp=390.0*hp_mult; speed=13.0; attack_cooldown=2.0
        orbit_sign=-1.0 if randf()<0.5 else 1.0
    elif enemy_type == "great_flea":
        max_hp=950.0*hp_mult; speed=15.0; attack_cooldown=1.7
    hp=max_hp
    phase=1

func _physics_process(delta: float) -> void:
    if not active or death_timer > 0.0: return
    if not is_instance_valid(player): return
    age += delta
    var to_player := player.global_position-global_position
    if boss:
        _boss_logic(delta,to_player)
    elif enemy_type in ["grub","elite_grub"]:
        if to_player.length()>17.0: global_position += to_player.normalized()*speed*delta
    elif enemy_type == "spitter":
        if to_player.length()>118.0: global_position += to_player.normalized()*speed*delta
        elif to_player.length()<82.0: global_position -= to_player.normalized()*speed*0.7*delta
        _shoot_timer(delta,func(): fire_spore())
    elif enemy_type == "mite":
        if to_player.length()>12.0: global_position += to_player.normalized()*speed*delta
    elif enemy_type == "turret":
        _shoot_timer(delta,func(): fire_radial(8,44.0))
    elif enemy_type == "slug":
        if to_player.length()>55.0: global_position += to_player.normalized()*speed*delta
        _shoot_timer(delta,func(): fire_spore_burst())
    elif enemy_type == "hopper":
        if attack_cooldown<=0.0: perform_hop()
        attack_cooldown-=delta
        if shoot_timer > 0.0: shoot_timer-=delta
    elif enemy_type == "fish_thief":
        if to_player.length()>18.0: global_position += to_player.normalized()*speed*delta
        _shoot_timer(delta,func(): steal_or_dash())
    knockback=knockback.move_toward(Vector2.ZERO,delta*90.0)
    global_position += knockback*delta
    global_position.x=clamp(global_position.x,arena.bounds.position.x+8.0,arena.bounds.end.x-8.0)
    global_position.y=clamp(global_position.y,arena.bounds.position.y+8.0,arena.bounds.end.y-8.0)
    hit_flash=max(0.0,hit_flash-delta)
    queue_redraw()

func _shoot_timer(delta:float,callback:Callable) -> void:
    shoot_timer-=delta
    if shoot_timer<=0.0:
        shoot_timer=attack_cooldown
        callback.call()

func _boss_logic(delta:float,to_player:Vector2) -> void:
    if enemy_type == "trash_golem":
        if to_player.length()>85.0: global_position += to_player.normalized()*speed*delta
        _shoot_timer(delta,func(): boss_golem_slam())
    elif enemy_type == "orbital_compactor":
        var radial := (global_position-arena.arena_center)
        if radial.length()<42.0: radial=Vector2.RIGHT
        var tangent:=Vector2(-radial.y,radial.x).normalized()*orbit_sign
        global_position += tangent*speed*delta
        global_position += -radial.normalized()*clamp((radial.length()-92.0),-16.0,16.0)*delta
        _shoot_timer(delta,func(): boss_compactor_ring())
    elif enemy_type == "great_flea":
        var new_phase := 1 if hp/max_hp>0.66 else (2 if hp/max_hp>0.33 else 3)
        if new_phase != phase:
            phase=new_phase
            arena.flash_boss_phase(phase)
        if to_player.length()>105.0: global_position += to_player.normalized()*speed*delta
        elif to_player.length()<72.0: global_position -= to_player.normalized()*speed*0.8*delta
        _shoot_timer(delta,func(): boss_flea_pattern())

func fire_spore() -> void:
    var dir:Vector2=(player.global_position-global_position).normalized()
    var speed_mult:=WaveDirector.bullet_speed_mult(arena.current_wave)
    arena.spawn_enemy_bullet(global_position,dir*46.0*speed_mult,1,Color("#b46ac7"),3.0)
    AudioManager.play_sfx("enemy_windup")

func fire_spore_burst() -> void:
    var base:Vector2=(player.global_position-global_position).angle()
    for a in [-0.22,0.0,0.22]:
        var dir:=Vector2.RIGHT.rotated(base+a)
        arena.spawn_enemy_bullet(global_position,dir*42.0,1,Color("#b477a8"),3.0)

func fire_radial(count:int,speed_value:float) -> void:
    for i in range(count):
        var dir:=Vector2.RIGHT.rotated(TAU*float(i)/float(count))
        arena.spawn_enemy_bullet(global_position,dir*speed_value*WaveDirector.bullet_speed_mult(arena.current_wave),1,Color("#c18ad2"),3.0)
    AudioManager.play_sfx("enemy_windup")

func perform_hop() -> void:
    attack_cooldown=2.8
    var dir:Vector2=(player.global_position-global_position).normalized()
    var landing:=global_position+dir*70.0
    var tween:=create_tween()
    tween.tween_property(self,"global_position",landing,0.42).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
    tween.tween_callback(func(): fire_radial(10,38.0))

func steal_or_dash() -> void:
    if arena.pickups.size()>0:
        stolen=true
        var nearest:Node=null
        var nearest_d:=INF
        for pickup in arena.pickups:
            if is_instance_valid(pickup):
                var d:float=global_position.distance_to(pickup.global_position)
                if d<nearest_d: nearest=pickup;nearest_d=d
        if nearest:
            nearest.queue_free()
            arena.status_note("A FISH THIEF ATE A FISH")
    else:
        var dir:Vector2=(player.global_position-global_position).normalized()
        global_position+=dir*28.0

func boss_golem_slam() -> void:
    arena.status_note("TRASH GOLEM • SLAM")
    fire_radial(10,36.0)
    var dir:Vector2=(player.global_position-global_position).normalized()
    arena.spawn_enemy_bullet(global_position,dir*62.0,1,Color("#d6a05c"),4.0)

func boss_compactor_ring() -> void:
    arena.status_note("ORBITAL COMPACTOR • RING")
    var count:=14 if arena.current_wave>=50 else 10
    for i in range(count):
        var dir:=Vector2.RIGHT.rotated(TAU*float(i)/float(count)+age*0.35)
        arena.spawn_enemy_bullet(global_position,dir*40.0,1,Color("#7ed6c2"),3.5)
    var aim_dir:Vector2=(player.global_position-global_position).normalized()
    arena.spawn_enemy_bullet(global_position,aim_dir*58.0,1,Color("#efc66d"),4.0)

func boss_flea_pattern() -> void:
    arena.status_note("THE GREAT FLEA • PHASE %d" % phase)
    if phase==1:
        fire_radial(14,34.0)
    elif phase==2:
        var base:float=(player.global_position-global_position).angle()
        for i in range(7):
            var dir:=Vector2.RIGHT.rotated(base+(float(i)-3.0)*0.16)
            arena.spawn_enemy_bullet(global_position,dir*52.0,1,Color("#d990a9"),3.5)
        fire_radial(10,30.0)
    else:
        fire_radial(20,33.0)
        var dir:Vector2=(player.global_position-global_position).normalized()
        for i in range(4):
            arena.spawn_enemy_bullet(global_position,dir.rotated((float(i)-1.5)*0.09)*65.0,1,Color("#efb15e"),4.0)

func take_damage(amount:float,impulse:Vector2=Vector2.ZERO) -> void:
    if not active: return
    hp-=amount
    hit_flash=0.12
    knockback+=impulse*(0.35 if boss else 1.0)
    if hp<=0.0: die()
    else: AudioManager.play_sfx("enemy_hit")
    queue_redraw()

func die() -> void:
    if not active: return
    active=false
    death_timer=0.42 if boss else 0.30
    AudioManager.play_sfx("boss_splat" if boss else "enemy_splat")
    if arena:
        if boss:
            arena.spawn_boss_fish(global_position)
        else:
            arena.spawn_fish_drop(global_position,elite)
    defeated.emit(self)

func _process(delta:float) -> void:
    if death_timer<=0.0: return
    death_timer-=delta
    var progress:=1.0-clamp(death_timer/(0.42 if boss else 0.30),0.0,1.0)
    scale=Vector2.ONE*(1.0+progress*(0.8 if boss else 0.5))
    modulate.a=1.0-progress
    queue_redraw()
    if death_timer<=0.0: queue_free()

func _draw() -> void:
    PixelArt.draw_enemy(self,Vector2.ZERO,enemy_type,hp/max(hp if hp>0.0 else 1.0,max_hp),elite,phase)
    if hit_flash>0.0:
        draw_rect(Rect2(-16,-16,32,32),Color(1,1,1,0.72),false,2.0)
