class_name PixelArt
extends RefCounted

static func draw_cat(target: CanvasItem, pos: Vector2, scale: float = 1.0, hurt: bool = false, facing := 1.0, cat_id := "stray") -> void:
    var palette := {
        "stray":"#d9d4c7", "brick":"#b98d6a", "soot":"#3d3a46", "miso":"#f0c9a6"
    }
    var accent_palette := {
        "stray":"#c78f5a", "brick":"#e6b64e", "soot":"#8a7e88", "miso":"#8ccfc1"
    }
    var body := Color.WHITE if hurt else Color(palette.get(cat_id,"#d9d4c7"))
    var accent := Color(accent_palette.get(cat_id,"#c78f5a"))
    var dark := Color("#2c2734")
    var o := pos
    target.draw_rect(Rect2(o + Vector2(-7,-6)*scale,Vector2(14,12)*scale),body)
    target.draw_rect(Rect2(o + Vector2(-9,-14)*scale,Vector2(18,11)*scale),body)
    target.draw_colored_polygon(PackedVector2Array([o+Vector2(-8,-13)*scale,o+Vector2(-5,-22)*scale,o+Vector2(-1,-14)*scale]),body)
    target.draw_colored_polygon(PackedVector2Array([o+Vector2(8,-13)*scale,o+Vector2(5,-22)*scale,o+Vector2(1,-14)*scale]),body)
    target.draw_rect(Rect2(o+Vector2(-5+facing*2,-11)*scale,Vector2(2,2)*scale),dark)
    target.draw_rect(Rect2(o+Vector2(3+facing*2,-11)*scale,Vector2(2,2)*scale),dark)
    target.draw_rect(Rect2(o+Vector2(-2,-7)*scale,Vector2(4,2)*scale),accent)
    if cat_id == "brick":
        target.draw_rect(Rect2(o+Vector2(-7,-18)*scale,Vector2(14,2)*scale),accent)
    elif cat_id == "soot":
        target.draw_rect(Rect2(o+Vector2(-11,-5)*scale,Vector2(3,6)*scale),accent)
    elif cat_id == "miso":
        target.draw_rect(Rect2(o+Vector2(-9,0)*scale,Vector2(18,3)*scale),accent)

static func draw_grub(target: CanvasItem, pos: Vector2, hp_ratio: float = 1.0, elite: bool = false) -> void:
    var c := Color("#8a6b4d") if not elite else Color("#b77b4f")
    target.draw_rect(Rect2(pos+Vector2(-9,-7),Vector2(18,14)),c)
    target.draw_rect(Rect2(pos+Vector2(-12,-3),Vector2(24,6)),c.darkened(0.15))
    target.draw_rect(Rect2(pos+Vector2(-7,-10),Vector2(4,4)),c.lightened(0.1))
    target.draw_rect(Rect2(pos+Vector2(3,-10),Vector2(4,4)),c.lightened(0.1))
    target.draw_rect(Rect2(pos+Vector2(-7,-1),Vector2(3,3)),Color("#332b39"))
    target.draw_rect(Rect2(pos+Vector2(4,-1),Vector2(3,3)),Color("#332b39"))
    target.draw_rect(Rect2(pos+Vector2(-8,11),Vector2(16,2)),Color("#3c3340"))
    target.draw_rect(Rect2(pos+Vector2(-8,11),Vector2(16*clamp(hp_ratio,0.0,1.0),2)),Color("#e7c85a"))

static func draw_spitter(target: CanvasItem, pos: Vector2, hp_ratio: float = 1.0) -> void:
    var c := Color("#6f9d76")
    target.draw_rect(Rect2(pos+Vector2(-10,-9),Vector2(20,18)),c)
    target.draw_rect(Rect2(pos+Vector2(-5,-14),Vector2(10,6)),c.lightened(0.1))
    target.draw_circle(pos+Vector2(-4,-3),2.5,Color("#2f2c39"))
    target.draw_circle(pos+Vector2(4,-3),2.5,Color("#2f2c39"))
    target.draw_rect(Rect2(pos+Vector2(-12,11),Vector2(24,2)),Color("#3c3340"))
    target.draw_rect(Rect2(pos+Vector2(-12,11),Vector2(24*clamp(hp_ratio,0.0,1.0),2)),Color("#e7c85a"))

static func draw_enemy(target: CanvasItem, pos: Vector2, enemy_type: String, hp_ratio: float, elite := false, phase := 1) -> void:
    match enemy_type:
        "grub","elite_grub": draw_grub(target,pos,hp_ratio,elite)
        "spitter": draw_spitter(target,pos,hp_ratio)
        "mite":
            target.draw_rect(Rect2(pos+Vector2(-5,-5),Vector2(10,10)),Color("#d3b55c"))
            target.draw_rect(Rect2(pos+Vector2(-3,-2),Vector2(2,2)),Color("#332b39"))
            target.draw_rect(Rect2(pos+Vector2(1,-2),Vector2(2,2)),Color("#332b39"))
        "turret":
            target.draw_circle(pos,12,Color("#596879"))
            target.draw_rect(Rect2(pos+Vector2(-3,-14),Vector2(6,12)),Color("#b4c1d0"))
            target.draw_circle(pos,3,Color("#f2d75f"))
        "slug":
            target.draw_colored_polygon(PackedVector2Array([pos+Vector2(-13,4),pos+Vector2(-6,-9),pos+Vector2(10,-7),pos+Vector2(14,7),pos+Vector2(0,12)]),Color("#8d6880"))
            target.draw_rect(Rect2(pos+Vector2(-8,-4),Vector2(3,3)),Color("#2f2c39"))
            target.draw_rect(Rect2(pos+Vector2(4,-4),Vector2(3,3)),Color("#2f2c39"))
        "hopper":
            target.draw_rect(Rect2(pos+Vector2(-8,-12),Vector2(16,18)),Color("#719a62"))
            target.draw_rect(Rect2(pos+Vector2(-12,5),Vector2(6,9)),Color("#4f704a"))
            target.draw_rect(Rect2(pos+Vector2(6,5),Vector2(6,9)),Color("#4f704a"))
        "fish_thief":
            target.draw_rect(Rect2(pos+Vector2(-9,-10),Vector2(18,17)),Color("#a26b55"))
            target.draw_rect(Rect2(pos+Vector2(-12,-15),Vector2(6,6)),Color("#a26b55"))
            target.draw_rect(Rect2(pos+Vector2(6,-15),Vector2(6,6)),Color("#a26b55"))
            target.draw_rect(Rect2(pos+Vector2(-4,-4),Vector2(8,3)),Color("#322b3a"))
        "trash_golem": draw_boss_golem(target,pos,hp_ratio)
        "orbital_compactor": draw_boss_compactor(target,pos,hp_ratio)
        "great_flea": draw_boss_flea(target,pos,hp_ratio,phase)
        _:
            draw_grub(target,pos,hp_ratio,elite)

static func draw_boss_golem(target: CanvasItem,pos:Vector2,hp_ratio:float) -> void:
    target.draw_rect(Rect2(pos+Vector2(-25,-22),Vector2(50,42)),Color("#756a78"))
    target.draw_rect(Rect2(pos+Vector2(-31,-7),Vector2(62,18)),Color("#5c5261"))
    target.draw_rect(Rect2(pos+Vector2(-16,-10),Vector2(8,7)),Color("#f2d75f"))
    target.draw_rect(Rect2(pos+Vector2(8,-10),Vector2(8,7)),Color("#f2d75f"))
    target.draw_rect(Rect2(pos+Vector2(-28,24),Vector2(56,4)),Color("#3a3442"))
    target.draw_rect(Rect2(pos+Vector2(-28,24),Vector2(56*hp_ratio,4)),Color("#d36b70"))

static func draw_boss_compactor(target: CanvasItem,pos:Vector2,hp_ratio:float) -> void:
    target.draw_circle(pos,26,Color("#6e5d81"))
    target.draw_arc(pos,30,0,TAU,24,Color("#e0b355"),4)
    target.draw_circle(pos+Vector2(-9,-3),5,Color("#f2d75f"))
    target.draw_circle(pos+Vector2(9,-3),5,Color("#f2d75f"))
    target.draw_rect(Rect2(pos+Vector2(-30,28),Vector2(60,4)),Color("#3a3442"))
    target.draw_rect(Rect2(pos+Vector2(-30,28),Vector2(60*hp_ratio,4)),Color("#7ed6c2"))

static func draw_boss_flea(target: CanvasItem,pos:Vector2,hp_ratio:float,phase:int) -> void:
    var body := Color("#bd6d73") if phase == 1 else (Color("#9b69bb") if phase == 2 else Color("#e29b55"))
    target.draw_circle(pos,30,body)
    target.draw_circle(pos+Vector2(-10,-5),5,Color("#2f2c39"))
    target.draw_circle(pos+Vector2(10,-5),5,Color("#2f2c39"))
    target.draw_rect(Rect2(pos+Vector2(-16,9),Vector2(32,6)),Color("#2f2c39"))
    target.draw_rect(Rect2(pos+Vector2(-34,34),Vector2(68,5)),Color("#3a3442"))
    target.draw_rect(Rect2(pos+Vector2(-34,34),Vector2(68*hp_ratio,5)),Color("#f2d75f"))

static func draw_fish(target: CanvasItem,pos:Vector2,rarity:String) -> void:
    var c := {"Common":Color("#78817a"),"Uncommon":Color("#4ea89c"),"Rare":Color("#8d6ec7"),"Epic":Color("#e0a642"),"Legendary":Color("#f08ad0")}.get(rarity,Color("#efcf62"))
    target.draw_colored_polygon(PackedVector2Array([pos+Vector2(-5,0),pos+Vector2(0,-4),pos+Vector2(7,0),pos+Vector2(0,4)]),c)
    target.draw_colored_polygon(PackedVector2Array([pos+Vector2(-5,0),pos+Vector2(-10,-4),pos+Vector2(-9,4)]),c.darkened(0.15))
    target.draw_rect(Rect2(pos+Vector2(2,-1),Vector2(2,2)),Color("#2f2c39"))
    if rarity in ["Epic","Legendary"]:
        target.draw_arc(pos,7,0,TAU,12,Color("#f2d75f"),1.0)
