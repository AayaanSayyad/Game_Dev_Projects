class_name OrbitBullet
extends Node2D

var velocity := Vector2.ZERO
var damage := 1.0
var friendly := false
var lifespan := 3.0
var active := false
var bullet_color := Color("#d4e26d")
var radius := 3.0
var arena: Node = null
var pierce_left := 0
var hit_targets := {}

func activate(p_position: Vector2,p_velocity: Vector2,p_damage: float,p_friendly: bool,p_color: Color=Color("#d4e26d"),p_radius: float=3.0,p_pierce: int=0) -> void:
    global_position=p_position
    velocity=p_velocity
    damage=p_damage
    friendly=p_friendly
    bullet_color=p_color
    radius=p_radius
    lifespan=3.0 if p_friendly else 4.0
    pierce_left=p_pierce
    hit_targets={}
    active=true
    visible=true
    BulletPool.register_bullet(self)
    queue_redraw()

func deactivate() -> void:
    active=false
    visible=false
    velocity=Vector2.ZERO
    hit_targets={}
    BulletPool.unregister_bullet(self)

func _physics_process(delta: float) -> void:
    if not active: return
    global_position += velocity*delta
    lifespan -= delta
    if lifespan <= 0.0 or global_position.x < -40 or global_position.y < -40 or global_position.x > 520 or global_position.y > 310:
        deactivate(); return
    if arena and arena.has_method("bullet_tick"): arena.bullet_tick(self)

func _draw() -> void:
    if active:
        draw_rect(Rect2(-radius,-radius,radius*2.0,radius*2.0),bullet_color)
        if not friendly and radius >= 3.5:
            draw_rect(Rect2(-radius*0.5,-radius*0.5,radius,radius),Color(1,1,1,0.18))
