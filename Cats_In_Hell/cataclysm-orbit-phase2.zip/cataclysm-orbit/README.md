# Cataclysm Orbit

Browser-first Godot 4 action game prototype based on the Cataclysm Orbit v2 design handoff.

## Current build: Phase 2 core

Implemented:

- House home screen with Launch Pad, Roster Nest, Gear Rack, Fish Vault, Blueprint Wall
- 4 playable cats: Stray, Brick, Soot, Miso
- Up to 2 Amiibo passive slots, with Window Perch gating slot 2
- Keyboard + mouse combat: WASD, mouse aim, LMB/Space fire, Shift dash, E active skill, Esc pause
- Momentum movement, deliberate dash, small hitboxes, pooled projectiles
- Planet 1 / Litter Prime with 100-wave ladder
- Slow bullet-hell scaling with 24-enemy cap and 120 active bullet cap
- Enemy roster: Grub, Spitter, Mite Swarm, Turret Eye, Junk Slug, Hopper, Fish Thief, Elite Grub
- Bosses: Trash Golem wave 25, Orbital Compactor wave 50, Great Flea wave 100
- Wave 10 and 50 checkpoint snapshots
- Optional extraction after waves 30, 50, and 80
- Milestone reward choices at waves 10 and 50
- Species + rarity fish economy with six Planet 1 fish species
- Specific fish recipes for house upgrades and gear crafting
- Weapon / armor / trinket equipment
- 15% base gear-loss roll on death, with Insurance and Soot Amiibo mitigation
- Fish death penalty, Compost recovery, Fish Safe mitigation
- Save data in `user://save.json`
- New run from wave 1 or resume/restart from the current checkpoint
- Procedural pixel-art placeholder rendering so no external assets are required to test systems

## Run in Godot

Open this folder in Godot 4.3 or newer. Use the Compatibility renderer for the web target.

Run the project from the editor. Export through Godot's Web preset for browser deployment.

## Controls

- WASD: move
- Mouse: aim
- Left mouse / Space: fire
- Shift: dash
- E: active skill
- F: hold during extract waves to extract
- Esc: pause

## Architecture

`autoload/` contains persistent state, save handling, data registries, wave direction, bullet limits, and audio hooks.

`scripts/` contains the House, Arena, Player, Enemy, Bullet, FishPickup, Amiibo, and procedural pixel-art layers.

`resources/` contains JSON manifests mirroring the game-design data model so the runtime can be migrated to external data resources later without redesigning the systems.

## Important limitation

This working folder has been structurally reviewed, but the execution environment used for this build did not contain the Godot executable, so an in-engine runtime smoke test and actual HTML5 export could not be performed here. The project is intentionally kept dependency-free to make that validation straightforward in Godot 4.
