# Phase 2 status

## Complete

- [x] 100-wave Planet 1 director
- [x] Boss waves 25 / 50 / 100
- [x] Four playable cats
- [x] Two-slot Amiibo system with passive effects
- [x] Gear slots and death-loss rolls
- [x] House upgrade purchase flow with prerequisites
- [x] Fish species + rarity economy
- [x] Checkpoint save snapshots
- [x] Resume checkpoint vs new wave-1 run
- [x] Optional extraction
- [x] Pause and death summary UI
- [x] Browser-conscious bullet and enemy caps

## Intentionally still deferred

- Production sprite sheets and frame-by-frame animation
- Full 16-cat roster
- Planets 2–4
- Full 12+ fish pool and planet-specific loot tables
- Advanced forge materials
- 64-cat skill tree
- Real audio files / music stems
- Desktop exports
- Account-level progression
- In-run shrine economy

## Tuning notes

The current boss HP is deliberately lower than a literal linear extrapolation of the enemy HP formula. The purpose is to keep the 100-wave ladder playable in browser sessions rather than turning wave 100 into a several-minute target dummy.
