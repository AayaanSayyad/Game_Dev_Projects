# Cataclysm Orbit — Build Notes

## Current scope

Phase 2 core systems are implemented around the original handoff. Planet 1 is now a complete 100-wave ladder with bosses, checkpoint snapshots, four playable cats, Amiibo passives, equipment, fish-specific meta progression, extraction, pause, and death summaries.

## Key rules resolved

- Checkpoints: waves 10 and 50.
- Optional extraction: wave clear after 30, 50, or 80; 3-second F hold; 70% run fish secured.
- Browser resume snapshots include checkpoint fish and temporary buffs.
- Death consumes a checkpoint resume snapshot only when the player actually launched by resuming that snapshot; a separate wave-1 farming run does not destroy an existing checkpoint save.
- Death fish penalty: 40% total loss by default; Compost converts 20% of that loss into recovered vault fish. Fish Safe reduces total loss to 32%.
- Gear loss: 15% per equipped piece, +5% for Epic; Insurance gives -10 percentage points and Soot Amiibo gives another -10 percentage points.
- Wave 25 unlocks Brick; wave 50 unlocks Soot and Miso.
- Amiibo slot 1 becomes available at wave 10; slot 2 requires Window Perch.
- Wave 75 uses an all-elite modifier.

## Current limitation

The container does not have a Godot binary, so the generated project has not been opened/run in the Godot editor here. Source structure and cross-file references were checked programmatically. Final engine parsing, browser export, and runtime balance still need editor validation.
